#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;
ll a[1000001][26];
ll dp[1000000];
ll k,p,t,r,u,z,x,y,l,g,w,q,c,i,j,f,m;
//ll a[3];
ll aa[26];
vector <ll> v;
main()
{
   char ch[1000000];
   string s;
   scanf("%s",ch);
   s=ch;
   l=s.length();


   for(i=1;i<=l;i++)
   {
       if(s[i-1]=='?')
         continue;
       p=s[i-1]-'A';
       a[i][p]++;
   }

    for(i=1;i<=l;i++)
    {
        if(s[i-1]=='?')
            dp[i]=1;

    }

     for(i=1;i<=l;i++)
    {

            dp[i]=dp[i-1]+dp[i];

    }

    for(i=1;i<=l;i++)
   {
       for(j=0;j<=25;j++)
         a[i][j]=a[i-1][j]+a[i][j];
   }

   f=0;

   for(i=1;;i++)
   {
       j=i+26-1;
       if(j>l)
         break;
       m=0;
       for(k=0;k<=25;k++)
       {
           if(a[j][k]-a[i-1][k]==0)
              m++;


       }
       if(m==dp[j]-dp[i-1])
       {
           f=1;
           break;
       }

   }

   if(f==0)
   {
       cout<<"-1";
       exit(0);
   }
   //cout<<i<<" "<<j<<endl;
   for(k=i-1;k<=j-1;k++)
   {
       if(s[k]=='?')
        continue;
       aa[s[k]-'A']=1;
       //cout<<s[k]-'A'<<endl;
   }
   for(k=0;k<=25;k++)
   {
       if(aa[k]==0)
         v.push_back(k);
   }


   //cout<<endl;
p=0;
//cout<<i<<endl;
   for(k=i-1;k<=j-1;k++)
   {
       if(s[k]=='?')
       {
           s[k]=(char)((int)('A')+v[p]);
           //v.pop_back();
           p++;
       }
   }

   for(i=0;i<l;i++)
   {
       if(s[i]=='?')
       {
           s[i]='A';
       }

   }


   cout<<s;







}
