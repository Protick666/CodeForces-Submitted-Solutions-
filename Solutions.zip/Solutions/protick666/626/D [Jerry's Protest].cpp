#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

ll dif[100000];
ll dp[100000];
ll a[100000];




int main() {
ll i,j,n,store,p,k,f,l,w,b,q;
double ans,sum;
ans=0;
cin>>n;
for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);
for(i=1;i<=n;i++)
{
    for(j=i+1;j<=n;j++)
    {
        if(i==j)
            continue;
        p=abs(a[i]-a[j]);
        dif[p]++;
    }
}

for(i=5000;i>=1;i--)
    dp[i]=dif[i]+dp[i+1];


q=n-1;
sum=q*(q+1)/2;

for(i=1;i<=5000;i++)
{
    for(j=1;j<=5000;j++)
    {
        if(dif[i]==0 || dif[j]==0)
            continue;
        q=i+j;
        q=dp[q+1];
        //cout<<i<<" "<<j<<" "<<dif[i]<<" "<<dif[j]<<" "<<q<<endl;


        ans=ans+(dif[i]/sum)*(dif[j]/sum)*(q/sum);

    }
}
printf("%.10lf", ans);
}
