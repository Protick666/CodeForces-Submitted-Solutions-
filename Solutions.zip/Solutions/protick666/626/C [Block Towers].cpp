#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;






main()
{
    int a,b,c,d,p,q,k,x,y,n,i;
    n=0;
    scanf("%d%d",&a,&b);
    x=a*2;
    y=b*3;
    if(x>=y)
    {
        d=b/2;
        p=(x-y)/3;

        if(x%3==0 && x!=y)
            p=p-1;
        //cout<<p<<endl;
        p=p/2+(((p%2==1)&&(y%2==0))?1:0);
        //cout<<p<<endl;
        p=d-p;
        if(p<=0)
            n=x;
        else
        {
            for(i=x+1;;i++)
            {
                if(i%3==0 || i%2==0)
                    p--;
                if(p==0)
                    break;

            }

            n=i;
        }


    }








    else
    {
        d=a/3;
        p=(y-x)/2;

       q=(y-(x-(x%3)))/3;
       if(q%2==1 && y%2==0)
         q=q/2+1;
       else
        q=q/2;
       //cout<<q<<endl;
       p=p-q;
       if(p<0)
        p=0;
        //cout<<p<<endl;
        //cout<<d<<"  "<<p<<endl;

        p=d-p;
        if(p<=0)
            n=y;
        else
        {
            //cout<<p<<endl;
              for(i=y+1;;i++)
            {
                if(i%3==0 || i%2==0)
                    p--;
                if(p==0)
                    break;

            }

            n=i;

        }


    }


 printf("%d",n);


}