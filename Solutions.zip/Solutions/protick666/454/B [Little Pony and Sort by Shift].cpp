#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll a[1000000];

int main() {

    ll i,j,k,n,ans,f;
  cin>>n;
  for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);


  f=1;

  for(i=2;i<=n;i++)
  {
      if(a[i]<a[i-1])
        break;

  }
  j=i;
  if(i==n+1)
    ans=0;
  else

  ans=n-i+1;

  if(i!=n+1)
  {
      if(a[n]>a[1])
        f=2;
      i++;
      for(;i<=n;i++)
      {if(a[i]<a[i-1])
        {   f=2;
            break;
        }


     }

  }


  if(f==2)
    cout<<"-1";
  else
    cout<<ans;

}
