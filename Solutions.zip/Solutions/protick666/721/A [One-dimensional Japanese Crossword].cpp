#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
ll len[1000];
ll a[1000];

main()
{
    ll n,i,j,k,l,p,x,y,t,q;
    cin>>n;

    string s;
    cin>>s;

    p=0;
    q=0;
    for(i=0;i<n;i++)
    {
        //cout<<s[i]<<endl;
        if(s[i]=='W')
        {
            p=0;


        }

        else if(p==0)
        {
            q++;
            a[q]=1;
            p=1;
        }
        else
        {
            a[q]++;
            //cout<<a[q]<<endl;
        }
        //cout<<q<<" "<<s<<endl;
    }

    cout<<q<<endl;

    for(i=1;i<=q;i++)
        cout<<a[i]<<" ";












}
