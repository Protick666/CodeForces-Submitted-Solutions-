#include<stdio.h>
main()
{


long long int p,q,x,y,movep,movev;

scanf("%I64d%I64d%I64d%I64d",&p,&q,&x,&y);
movep=p+q;
movev=x>=y?x:y;
if(p>=x && q>=y)
    printf("Vasiliy");

else if(x>=p && y>=q)
    printf("Polycarp");


else if(movev>=movep)

       printf("Polycarp");




else if(movev<movep)

       printf("Vasiliy");
















}
