#include <bits/stdc++.h>
#include <math.h>
using namespace std;
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

int main() {
    long long int n, m, p, q, r, l, mod;
    mod = 1000000007;
    cin>> n >> l >> r;
    long long int dp[n+1][4];
    long long int possibleValue[3];

    for(int i=0;i<3;i++)
    {
        possibleValue[i]=(r-i+3)/3-(l-i+2)/3;
    }

    for(int i = 0; i<=n; i++){
        for(int j = 0; j<=3; j++)
            dp[i][j] = 0;
    }

    dp[0][0] = 1;

    for(int i = 1; i <= n; i++){
        for(int dest = 0; dest<3; dest++){
            for(int source = 0; source<3; source++){
                long long int sum = (dest + source) % 3;
                long long int temp = (dp[i-1][source] * possibleValue[dest]) % mod;
                dp[i][sum] = (dp[i][sum] + temp) % mod;
            }
        }
    }

    cout<<dp[n][0];

}