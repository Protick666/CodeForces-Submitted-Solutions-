#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll dp[1000001][3];

int main() {

    ll i,j,k,r,a,b,c,x,d,y,sum,store,p,f,m,n,r1,c1,r2,c2,z;

    cin>>r>>c>>a>>b>>d>>p;

    for(i=1;i<=p;i++)
    {
        scanf("%I64d%I64d",&x,&y);
        dp[i][1]=x;
        dp[i][2]=y;
    }

    //cout<<r<<" "<<c<<"rc"<<endl;

    for(i=1;i<=p;i++)
    {
        //cout<<"dhuksi";
        x=dp[i][1];
        y=dp[i][2];
 //printf("%I64d %I64d\n",x,y);
        f=a%4;
        r1=r;
        c1=c;

        if(f==1)
        {
            r1=c;
            c1=r;
            z=x;
            x=y;
            y=c1-z+1;


        }

        else if(f==2)
        {
            x=r-x+1;
            y=c-y+1;


        }
        else if(f==3)
        {
            //cout<<"achi";
            r1=c;
            c1=r;
            z=x;
            x=y;
            y=c1-z+1;

            x=r1-x+1;
            y=c1-y+1;

        }



        if((b%2)==1)
        {
            y=c1-y+1;
        }


        f=d%4;


        r2=r1;
        c2=c1;

        if(f==3)
        {
            r2=c1;
            c2=r1;
            z=x;
            x=y;
            y=c2-z+1;


        }

        else if(f==2)
        {
            x=r1-x+1;
            y=c1-y+1;


        }
        else if(f==1)
        {
            //cout<<"achi";
            r2=c1;
            c2=r1;
            z=x;
            x=y;
            y=c2-z+1;

            x=r2-x+1;
            y=c2-y+1;

        }






      printf("%I64d %I64d\n",x,y);

    }




}
