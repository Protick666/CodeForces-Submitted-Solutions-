#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

ll bin[1000000];
ll s[1000000];
ll d[1000000];

ll a[1000000];
vector<ll> ans;
ll t,q;

map<ll,ll> val;

ll check()
{
    ll x,y,i,j,m;
    x=1;y=q;
    while(1)
    {
    //cout<<t<<endl;
        m=(x+y)/2;
        if(bin[m]<=t && bin[m+1]>t)
        {
            j=t-bin[m]+1;
            j=j%s[m];
            if(j==0)
                j=s[m];
            return a[j];


        }
        else if(bin[m]>t)
        {
            y=m-1;
            cont;
        }
        else
        {
            x=m+1;
            cont;

        }
    }
}

//x pos,y neg,temp pos a, temp neg b
int main()
{
  ll i,j,l,m,n,sum,z,k,x,y,r,p,f;
  t=0;
  cin>>m;
  p=1;
  q=1;
  for(i=1;i<=m;i++)
  {
      in1(f);
      if(f==1)
      {
          in1(x);
          val[p]=x;
          if(t==0)
          {
              a[p]=x;
              p++;
              if(p>=100001)
                t=1;
          }
          else
            p++;

      }
      else
      {
          in2(x,y);
          bin[q]=p;
          s[q]=x;
          d[q]=y;
          q++;

          if(t==0)
          {
              l=1;
              for(j=p;j<=p+x*y-1;j++)
              {
                 a[j]= a[l];
                 l++;
                 if(l>x)
                    l=1;
                 if(j>100001)
                 {
                     t=1;
                     break;
                 }
              }
          }
          p=p+x*y;

      }

    //cout<<p<<endl;
  }
  q--;
  bin[q+1]=10000000000000000;

  //cout<<"q "<<q<<endl;
  //for(i=1;i<=16;i++)
     //cout<<a[i]<<" ";


  cin>>n;

  for(i=1;i<=n;i++)
  {
      in1(t);
      if(val[t]!=0)
        ans.pb(val[t]);
      else
        ans.pb(check());
  }

  for(i=0;i<ans.size();i++)
  {
      printf("%I64d ",ans[i]);
  }
}
