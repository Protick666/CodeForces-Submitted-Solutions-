#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;



main()
{

long long int s,a,b,n,i,j,aa,bb,fa,f,fb,l,p,q,k,z,d,r,w,flag,m,sum,e;
cin>>m;
long long int x[m];
for(i=0;i<m;i++)
{
    scanf("%I64d",&x[i]);
}
cin>>n;
long long int y[n];
for(i=0;i<n;i++)
{
    scanf("%I64d",&y[i]);
}

sort(x,x+m);
sort(y,y+n);

a=m*2;
b=n*2;
s=a-b;

if(m*3-n*3>s)
{
    s=m*3-n*3;
    a=m*3;
    b=n*3;
}
else if(m*3-n*3==s)
{

    a=m*3;
    b=n*3;
}
j=0;
for(i=0;i<m;i++)
{
    if(i!=m-1 && x[i]==x[i+1])
        continue;
    if(j==n)
    {
          p=(i+1)*2;
    p=p+(m-i-1)*3;
    q=n*2;
    sum=p-q;
    if(sum>s)
    {
        s=sum;
        a=p;
        b=q;


    }

    else if(sum==s && p>a)
    {

        a=p;
        b=q;


    }

        continue;
    }



    while(x[i]>=y[j])
        {   j++;
          if(j==n)
             break;

        }
    p=(i+1)*2;
    p=p+(m-i-1)*3;
    q=j*2+(n-j)*3;
    sum=p-q;
    if(sum>s)
    {
        s=sum;
        a=p;
        b=q;


    }

    else if(sum==s && p>a)
    {

        a=p;
        b=q;


    }





}

//cout<<a<<":"<<b<<endl;







j=0;
for(i=0;i<n;i++)
{

    if(i!=n-1 && y[i]==y[i+1])
        continue;
    if(j==m)
    {
          q=(i+1)*2;
    q=q+(n-i-1)*3;
    p=m*2;
    sum=p-q;
    if(sum>s)
    {
        s=sum;
        a=p;
        b=q;


    }

    else if(sum==s && p>a)
    {

        a=p;
        b=q;


    }

        continue;
    }



    while(y[i]>=x[j])
        {   j++;
          if(j==m)
             break;

        }
    q=(i+1)*2;
    q=q+(n-i-1)*3;
    p=j*2+(m-j)*3;
    sum=p-q;
    if(sum>s)
    {
        s=sum;
        a=p;
        b=q;



    }

    else if(sum==s && p>a)
    {

        a=p;
        b=q;


    }





}


cout<<a<<":"<<b;


}
