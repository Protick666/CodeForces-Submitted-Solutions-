#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
ll a[1000001];
ll b[1000001];
ll c[1000001];
ll vis[10000001];
main()
{
    ll i,j,k,l,m,r,n,c,ans,sum,x,y,z,p,f,q;
    cin>>n>>k;
    //l=0;

    for(i=0;i<=n-1;i++)
      {scanf("%I64d",&x);
        //cout<<x<<" "<<i<<endl;
       b[i]=x;

      }
      //sort(a,a+l);
      sort(b,b+n);
      sum=0;

      for(i=n;i>=1;i--)
        b[i]=b[i-1];


//cout<<l;
 i=1;
 l=1;
 while(1)
 {
     if(i>n)
        break;
     j=i;

     while(b[j]==b[i] && j<=n)
     {
         j++;
     }
     j--;
     a[l]=b[i];
     vis[l]=j-i+1;
     l++;
     i=j+1;

 }

 l--;

 for(i=1;i<=l;i++)
 {


     if(vis[i]*n<k)
     {
         k-=vis[i]*n;
         continue;
     }

     p=k/vis[i];
     q=k%vis[i];
     if(q==0)
     {
         cout<<a[i]<<" "<<b[p];
         break;
     }

     else
     {
         cout<<a[i]<<" "<<b[p+1];
         break;

     }
 }





}
