#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

map <long long int,long long int> m;

map<long long int, vector<long long int> > v;









main()
{

    long long int i,flag,j,k,l,n,o,sum,q,a,b,store;
    cin>>n;
    long long int fin[n+1];

    for(i=1;i<=n;i++)
    {
        scanf("%I64d",&store);
        m[store+1]=m[store+1]+1;
        v[store+1].push_back(i);


    }

    a=0;
    flag=0;

    for(i=1;i<=n;i++)
    {
        if(m[a+1]>0)
        {
            fin[i]=v[a+1].back();
            v[a+1].pop_back();
            m[a+1]--;
            a=a+1;
        }

        else
        {
            while(1)
            {
                //cout<<a;
                a=a-3;
                if(a<0)
                {

                    flag=1;
                    break;
                }
                else if(m[a+1]>0)
               {

                   fin[i]=v[a+1].back();
                   v[a+1].pop_back();
                   m[a+1]--;
                    a=a+1;
                    break;
                }

            }





        }


    }

    if(flag==1)
        cout<<"Impossible";
    else{
        cout<<"Possible\n";
        for(i=1;i<=n;i++)
            printf("%I64d ",fin[i]);



    }



}














