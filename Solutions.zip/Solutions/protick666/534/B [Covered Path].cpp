#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int


ll ans[1000000];
main()
{
     //cout<<"bal";

    ll u,v,n,i,j,k,l,sum,t,d,p,store;

    cin>>u>>v;
    cin>>t>>d;

    ans[1]=u;
    ans[t]=v;

    sum=u;

    for(i=2;i<=t-1;i++)
    {
        p=t-i;
        store=sum;
        if(sum-p*d<=v)
        {
            while(sum-p*d<=v)
                sum++;
            sum=sum-1;
            if(sum-store>d)
                sum=store+d;
            ans[i]=sum;
            store=sum;


        }

        else
        {
            while(sum-p*d>v)
                sum--;
            if(store-sum>d)
                sum=store-d;
            ans[i]=sum;
            store=sum;

        }




    }
    sum=0;

    for(i=1;i<=t;i++)
        sum+=ans[i];
    cout<<sum;


}
