#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007

ll dp[50001][501];
ll ans,k;
ll vis[50001];
ll leaf[50001];
ll par[50001];
vector <ll> v[50001];
ll len[50001];

queue <ll> q;
ll call(ll a)
{
    ll x,y,i,j,sum,p,l;
    ans+=dp[a][k];
    sum=0;

    for(i=1;i<=k;i++)
    {
        x=i;
        y=k-i;
        if(x>y)
            break;
        x--;
        y--;
        if(x==0 && y==0)
        {
            l=dp[a][1];
            ans+=l*(l-1)/2;
            continue;

        }
        else if(x==y)
        {

        for(j=0;j<len[a];j++)
        {
            p=v[a][j];
            if(p==par[a])
                continue;


            else
            {
                ans+=dp[p][x]*(dp[a][y+1]-dp[p][y]-sum);
                sum+=dp[p][x];

            }



        }

           continue;

        }

        for(j=0;j<len[a];j++)
        {
            p=v[a][j];
            if(p==par[a])
                continue;

            if(x==0)
            {
                ans+=dp[a][y+1]-dp[p][y];

            }
            else
            {
                ans+=dp[p][x]*(dp[a][y+1]-dp[p][y]);

            }



        }
    }

//cout<<a<< " "<<ans<<endl;
    for(i=0;i<len[a];i++)
    {
        p=v[a][i];
        if(p==par[a])
            continue;
        call(p);
    }






}

void complete( ll a)
{

    ll p, i,j;

    for(i=0;i<len[a];i++)
    {
        p=v[a][i];
        if(p==par[a])
            continue;
        complete(p);
    }

    for(i=0;i<len[a];i++)
    {
        p=v[a][i];
        if(p==par[a])
            continue;
        dp[a][1]++;

        for(j=1;j<=499;j++)
        {
            if(dp[p][j]!=0)
            {
                dp[a][j+1]+=dp[p][j];

            }
        }
    }

}

void dfs(ll a)
{
    ll p,i;


    for(i=0;i<len[a];i++)
    {
        p=v[a][i];
        if(vis[p]!=1)
        {
            vis[p]=1;
            leaf[a]=1;
            par[p]=a;
            dfs(p);

        }

    }

}

int main()
{
   ll n,i,j,x,y,sum,p,r;
   ans=0;

   cin>>n>>k;

   for(i=1;i<n;i++)
   {
       scanf("%I64d%I64d",&x,&y);
       v[x].push_back(y);
       v[y].push_back(x);
       len[x]++;
       len[y]++;
   }
   vis[1]=1;
   dfs(1);

   for(i=1;i<=n;i++)
     vis[i]=0;


    complete(1);


/*for(i=1;i<=n;i++)
  {

    for(j=1;j<=k;j++)
    {
        cout<<dp[i][j]<<" ";
    }

    cout<<endl;
  }*/

    call(1);


cout<<ans;

}
