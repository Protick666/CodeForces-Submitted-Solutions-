#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 1000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
map<string,ll > vis;
map<string,ll > has;

vector<string> vv;
ll p[1000009];
//ll has[1000009];

vector<ll> v[1000006];

ll ck(string s)
{

    ll i,j;
    i=0;
    j=s.length()-1;
    while(i<=j)
    {
        if(s[i]!=s[j])
            return 0;
        i++;
        j--;
    }
    return 1;
}
main()
{
    ll i,j,k,q,m,sum,t,n,ans;
    string s;
    cin>>n>>k;
     char ch[1000006];
    t=1;
    fr(i,1,n)
    {
       scanf("%s",ch);
       s=ch;
       cin>>q;
       if(vis[s]==0)
       {
           vis[s]=1;
           vv.pb(s);
           has[s]=t;
           t++;
           v[t-1].pb(q);
       }
       else
       {
           ll g=has[s];
           v[g].pb(q);

       }
    }


    for(i=0;i<=1000002;i++)
    {
        v[i].pb(-maxx);
        v[i].pb(-maxx);
    }
    //cout<<"here1";

    for(i=0;i<=1000002;i++)
    {
        sort(all(v[i]));
    }
    //cout<<"here2";
    for(i=0;i<=1000002;i++)
    {
        p[i]=v[i].size()-1;
    }
    //cout<<"here3";

    sum=0;
     ans=0;
    string x,y;
    for(i=0;i<vv.size();i++)
    {
        x=vv[i];
        char tt[1000009];
        j=0;
        ll u;
        for(u=x.length()-1;u>=0;u--,j++)
        {
            tt[j]=x[u];
        }
        tt[j]='\0';
        y=tt;

        ll a,b,w,e;
        a=has[x];
        b=has[y];
        //cout<<x<<" "<<y<<endl;
        w=v[a][p[a]];
         p[a]--;
        e=v[b][p[b]];
         p[b]--;
        ll temp=w+e;
        //cout<<"temp "<<temp<<endl;
        while(temp>0)
        {
            //cout<<"dhuke gesi";
            sum+=temp;
            if(w<0)
            {
                ll yy=ck(y);
                if(yy==1)
                    ans=min3(w,e,ans);
            }
            else if(e<0)
            {
                ll yy=ck(x);
                if(yy==1)
                    ans=min3(w,e,ans);

            }
            //ans=min3(w,e,ans);

            w=v[a][p[a]];
           p[a]--;
           e=v[b][p[b]];
           p[b]--;
            temp=w+e;
        }
         p[a]++;
         p[b]++;

    }

    m=0;
    for(i=0;i<vv.size();i++)
    {
        s=vv[i];
        if(ck(s)==0)
            cont;
        ll qq=has[s];

        m=max(m,v[qq][p[qq]]);
    }
    m=max(m,abs(ans));
    sum+=m;
    cout<<sum;

}
