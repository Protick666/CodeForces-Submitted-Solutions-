#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll val[10000];
vector<pair<ll,ll> > a;
pair<ll,ll> p;
vector<ll> v[10000];
ll z,d;
ll vis[10000];
ll done[10000];

ll dfs(ll t)
{
    ll i,j,ans,k;
    vis[t]=1;
    ans=1;
    for(j=0;j<v[t].size();j++)
    {
        k=v[t][j];
        if(vis[k]!=1 && done[k]!=1 && (z-val[k])<=d)
        {
            ans=(ans*(dfs(k)+1))%modd;
        }
    }
    return ans;

}
int main()
{


    ll n,m,x,y,sm,ans,t,i,j;
    cin>>d>>n;
    loop(i,n)
    {
        cin>>val[i+1];
        p=mp(val[i+1],i+1);
        a.pb(p);
    }
    sort(all(a));
    loop(i,n-1)
    {
        cin>>x>>y;
        v[x].pb(y);
        v[y].pb(x);
    }
    ans=0;
    for(i=a.size()-1;i>=0;i--)
    {
        p=a[i];

        x=p.second;
        done[x]=1;
        for(j=1;j<=n;j++)
        {
            vis[j]=0;
        }
        z=val[x];
        ans=(ans+dfs(x))%modd;
    }

    cout<<ans;

}
