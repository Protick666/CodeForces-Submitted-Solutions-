#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

long long int vis[100001];

main()
{

long long int p,n,i,j,pf,af,aa,bb,fa,f,fb,t,l,q,k,z,r,w,x,y,flag,sum,e,val;
char c,a,b,d;
cin>>n>>p;
f=-1;
e=-1;


if(p>n/2)
    p=n-p+1;
char str[n+1];
scanf("%s",str);
sum=0;
for(i=0;i<n/2;i++)
{
    j=n-i-1;
    if(str[i]==str[j])
    {
        vis[i+1]=0;

    }
else
{
    if(f==-1)
        f=i+1;
    if(i+1>e)
        e=i+1;

    if(str[i]<str[j])
    {
        b=str[j];
        a=str[i];
    }
    else
     {
        a=str[j];
        b=str[i];
    }

    l=min(b-a,(a-'a')+('z'-b)+1);
    vis[i+1]=l;
    sum=sum+l;


}



}
//cout<<f<<" "<<e<<" "<<sum<<" "<<p<<endl;
if(sum==0)
{
    cout<<"0";
    exit(0);
}

if(n%2==1 && p==n/2+1)
    l=n/2-(f);
else
{
    if(p<f)
        l=e-p;
    else if(p>e)
        l=p-f;
    else{
    t=MAX(p-f,e-p);
      q=MIN(p-f,e-p);
    l=2*q+t;
    //cout<<t<<" "<<q<<endl;


    }


}
sum=sum+l;
cout<<sum;




}

