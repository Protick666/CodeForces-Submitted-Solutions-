#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000


int main()
{
   ll n,i,j,k,l,sum,ans,z,x,y,w1,w2,d1,d2,e,d;
   cin>>n;
   x=n/7;

   y=n%7;

   string s="ROYGBIV";

   for(i=1;i<=x;i++)
    cout<<s;

   if(y>=4)
   {
       i=0;
       while(y!=0)
       {
           cout<<s[i];
           i++;
           y--;
       }


   }

   if(y<4)
   {
       i=3;
       while(y!=0)
       {
           cout<<s[i];
           i++;
           y--;
       }


   }






}
