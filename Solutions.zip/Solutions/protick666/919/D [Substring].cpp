#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;

#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define MOD 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
class Graph
{
    int V;    // No. of vertices
    list<int> *adj;    // Pointer to an array containing adjacency lists
    bool isCyclicUtil(int v, bool visited[], bool *rs);  // used by isCyclic()
public:
    Graph(int V);   // Constructor
    void addEdge(int v, int w);   // to add an edge to graph
    bool isCyclic();    // returns true if there is a cycle in this graph
};

Graph::Graph(int V)
{
    this->V = V;
    adj = new list<int>[V];
}

void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w); // Add w to v’s list.
}

// This function is a variation of DFSUytil() in https://www.geeksforgeeks.org/archives/18212
bool Graph::isCyclicUtil(int v, bool visited[], bool *recStack)
{
    if(visited[v] == false)
    {
        // Mark the current node as visited and part of recursion stack
        visited[v] = true;
        recStack[v] = true;

        // Recur for all the vertices adjacent to this vertex
        list<int>::iterator i;
        for(i = adj[v].begin(); i != adj[v].end(); ++i)
        {
            if ( !visited[*i] && isCyclicUtil(*i, visited, recStack) )
                return true;
            else if (recStack[*i])
                return true;
        }

    }
    recStack[v] = false;  // remove the vertex from recursion stack
    return false;
}

// Returns true if the graph contains a cycle, else false.
// This function is a variation of DFS() in https://www.geeksforgeeks.org/archives/18212
bool Graph::isCyclic()
{
    // Mark all the vertices as not visited and not part of recursion
    // stack
    bool *visited = new bool[V];
    bool *recStack = new bool[V];
    for(int i = 0; i < V; i++)
    {
        visited[i] = false;
        recStack[i] = false;
    }

    // Call the recursive helper function to detect cycle in different
    // DFS trees
    for(int i = 0; i < V; i++)
        if (isCyclicUtil(i, visited, recStack))
            return true;

    return false;
}
ll ans=0;
vector<ll> v[1000000];
ll mama[1000000];
ll pos[1000000];
ll vis[1000000];
//vector<ll> v[1000000];
vector<ll> top;
ll dp[300002][27];
ll val[300002];
void dfs(ll p)
{
    vis[p]=1;
    for(int i=0;i<v[p].size();i++)
    {
        ll h=v[p][i];
        if(vis[h]==0)
            dfs(h);
    }
    top.pb(p);
}

void dfs1(ll p)
{
    vis[p]=1;
    for(int i=0;i<v[p].size();i++)
    {
        ll h=v[p][i];
        if(vis[h]==0)
        {

                       //cout<<"from "<<p<<"to "<<h<<endl;

            dfs1(h);

        }
         for(int j=0;j<26;j++)
                 dp[p][j]=max(dp[p][j],dp[h][j]);
    }
    //cout<<"end of "<<p<<endl;
    //top.pb(p);

    //cout<<p<<" val"<<val[p]<<endl;
    dp[p][val[p]]++;
}

bool cmp(const ll x,const ll y)
{
    return pos[x]>pos[y];
}
int main()
{
    // Create a graph given in the above diagram
    ll i,j,k,l,m,n,x,y;
    cin>>n>>m;
    Graph g(n);
    char ch[1000000];
    scanf("%s",ch);
    string s=ch;
    for(i=1;i<=n;i++)
        val[i]=s[i-1]-'a';

    fr(i,1,m)
    {
        cin>>x>>y;
         v[x].pb(y);
        mama[y]=1;
        g.addEdge(x-1, y-1);

    }


    if(g.isCyclic())
        {
            cout << "-1";
            ex;
        }

    for(i=1;i<n;i++)
    {
        if(vis[i]==0)
            dfs(i);
    }

    fr(i,1,n)
      vis[i]=0;
   // for(i=0;i<top.size();i++)
   // {
       // cout<<top[i]<<" ";
       // pos[top[i]]=i;
   // }

    //cout<<endl;
    for(i=1;i<=n;i++)
    {
        sort(v[i].begin(),v[i].end(),cmp);
    }

    for(i=1;i<=n;i++)
    {
        if(vis[i]!=0)
            cont;
        //cout<<"strat from"<<i<<endl;

            dfs1(i);
        //cout<<endl;
    }

    for(i=1;i<=n;i++)
    {
        for(j=0;j<26;j++)
            ans=max(ans,dp[i][j]);
    }

    cout<<ans;


}