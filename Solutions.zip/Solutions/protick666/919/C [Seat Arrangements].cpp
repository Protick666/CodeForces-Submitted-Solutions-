#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;

#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define MOD 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
ll dp[2002][2002];
int main()
{
    ll i,j,k,l,m,n,a,b,c,t,tit,z,x;
    cin>>n>>m>>k;
    fr(i,1,n)
    {
        char ch[5001];
        scanf("%s",ch);
        string s=ch;
        for(t=0;t<s.length();t++)
        {
            if(s[t]=='.')
                dp[i][t+1]=1;

        }
    }
    ll sum=0;
    //cout<<"tit"<<endl;
    for(i=1;i<=n;i++)
    {
       // cout<<i<<endl;
        j=1;
        while(j<=m)
        {
           // cout<<j<<endl;
            if(dp[i][j]==0)
                {
                    j++;
                    cont;
                }
            x=j;
            while(dp[i][x]==1)
            {
                x++;
                if(x>m)
                {
                    //x--;
                    break;
                }

            }
            x--;
            //cout<<x<<" x"<<endl;
            ll len=x-j+1;
            if(len>=k)
            {
                sum+=len-k+1;
            }
            j=x+1;

        }
    }
    
    if(k==1)
    {
        cout<<sum;
        ex;
    }


    //cout<<sum<<endl;
    for(i=1;i<=m;i++)//i col no
    {
        j=1;
        while(j<=n)
        {
            if(dp[j][i]==0)
                {
                    j++;
                    cont;
                }
            x=j;
            while(dp[x][i]==1)
            {
                x++;
                if(x>n)
                {
                    //x--;
                    break;
                }

            }
            x--;
            ll len=x-j+1;
            if(len>=k)
            {
                sum+=len-k+1;
            }
            j=x+1;

        }
    }


    cout<<sum;






}