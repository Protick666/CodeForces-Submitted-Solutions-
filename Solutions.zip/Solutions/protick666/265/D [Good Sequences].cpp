#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll dp[1000000];
vector<ll> v[100002];
ll len[100001];
ll a[100001];
int main() {


ll i,j,k,l,n,sum,ans,p,q;

for(i=2;i<=100000;i++)
    a[i]=i;
for(i=2;i<=100000;i++)
{
    if(a[i]==i)
    {
        v[i].push_back(i);
        len[i]++;


    for(j=2;;j++)
    {
        q=i*j;
        if(q>100000)
            break;

            a[q]=a[q]/i;
            len[q]++;
            v[q].push_back(i);



    }

    }
}


cin>>n;
for(i=1;i<=n;i++)
{
    scanf("%I64d",&a[i]);
}
ans=0;
for(i=1;i<=n;i++)
{
    p=a[i];
    if(p==1)
        continue;
    sum=-1;
    for(j=0;j<len[p];j++)
    {
        q=v[p][j];
        if(dp[q]>sum)
            sum=dp[q];


    }
    sum++;
    if(sum>ans)
        ans=sum;
    for(j=0;j<len[p];j++)
    {
        q=v[p][j];
        dp[q]=sum;


    }





}
if(ans==0)
    ans++;
cout<<ans;

}
