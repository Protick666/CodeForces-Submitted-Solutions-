#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

//ll a[1000004];

int main()
{
    double n,i,j,k,l,sum,ans,z,x,y,w1,w2,d1,d2;
    cin>>x>>y>>z>>l;
    w1=x/y;
    d1=1-w1;
    d2=1-(z/l);
    sum=d1*d2;

    ans=0;
    ans+=w1;

    for(i=1;i<=1000000;i++)
    {
        ans+=sum*w1;
        sum=sum*d1*d2;
    }
    std::cout << std::fixed;
    std::cout << std::setprecision(10);

    cout<<ans;

}
