#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007





int main()
{
   ll n,i,j,x,y,sum,p,r,q,m;
   cin>>n>>m;
   x=0;
   y=0;
   p=(n-1)*n/2;

   if(p<=m)
   {
       cout<<"no solution";
   }
   else
   {
       for(i=1;i<=n;i++)
       {
           cout<<x<<" "<<y<<endl;
           y++;
       }
   }


}
