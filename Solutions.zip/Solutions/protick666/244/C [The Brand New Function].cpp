
#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>


using namespace std;
//vector<pair<int,int> > bichi;
int vis[10000000];
int  j,n,p,q,r,l,x,y,z,ans,k;
int a[10000000];
vector< int> v;

int main ()
{
  std::set<int> myset;
  std::set<int>::iterator i;
  //std::pair<std::set<int>::iterator,bool> ret;
//myset.insert(1000);
  // set some initial values:
  //for (int i=1; i<=5; ++i) myset.insert(i*10);    // set: 10 20 30 40 50

  //ret = myset.insert(4);
    //it=myset.begin();
  //it++;
  //std::cout << ' ' << *it;




  cin>>n;

  for(j=1;j<=n;j++)
    scanf("%d",&a[j]);


    for(j=1;j<=n;j++)
    {
        //l=0;
        x=a[j];
        if(j==1)
        {

            myset.insert(x);
            vis[x]++;
            ans++;
            continue;
        }
        y=myset.size();

        i=myset.begin();
        for(k=1;k<=y;k++)
        {
            p=*i;
            q=p|x;
            v.push_back(q);
            i++;
            //l++;

        }
        myset.clear();

        for(k=y-1;k>=0;k--)
        {
            p=v[k];
            myset.insert(p);
            if(vis[p]==0)
            {
                ans++;
                vis[p]=1;
            }

            v.pop_back();

        }
        myset.insert(x);

        if(vis[x]==0)
        {
            vis[x]=1;
            ans++;
        }





    }

cout<<ans;
  return 0;
}
