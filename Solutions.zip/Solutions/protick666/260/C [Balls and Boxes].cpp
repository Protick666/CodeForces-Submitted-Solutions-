#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
ll a[1000000];
ll b[1000000];
int main()
{
    ll i,j,k,n,m,x,y,ans,sum,p,q,t;
    cin>>n>>k;
    sum=1000000000000;
    for(i=1;i<=n;i++)
    {
        cin>>x;
        sum=min(sum,x);
        a[i]=x;
    }

    i=k;
    //sum=0;
    ans=0;
       // cout<<sum<<endl;

    while(a[i]!=sum)
    {
        i--;
        ans++;
        if(i==0)
            i=n;
    }

    x=1;
    y=x+ans;
    j=i;
    if(i==1)
        q=1;
    else
        q=n-i+2;
    for(t=1;t<=n;t++)
    {
        b[t]=a[j];
        j++;
        if(j==n+1)
            j=1;
    }
    t=b[1];
    for(i=1;i<=n;i++)
    {
        b[i]-=t;

    }

    for(i=2;i<=y;i++)
    {
        b[i]-=1;

    }
    b[1]+=t*n+y-1;

    for(i=1;i<=n;i++)
    {
        cout<<b[q]<<" ";
        q++;
        if(q==n+1)
            q=1;
    }





}










