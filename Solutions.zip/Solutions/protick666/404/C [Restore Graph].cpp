#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define co continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity


vector < pair<ll,ll> > v;
vector <pair<ll,ll>  > ans;
pair <ll,ll> p,q;
ll cap[10000001];
void fail()
{
    cout<<"-1";
    ex;
}
int main()
{
    ll n,k,i,j,l,sum,x,y,f,a,b,c,d;
    cin>>n>>k;
    f=0;
      for(i=1; i<=n; i++)
    {
        cin>>l;
        p=mp(l,i);
        v.pb(p);
        if(l==0)
            f=1;
    }

    if(f==0)
    {
        fail();
    }
    sort(v.begin(),v.end());
    x=0;
    y=1;
    while(1)
    {
        if(y==n)
            break;

        a=v[x].fi;
        b=v[x].se;
        c=v[y].fi;
        d=v[y].se;
        if(a==c)
            fail();
        if(c!=a+1)
        {
            x++;
            co;
        }

        else if(cap[b]<k)
        {
            cap[b]++;
            cap[d]++;
            q=mp(b,d);
            ans.pb(q);
            y++;
            co;
        }
        else
        {
            x++;
            co;
        }

     }

     cout<<ans.size()<<endl;
     for(i=0;i<ans.size();i++)
        cout<<ans[i].fi<<" "<<ans[i].se<<endl;





}
