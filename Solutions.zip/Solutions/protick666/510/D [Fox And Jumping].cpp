#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 4000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
ll cost[1000];
ll a[1000];
ll dp[301][1<<9];
ll n,z;
ll m[1000];
ll vis[1<<9];
ll dpp()
{
    ll i,j,k,sum,p,x,y;
    sum=maxx;

    for(i=0; i<=n; i++)
    {
        for(j=0; j<(1<<9); j++)
            dp[i][j]=maxx;
    }
    for(j=0;j<(1<<9); j++)
        vis[j]=maxx;

    for(i=1; i<=n; i++)
    {
        if(i==z)
            continue;
        p=m[i];
        for(j=0; j<(1<<9); j++)
        {

            y=p&j;
            dp[i][y]=vis[j]+cost[i];

            vis[y]=min(vis[y],dp[i][y]);
        }
        vis[p]=min(vis[p],cost[i]);
    }

    return vis[0];
}
main()
{
    ll i,j,k,l,t,ans,x,y;
    ans=maxx;

    cin>>n;
    for(i=1; i<=n; i++)
        cin>>a[i];

    for(i=1; i<=n; i++)
        cin>>cost[i];

    for(i=1; i<=n; i++)
    {
        vector <ll> v;
        if(a[i]==1)
        {
            ans=min(ans,cost[i]);
            continue;
        }
        t=a[i];
        for(j=2; j*j<=t; j++)
        {
            if((t%j)==0)
                v.pb(j);
            while((t%j)==0)
                t=t/j;

        }
        if(t!=1)
            v.pb(t);

        for(j=1; j<=n; j++)
        {
            x=a[j];
            for(k=0; k<v.size(); k++)
            {
                y=v[k];
                if((x%y)==0)
                {
                    m[j]|=1<<k;
                }
            }

        }
        z=i;
        ans=min(ans,dpp()+cost[i]);

        for(j=1; j<=n; j++)
        {
            m[j]=0;

        }



    }

    if(ans>=maxx)
        cout<<"-1";
    else
        cout<<ans;



}
