#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll dp[1000000];

int main() {

    ll i,j,k,l,n,q,x,f,m,store,sum,p;
    sum=0;
double  y;
    cin>>n>>m;

    ll a[n+1];
    for(i=1;i<=n;i++)
    {
        scanf("%I64d%lf",&x,&y);
        a[i]=x;
    }




    for(i=1;i<=n;i++)
    {
        if(i==1)
            {dp[i]=1;

            if(dp[i]>sum)
            sum=dp[i];
            continue;

            }

        store=0;
        p=a[i];
        for(j=1;j<i;j++)
        {
            if(a[j]<=p)
            {
                if(dp[j]>store)
                    store=dp[j];

            }

        }
        dp[i]=store+1;
        if(store+1>sum)
            sum=store+1;





    }

    cout<<n-sum;

    return 0;





}
