#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%lld ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265






int main()

{

    ll n,i,j,k,m,x,y,d;

    vector<string> v;
    v.pb("purple");

    v.pb("green");
    v.pb("blue");
    v.pb("orange");
    v.pb("red");
    v.pb("yellow");
    //purple, green, blue, orange, red, yellow
    map<string,int> mymap;



   map<string,string> pos;
    pos["purple"]="Power";
    pos["green"]="Time";
    pos["blue"]="Space";
    pos["orange"]="Soul";
    pos["red"]="Reality";
    pos["yellow"]="Mind";


    cin>>n;

    fr(i,1,n)
    {
        string s;
        cin>>s;
        mymap[s]=1;
    }
    ll sum=0;
    fr(i,0,5)
    {
        if(mymap[v[i]]==0)
            sum++;
    }

    cout<<sum<<endl;

    fr(i,0,5)
    {
        if(mymap[v[i]]==0)
            cout<<pos[v[i]]<<endl;
    }





}






