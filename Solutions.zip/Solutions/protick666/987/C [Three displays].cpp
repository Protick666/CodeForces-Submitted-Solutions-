#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%lld ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265




ll dp1[10000];
ll dp2[10000];
ll dp3[10000];
ll val[10000];
ll s[10000];

int main()

{

    ll i,j,k,n,p,x,y;

    cin>>n;
    fr(i,1,n)
    {
        in(x);
        s[i]=x;
        //dp1[i]=x;
    }

    fr(i,1,n)
    {
        in(x);
        val[i]=x;
        dp1[i]=x;
    }

    fr(i,1,n)
      dp2[i]=-1;

    fr(i,1,n)
    {
        fr(j,1,i-1)
        {
            if(s[j]>=s[i])
                cont;
            if(dp2[i]==-1)
                dp2[i]=val[i]+val[j];
            else
                dp2[i]=min(dp2[i],val[i]+val[j]);
        }
    }

    fr(i,1,n)
      dp3[i]=-1;

    fr(i,1,n)
    {
        fr(j,1,i-1)
        {
            if(s[j]>=s[i])
                cont;
            if(dp2[j]==-1)
                cont;
            if(dp3[i]==-1)
                dp3[i]=val[i]+dp2[j];
            else
                dp3[i]=min(dp3[i],val[i]+dp2[j]);
        }
    }

    ll ans=-1;

    fr(i,1,n)
    {
        if(dp3[i]==-1)
            cont;
        if(ans==-1)
            ans=dp3[i];
        else
            ans=min(ans,dp3[i]);
    }

    cout<<ans;


}






