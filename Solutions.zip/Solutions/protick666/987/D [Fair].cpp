#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%lld ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265




ll vis[102][100002];
ll dist[102][100002];
vector<ll> alldist[100002];
ll col[100002];
vector<ll> v[100002];

vector<ll> which[500];

int main()
{
 //ssdist
    ll n,m,k,i,s,j,x,y;



    cin>>n>>m>>k>>s;

    for(i=1;i<=k;i++)
    {
        for(j=0;j<=n;j++)
            dist[i][j]=100000000000000000;
    }
    fr(i,1,n)
    {
        in(col[i]);
        which[col[i]].pb(i);
    }

    fr(i,1,m)
    {
        in2(x,y);
        v[x].pb(y);
        v[y].pb(x);
    }

    for(i=1; i<=k; i++) ////i=col
    {
        queue<ll > myq;
       for(j=0;j<which[i].size();j++)
       {
           ll temp=which[i][j];
           myq.push(temp);
           dist[i][temp]=0;
           vis[i][temp]=1;
       }

       while(myq.size()>0)
       {
           x=myq.front();
           myq.pop();
           for(j=0;j<v[x].size();j++)
           {
               ll cand=v[x][j];
               if(vis[i][cand]==1)
                cont;

                myq.push(cand);
                dist[i][cand]=dist[i][x]+1;
                vis[i][cand]=1;
          }

       }
    }

    for(i=1;i<=n;i++)
    {
        vector<ll> h;

        for(j=1;j<=k;j++)
            h.pb(dist[j][i]);
        sort(all(h));
        ll sum=0;
        for(j=0;j<s;j++)
            sum+=h[j];

        printf("%I64d ",sum);
    }

    /*
    ll vis[102][100002];
    ll dist[102][100002];
    vector<ll> alldist[100002];
    ll col[100002];
    vector<ll> v[100002];
    vector<ll> which[500];

    */





}






