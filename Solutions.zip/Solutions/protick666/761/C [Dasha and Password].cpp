#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 1000000007
#define ex  exit(0)

vector<ll> v1;
vector<ll> v2;\
ll m,i,j;
ll dg[1000];
ll ch[1000];
ll sg[1000];
ll ckdg(string s)
{
    ll t=maxx;
    for(i=0;i<m;i++)
    {
        j=(int)(s[i]);
        //cout<<j<<" "<<i<<endl;
        if(j>=48 && j<=57)
        {
            t=min(t,min(i,m-i));
            //cout<<t<<endl;
        }
    }
    //cout<<s<<" "<<t<<endl;
    return t;

}
ll cksg(string s)
{
    ll t=maxx;
    for(i=0;i<m;i++)
    {
       // '#', '*' or '&'
        if(s[i]=='#' || s[i]=='*' || s[i]=='&')
        {
             t=min(t,min(i,m-i));
        }
    }
    return t;

}

ll ckch(string s)
{
    ll t=maxx;
    for(i=0;i<m;i++)
    {
        j=(int)(s[i]);
        if(j>=97 && j<=122)
        {
             t=min(t,min(i,m-i));
        }
    }
    return t;

}
main()
{
    ll n,i,j,k,sum;

    cin>>n>>m;
    string s;
    for(i=1; i<=n; i++)
    {
        cin>>s;
        dg[i]=ckdg(s);
        ch[i]=ckch(s);
        sg[i]=cksg(s);
    }
    sum=maxx;

    //cout<<dg[1]<<" "<<ch[2]<<" "<<sg[3]<<endl;

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            for(k=1;k<=n;k++)
            {
                if(i==j || i==k || j==k)
                    continue;
                sum=min(sum,dg[i]+ch[j]+sg[k]);

            }

        }
    }

    cout<<sum;


}
