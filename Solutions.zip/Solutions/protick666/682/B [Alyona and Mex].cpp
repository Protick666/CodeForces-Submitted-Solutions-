#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007

ll a[1000000];


int main()
{
   ll n,i,j,x,y,sum,p,r,m,q,ans;
   cin>>n;

   for(i=0;i<n;i++)
    scanf("%I64d",&a[i]);

   sort(a,a+n);

   sum=1;

   for(i=1;i<n;i++)
   {
       if(a[i]>sum)
       {
           a[i]=sum+1;
           sum++;
       }

       else
        a[i]=sum;



   }
   if(n==1)
    cout<<2;
   else

   cout<<a[n-1]+1;

}
