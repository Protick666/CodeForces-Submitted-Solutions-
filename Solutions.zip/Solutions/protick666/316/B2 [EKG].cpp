#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)


class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};

ll par[10000];
ll len[10000];
ll dp1[1002];
ll dp2[1002];
vector<ll> v;
vector<ll> ans;

main()
{   ll i,n,p,j,k,l;
    UF t(10000);
    //pad=new UF(5);
    //pad.merge(1,2);
    //cout<<pad.find(i)<<endl;
    cin>>n>>p;
    ll *x,*y;
    x=dp1;
    y=dp2;

    fr(i,1,n)
    {
        cin>>par[i];
        if(par[i]!=0)
          t.merge(i,par[i]);}

    for(i=1;i<=n;i++)
    {
        len[(t.find(i))]++;
    }
    for(i=1;i<=n;i++)
    {
        if(len[i]==0 || (t.find(p))==i)
            cont;
        v.pb(len[i]);
    }
    //flag(1);
    ll temp=par[p];
    l=0;
    while(temp!=0)
    {
        temp=par[temp];
        l++;
    }
    l++;
    x[l]=1;
    //flag(2);


    for(i=0;i<v.size();i++)
    {
        //cout<<v[i]<<endl<<endl;
        for(j=0;j<=1000;j++)
        {
            //cout<<dp[j]<<endl;
            if(x[j]==0)
                cont;
            //cout<<j<<endl;
            y[j]=1;
            y[j+v[i]]=1;
        }
        swap(x,y);
    }
    //flag(2);

    for(i=1;i<=1000;i++)
    {
        if(x[i]==0)
            cont;
        cout<<i<<endl;
    }




/////////this code works in O(n) time where n is the number of times merge and find is called
}
