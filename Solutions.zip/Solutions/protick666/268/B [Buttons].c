#include<stdio.h>
main()
{int i,a,b,c,d;
 scanf("%d",&a);
 c=0;
 for(i=a;i>=1;i=i-1)
    {if(i==a)
       b=0;
     else
       b=(i-1)*(a-i);
     c=i+b+c;
     }
 printf("%d",c);


}