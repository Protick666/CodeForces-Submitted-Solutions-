#include<stdio.h>
main()
{

int a,b,sum,flag,max;
scanf("%d%d",&a,&b);
max=a>=b?b:a;
max++;

printf("%d\n",max);
for(a=0;a<max;a++)
{
printf("%d %d\n",a,max-a-1);


}









}