#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>


using namespace std;
main()
{
    long long int x,y,z,a,b,c;
    cin>>x>>y>>z>>a>>b>>c;
    if(x==a || y==b || z==c)
        cout<<"YES";
    else
        cout<<"NO";

}
