#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define mama 1000000007


ll a[1000000];

main()
{


    ll i,j,k,n,sum,p,q,r,store,cur,x,y,l;

    cin>>n;

    for(i=1;i<=n;i++)
    {scanf("%I64d",&a[i]);

      if(a[i]==1)
        x=i;

      if(a[i]==n)
        y=i;


    }

    if(x>y)
    {
        sum=x;
        x=y;
        y=sum;
    }

    p=x;
    q=n-y+1;

    //cout<<x<<" "<<y<<endl;

    if(p>q)
    {
        cout<<y-1;
    }

    else
        cout<<n-x;

}
