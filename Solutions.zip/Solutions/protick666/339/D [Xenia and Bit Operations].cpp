#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[1000004];

int main()
{
    ll n,i,j,k,l,sum,ans,x,y,temp,q,p,f,m,u,v,z;
    f=1;
    cin>>x>>q;
    l=1;
    for(i=1;i<=x;i++)
        l*=2;
    x=l;
    y=2*x-1;
    p=x/2;

    for(i=y-x+1;i<=y;i++)
        scanf("%I64d",&a[i]);

i=y-x+1;
l=x;
//cout<<x<<" "<<y<<endl;
  while(1)
  {
      for(j=1;j<=l;j=j+2)
      {
          k=i+j-1;
          m=k+1;

          if((f%2)==1)
            temp=a[k] | a[m];
          else
            temp=a[k] ^ a[m];
          a[k/2]=temp;

      }
      l=l/2;
      if(l==1)
        break;
      i=i-p;
      p=p/2;
      f++;

  }

  /*for(i=1;i<=y;i++)
    cout<<a[i]<<" ";*/
j=y-x;

    for(z=1;z<=q;z++)
    {
        scanf("%I64d%I64d",&u,&v);
         f=1;
         u=u+j;
        a[u]=v;


      while(1)
      {
          if((u%2)==0)
            k=u+1;
      else
          k=u-1;

          x=a[u];
          y=a[k];
          p=u/2;
          if((f%2)==1)
            temp=a[k] | a[u];
          else
            temp=a[k] ^ a[u];
        if(a[u/2]==temp)
            break;
          a[u/2]=temp;
          if(p==1)
            break;
        u=u/2;
        f++;

//cout<<p<<endl;



      }


       printf("%I64d\n",a[1]);


    }

//cin>>p;
}
