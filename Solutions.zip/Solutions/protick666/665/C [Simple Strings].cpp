#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000
char x[1000000];
ll dp[1000000];
char y[1000000];
char ch[1000000];

char check(char a,char b)
{
    char c='a';

    while(1)
    {
        if(c!=a && c!=b)
            return c;
        c++;
    }


}

int main()
{
   ll n,i,j,k,l,sum,ans,p,f;
   char a;
   char b;
   scanf("%s",ch);

   string s;
   s=ch;
   l=s.length();
   p=0;

//cout<<l<<endl;
   for(i=0;i<l;i++)
   {

       if(i==0)
       {
           dp[p]++;
           x[p]=s[i];

       }
       else
       {
           if(s[i]==s[i-1])
           {
               dp[p]++;
           }
           else
           {
               p++;
               dp[p]++;

               x[p]=s[i];
               //cout<<s[i];
           }

       }}



       //cout<<dp[0]<< " "<<dp[1]<<endl;
       for(i=0;i<=p;i++)
       {
           a=x[i];
           if(i<p)
            b=check(a,x[i+1]);
           else
            b=check(a,a);
            f=1;

           while(dp[i]!=0)
           {
               if((f%2)==1)
                printf("%c",a);
               else
                printf("%c",b);
               f++;
               dp[i]--;


           }



       }




}
