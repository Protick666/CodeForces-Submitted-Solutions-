#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)

class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};
pair <ll,ll> p;
ll root[1000001];
ll a[1000001];
vector <ll> v[1000001];
vector < pair<ll,ll> > s;
ll vis[1000001];

double yy,xx;
 ll n,i,j,k,ans,sum,m,x,y,z,t;

main()
{


    /*//pad=new UF(5);
    pad.merge(1,2);
    pad.merge(3,4);
    //pad.merge(3,2);
    for(i=1;i<=5;i++)
        pad.find(i);
    for(i=1;i<=5;i++)
        cout<<pad.find(i)<<endl;*/

        cin>>n>>m;
                 UF pad(n);

        for(i=1;i<=n;i++)
            {cin>>a[i];
             p=mp(a[i],i);
             s.pb(p);
            }

            for(i=1;i<=m;i++)
            {
                cin>>x>>y;
                v[x].pb(y);
                v[y].pb(x);
            }

            sort(s.begin(),s.end());

            for(i=1;i<=n;i++)
                root[i]=1;

            for(i=n-1;i>=0;i--)
            {
                p=s[i];
               x=p.fi;
               y=p.se;
               //cout<<y<<" "<<x<<" :";

               for(j=0;j<v[y].size();j++)
               {
                   t=v[y][j];
                   if(vis[t]==0 || pad.find(t)==pad.find(y))
                     continue;

                   ans+=x*root[pad.find(t)]*root[pad.find(y)];
                   //cout<<t<<" "<<ans;
                   z=root[pad.find(t)]+root[pad.find(y)];
                   pad.merge(y,t);
                   root[pad.find(y)]=z;
               }

               vis[y]=1;
               //cout<<endl;
            }

            z=n*(n-1)/2;


        yy=ans;
        xx=z;
        yy=yy/xx;


std::cout << std::fixed;
    std::cout << std::setprecision(10);
    std::cout << yy;




}
