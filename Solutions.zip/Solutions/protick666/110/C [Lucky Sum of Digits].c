#include<stdio.h>
main()
{
long long int n,i,j,k,s,f,rest,give;
scanf("%I64d",&n);

s=n/7;
rest=n%7;

switch(rest)
{

case 0:
  f=0;
  give=0;
  break;

case 1:
  f=2;
  give=1;
  break;
case 2:
  f=4;
  give=2;
  break;
case 3:
  f=6;
  give=3;
  break;
case 4:
  f=1;
  give=0;
  break;
case 5:
  f=3;
  give=1;
  break;
case 6:
  f=5;
  give=2;












}

if(s-give<0)
 printf("-1");
else
{

for(i=1;i<=f;i++)
 printf("4");
for(i=1;i<=s-give;i++)
 printf("7");








}









}
