#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define modd 1000000007

#define ll long long int

ll dp[4000][4000];
vector <ll> v[10000];
ll vis[1000000];


int main()
{
    ll n, k,i ,j, l,sum, ans,p;
    cin>>n>>k;

    for(i=1;i<=n;i++)
    {

        for(j=1;;j++)
        {
            p=j*i;

            if(p>n)
                break;
            v[p].push_back(i);
            vis[p]++;

        }


    }


    for(i=1;i<=k;i++)
    {
       if(i==1)
       {
           for(j=1;j<=n;j++)
             dp[i][j]=1;
       }

       else
       {
           for(j=1;j<=n;j++)
           {
               sum=0;

               for(l=0;l<vis[j];l++)
                 sum=(sum+dp[i-1][v[j][l]])%modd;

               dp[i][j]=sum;
           }

       }


    }



    sum=0;

    for(i=1;i<=n;i++)
        sum=(sum+dp[k][i])%modd;

    cout<<sum;

}
