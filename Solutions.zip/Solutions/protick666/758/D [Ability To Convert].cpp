#include <bits/stdc++.h>
using namespace std;


#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl


string s,t;


int main()
{
    ll n,i,j,k,sum,p,ans,q,r;
    string s;
    cin>>n>>s;
    ans=0;
    i=s.length()-1;
    j=i;
    q=1;
    while(1)
    {
        if(i<0)
            break;
        j=i;
        p=1;
        sum=0;
        while(j>=0)
        {
            r=digit(s[j]);
            r*=p;
            if(sum+r>=n)
            {j++;
                break;}
          sum+=r;
          p*=10;
          if(p>n)
            break;
          j--;

        }
        if(j>=0)
        {
            while(s[j]=='0' && j!=i)
                j++;
        }
        ans+=q*sum;
        q*=n;
        i=j-1;


    }


cout<<ans;



}
