#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 10000000000000000
#define ex  exit(0)
ll a[1000][1000];
main()
{
    ll n,m,k,x,y,i,j,sum,p,t,q,w,e;
    cin>>n>>m>>k>>x>>y;
    if(n==1)
    {
        p=k/m;
        t=k%m;
        if(t!=0)
        {
            if(y<=t)
                cout<<p+1<<" "<<p<<" "<<p+1;
            else
                cout<<p+1<<" "<<p<<" "<<p;

        }
        else
            cout<<p<<" "<<p<<" "<<p;

    }

    else
    {
        p=k/(m*(n+n-2));
        t=k%(m*(n+n-2));
        for(i=1; i<=n+n-2; i++)
        {
            for(j=1; j<=m; j++)
                a[i][j]+=p;
        }
        i=1;
        j=1;

        while(t!=0)
        {
            a[i][j]++;
            j++;
            if(j>m)
            {
                j=1;
                i++;
            }
            t--;

        }
        //cout<<"tit";
        for(i=1; i<=n; i++)
        {
            if(i==1 || i==n)
                continue;
            for(j=1; j<=m; j++)
            {
                a[i][j]+=a[n-i+n][j];

            }
        }
        //cout<<"racks";
        q=-1;
        w=maxx;
        e=-1;
        for(i=1; i<=n; i++)
        {
            for(j=1; j<=m; j++)
            {
                if(i==x && j==y)
                    e=a[i][j];
                q=max(a[i][j],q);
                w=min(a[i][j],w);
            }
        }
        cout<<q<<" "<<w<<" "<<e;
    }
}
