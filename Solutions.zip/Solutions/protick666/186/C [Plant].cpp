#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007

ll check( ll a)
{
    if(a==1)
        return 2;
    if(a==0)
        return 1;
    ll p,q,r;

    p=a/2;

    q=a%2;

     r=check(p);

    if(q==0)
        return (r*r)%mod;
    else
        return (r*r*2)%mod;

}


int main()
{
   ll n,i,j,k,x,y,ans,sum,q,a,b;
   cin>>n;
   if(n==0)
   {
      cout<<"1";
      exit(0);
   }
   b=n;

   n=n%(mod-1);

   y=check(n);
   b=b-1;
   b=b%(mod-1);
   x=check(b);

   ans=(y+1)%mod;
   ans=(ans*x)%mod;
   cout<<ans;


}
