#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int a[3][3];

main()
{

int l1,l2,l3,i,j,k,l,flag,pos,sum,n;
char ch,ch1,ch3;
n=-1;
flag=0;
pos=0;
scanf("%d%d%d%d%d%d",&a[0][0],&a[0][1],&a[1][0],&a[1][1],&a[2][0],&a[2][1]);

sum=a[0][0]*a[0][1]+a[1][1]*a[1][0]+a[2][1]*a[2][0];
//printf("%d\n",sum);
for(i=1;i<=sqrt(sum)+1;i++)
{
    if(i*i==sum)
    {
        n=i;
        break;
    }


}

if(n==-1)
{
    printf("-1");
    exit(0);

}
for(i=0;i<3;i++)
{
 if(a[i][0]==n)
 {
     l1=a[i][1];
     flag=1;
     a[i][2]=1;
     break;
 }

 if(a[i][1]==n)
 {
     l1=a[i][0];
     flag=1;
     a[i][2]=1;
     break;
 }


}


if(flag==0)
{
    printf("-1");
    exit(0);


}
for(i=0;i<3;i++)
{if(a[i][2]!=0)
   continue;
 if(a[i][0]==n)
 {
     l2=a[i][1];
     flag=2;
     a[i][2]=2;
     break;
 }

 if(a[i][1]==n)
 {
     l2=a[i][0];
     flag=2;
     a[i][2]=2;
     break;
 }

}
//printf("%d\n\n",l2);
if(flag==1)
{

    for(i=0;i<3;i++)
{if(a[i][2]!=0)
   continue;
 if(a[i][0]==n-l1)
 {
     l2=a[i][1];
     flag=3;
     a[i][2]=2;
     break;
 }

 if(a[i][1]==n-l1)
 {
     l2=a[i][0];
     flag=3;
     a[i][2]=2;
     break;
 }

}


}

if(flag==1)
{
    printf("-1");
    exit(0);


}


if(flag==2)
{
    for(i=0;i<3;i++)
    {

        if(a[i][2]!=0)
            continue;

        if(a[i][0]==n || a[i][1]==n){
                pos=1;
                 break;
        }

    }
    if(pos==1)
    {
        printf("%d\n",n);
        for(i=1;i<=2;i++)
        {
            for(j=0;j<3;j++)
            {
                if(a[j][2]==i)
                {
                    if(j==0)
                        ch='A';
                    if(j==1)
                        ch='B';
                    if(j==2)
                        ch='C';
                   break;
                }

            }

          if(i==1){
          for(k=1;k<=l1;k++)
          {
              for(l=1;l<=n;l++)
                printf("%c",ch);
             printf("\n");

          }

          }
           //printf("\n");
           if(i==2){
          for(k=1;k<=l2;k++)
          {
              for(l=1;l<=n;l++)
                printf("%c",ch);
             printf("\n");

          }

          }
          //printf("\n");
        }

       for(i=0;i<2;i++)
       {
           if(a[i][2]==0)
            break;

       }
                   if(i==0)
                        ch='A';
                    if(i==1)
                        ch='B';
                    if(i==2)
                        ch='C';
         for(k=1;k<=n-l1-l2;k++)
          {
              for(l=1;l<=n;l++)
                printf("%c",ch);
             printf("\n");

          }



    }


}



if(flag==3)
{
    for(i=0;i<3;i++)
    {

        if(a[i][2]!=0)
            continue;

        if(a[i][0]==n-l1 || a[i][1]==n-l1){
                pos=1;
                 break;
        }

    }
    if(pos==1)
    {
           printf("%d\n",n);
        for(i=1;i<=2;i++)
        {
            for(j=0;j<3;j++)
            {
                if(a[j][2]==i)
                {
                    if(j==0)
                        ch='A';
                    if(j==1)
                        ch='B';
                    if(j==2)
                        ch='C';
                   break;
                }



            }

          if(i==1){
          for(k=1;k<=l1;k++)
          {
              for(l=1;l<=n;l++)
                printf("%c",ch);
             printf("\n");

          }

          }

           if(i==2){
          ch1=ch;
          }
        }

         for(j=0;j<3;j++)
            {
                if(a[j][2]==0)
                {
                    if(j==0)
                        ch3='A';
                    if(j==1)
                        ch3='B';
                    if(j==2)
                        ch3='C';
                   break;
                }



            }

         for(k=1;k<=n-l1;k++)
          {
              for(l=1;l<=l2;l++)
                printf("%c",ch1);
              for(l=l2+1;l<=n;l++)
                printf("%c",ch3);
             printf("\n");

          }



    }

//printf("%c%c",ch1,ch3);
}


if(pos==0)
{
    printf("-1");
    exit(0);



}




}