#include<stdio.h>
#include<stdlib.h>
#include<string.h>



long long int dif[11];
long long int base[12];

int comparetor (const void * a, const void * b)
	{
		return ( *(int*)a - *(int*)b );
	}




int main()
{
long long int n,poi,sum,i,store;
scanf("%I64d%I64d",&n,&poi);

sum=0;


for(i=1;i<=n;i++)
{
   scanf("%I64d",&store);
   sum=sum+(store/10);

   if(store!=100)
   dif[10*(1+store/10)-store]++;
   base[store/10+1]++;

}


for(i=1;i<=10;i++)
{
   if(poi<i)
    break;
   if(i*dif[i]<=poi){
        sum=sum+dif[i];
        poi=poi-i*dif[i];}


    else{
     sum=sum+ (poi/i);
     poi=poi-i*(poi/i);

     break;}





}

for(i=1;i<=9;i++)
{

    if(10*(10-i)*base[i]<=poi){
        sum=sum+base[i]*(10-i);
        poi=poi-10*(10-i)*base[i];}


    else{
        sum=sum+poi/10;
        break;

    }



}




printf("%I64d",sum);




//qsort (a, i+1, sizeof(int), comparetor );


}