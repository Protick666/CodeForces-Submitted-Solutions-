#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))


ll cap[1000000];
ll vis[1000000];
ll dp[1000000];
int main()
{
    ll i,q,z,j,sum,ans,n,m,f,x,y;
    cin>>n;
    for(i=1; i<=n; i++)
    {
        cin>>cap[i];
        vis[i]=cap[i];
    }

    std::set<ll> myset;
    std::set<ll>::iterator itup;

    for (int i=1; i<=n+1; i++) myset.insert(i);

    cin>>m;

    for(i=1; i<=m; i++)

    {


        cin>>f;

        if(f==1)
        {
            cin>>x>>y;
            itup=myset.upper_bound (x-1);
            while(*itup!=n+1)
            {
                z=*itup;
                if(y>cap[z])
                {
                    y-=cap[z];
                    cap[z]=0;

                    myset.erase(z);
                    itup=myset.upper_bound (x-1);

                }
                else if(y<cap[z])
                {
                    cap[z]-=y;
                    break;

                }
                else
                {
                    cap[z]=0;
                    myset.erase(z);
                    break;
                }
            }
        }
        else
        {
            cin>>x;
            cout<<vis[x]-cap[x]<<endl;;
        }
    }





}
