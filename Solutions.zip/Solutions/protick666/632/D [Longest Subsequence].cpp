#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
ll a[1000009];
//ll tot[1000009];
//ll vis[1000009];
ll m;
ll dp[1000009];
map<ll,ll> vis;
map<ll,ll> tot;
void ck(ll x)
{
    for(ll j=1;j*x<=m;j++)
    {
        dp[j*x]+=tot[x];
    }
}

main()
{
    ll i,p,j,l,x,y,r,b,sum,ans,n;
    cin>>n>>m;
    fr(i,1,n)
    {
        in(x);
        a[i]=x;
        tot[x]++;
    }
    for(i=1;i<=n;i++)
    {
        if(vis[a[i]]==1)
            cont;
        vis[a[i]]=1;
        ck(a[i]);
    }
    sum=0;
    ans=1;
    for(ll j=1;j<=m;j++){

        if(dp[j]>sum)
        {
            sum=dp[j];
            ans=j;
        }
    }

    cout<<ans<<" "<<sum<<endl;
    for(i=1;i<=n;i++)
    {
        x=a[i];
        if((ans%x)==0)
            out(i);
    }

}
