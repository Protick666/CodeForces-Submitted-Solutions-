#include <stdio.h>


int main()
{
    long long int n,sum;
    scanf("%I64d",&n);




    if(n==1)
    {
        printf("1");
        return 0;
    }
    else if(n==2)
    {
        printf("2");
        return 0;
    }

    else if(n%2==0)
    {
        if(n%3==0)
        {
           
           
             printf("%I64d",(n-1)*(n-2)*(n-3));
          //else
            //printf("%I64d",(n)*(n-1)*(n-4));
        
        
        }
        else
        {
            printf("%I64d",n*(n-1)*(n-3));
        }
    }
    else if(n%2!=0)
    {
        printf("%I64d",n*(n-1)*(n-2));
    }

      return 0;}
