#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007


ll vis[100];
vector <ll> v;




int main()
{
   ll i,j,k,l,n,ans,sum,p,e,x,y,q,z;
   z=0;
char ch[1000009];
string s;


scanf("%s",ch);

s=ch;

l=s.length();

for(i=0;i<l;i++)
{
    p=s[i]-'0';
    vis[p]++;

}
ans=0;

for(i=1;i<=9;i++)
{
    p=vis[i];
    if(i==1 || i==6 || i==8 || i==9)
    {
        p--;
    }

    for(j=1;j<=p;j++)
    {
        ans= (ans*10 +i)%7;
        v.push_back(i);
        z++;
    }


}


   for(i=0;i<z;i++)
    printf("%I64d",v[i]);

    ans=(ans*10000)%7;

   if(ans==0)
     cout<<"1869";
   else if(ans==6)
      cout<<"1968";
    else if(ans==5)
      cout<<"1689";
      else if(ans==4)
      cout<<"6198";
      else if(ans==3)
      cout<<"8691";
      else if(ans==2)
      cout<<"8916";
      else if(ans==1)
      cout<<"1896";


      for(i=1;i<=vis[0];i++)
        printf("0");

}
