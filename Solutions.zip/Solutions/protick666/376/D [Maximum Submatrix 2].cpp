#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define co continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

//ll a[5003][5003];
ll dp[5003][5003];
ll gu[5003][5003];

//vector <ll> v[5004];

int main()
{
    ll n,m,i,j,k,l,x,sum,ans,t;
    cin>>n>>m;
    char ch[10000];
    string s;
    for(i=1; i<=n; i++)
    {
        scanf("%s",ch);
        s=ch;
        for(j=1; j<=m; j++)
            dp[i][j]=(s[j-1]=='0')?0:1;
    }

    for(i=1; i<=n; i++)
    {
        for(j=m; j>=1; j--)
        {
            if(dp[i][j]==0)
                dp[i][j]=0;
            else
                dp[i][j]=dp[i][j+1]+1;
        }
    }
    ans=0;
    for(j=1; j<=m; j++)
    {
        for(i=1; i<=n; i++)
        {
            gu[j][dp[i][j]]++;
        }


        //for(i=5003;i>=1;i--)
            //gu[j][i]=gu[j][i]+gu[j][i+1];
            x=0;

        for(i=5003;i>=1;i--)
        {
            x+=gu[j][i];
            
            ans=max(ans,i*x);
        }



    }

    cout<<ans;

}
