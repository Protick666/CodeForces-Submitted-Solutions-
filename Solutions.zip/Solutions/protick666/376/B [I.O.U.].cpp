#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll x[101];
ll y[101];

int main() {

    ll i,j,k,l,sum,ans,n,p,a,b,m;
    cin>>n>>m;
    sum=0;

    for(i=1;i<=m;i++)
    {
        scanf("%I64d%I64d%I64d",&a,&b,&l);
        x[a]+=l;
        y[b]+=l;

    }

    for(i=1;i<=n;i++)
    {
        p=x[i]-y[i];
        if(p<0)
            p=0;
        sum+=p;


    }

    cout<<sum;


}
