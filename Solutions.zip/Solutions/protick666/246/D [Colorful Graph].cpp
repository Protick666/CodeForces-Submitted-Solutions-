#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007




ll col[1000000];
map <ll,ll> m[100001];

ll vis[1000000];



int main()
{
   ll i,j,k,l,n,ans,sum,p,e,x,y,q;

   cin>>n>>e;
q=100000000;
   for(i=1;i<=n;i++)
    {scanf("%I64d",&p);
    col[i]=p;
    if(p<q)
        q=p;

    }

//q=col[1];
for(i=1;i<=e;i++)
{
    scanf("%I64d%I64d",&x,&y);

    if(m[col[x]][col[y]]==0 && col[x]!=col[y])
    {
        vis[col[x]]++;
         vis[col[y]]++;
         m[col[x]][col[y]]=1;
           m[col[y]][col[x]]=1;



    }
}
ans=0;

sum=0;

for(i=1;i<=1000000;i++)
{
    if(vis[i]>sum)
    {
        sum=vis[i];
        ans=i;
    }

}
if(ans==0)
    ans=q;
//cout<<vis[1]<<endl;
cout<<ans;
}
