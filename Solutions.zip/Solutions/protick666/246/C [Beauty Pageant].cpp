#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll a[100];
ll dp[100];
ll m[100][100];
int main() {
ll i,j,n,sum,ans,store,p,k,f,l,w;

sum=0;
cin>>n>>p;
for(i=0;i<n;i++)
    cin>>a[i];
sort(a,a+n);
for(i=n;i>=1;i--)
    a[i]=a[i-1];

w=1;

for(l=n;l>=1;l--,w++)
{
    if(l==n)
    {
        for(i=1;i<=n;i++)
        {
            cout<<w<<" "<<a[i]<<endl;
            m[i][1]=a[i];
            sum++;
            if(sum==p)
                exit(0);
        }

    }
    else
    {
        for(i=1;i<=l;i++)
        {
            cout<<w<<" ";
            for(j=1;j<w;j++)
                cout<<m[i][j]<<" ";
            cout<<a[l+1]<<endl;
            m[i][w]=a[l+1];
            sum++;
            if(sum==p)
                exit(0);
        }

    }


}




}
