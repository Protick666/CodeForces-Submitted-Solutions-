#include<string.h>
main()
{
  long long int n,q,i,j,k,count;
  scanf("%I64d%I64d",&n,&q);
  char c;
  long long int a[q];
  count=0;
  char ori[n+1];
  char test[n+1];
  scanf("%s",ori);
  getchar();
  strcpy(test,ori);
  //printf("string : %s\n",test);
  //for(i=1;i<=q;i++)
  //{

      count=0;

     // test[k-1]=c;
     // printf("string : %s\n",test);
      for(j=0;j<n-1;j++)
      {
          if(test[j]=='.')
          { k=j;
            while(test[k]=='.')
                k++;
            count=k-j-1+count;

            j=k-1;
           //printf("count %I64d\n",count);
          }




      }

    //a[i-1]=count;


  //}

  for(i=1;i<=q;i++)
  {
      scanf("%I64d",&k);
      getchar();
      scanf("%c",&c);
      getchar();
      if(test[k-1]==c || (test[k-1]!='.' && c!='.'))
      {
          a[i-1]=count;
          continue;
      }
      test[k-1]=c;
      if(c=='.')
      {

              if(k!=1 && k!=n)
              {
                  if(test[k-2]=='.' && test[k]=='.')
                  {
                      count=count+2;
                      a[i-1]=count;
                  }

                  else if(test[k-2]=='.' || test[k]=='.')
                  {
                      count=count+1;
                      a[i-1]=count;
                  }
               else
                a[i-1]=count;


              }

            else if(k==1)
            {
                if( test[k]=='.')
                  {
                      count=count+1;
                      a[i-1]=count;
                  }
                else
                a[i-1]=count;


            }
        else if(k==n)
            {
                if( test[k-2]=='.')
                  {
                      count=count+1;
                      a[i-1]=count;
                  }
                else
                a[i-1]=count;

            }




          }
          ////////////


           else
      {

              if(k!=1 && k!=n)
              {
                  if(test[k-2]=='.' && test[k]=='.')
                  {
                      count=count-2;
                      a[i-1]=count;
                  }

                  else if(test[k-2]=='.' || test[k]=='.')
                  {
                      count=count-1;
                      a[i-1]=count;
                  }
               else
                a[i-1]=count;


              }

            else if(k==1)
            {
                if( test[k]=='.')
                  {
                      count=count-1;
                      a[i-1]=count;
                  }
                else
                a[i-1]=count;

            }
        else if(k==n)
            {
                if( test[k-2]=='.')
                  {
                      count=count-1;
                      a[i-1]=count;
                  }
               else
                a[i-1]=count;

            }




          }



      }







for(i=0;i<q;i++)
    printf("%I64d\n",a[i]);












}
