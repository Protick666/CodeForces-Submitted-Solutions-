#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
ll dp1[1001][1001];
ll dp2[1001][1001];
ll dp[1001][1001];

main()
{
    ll i,j,k,n,l,ans,sum,x,y;
    ans=0;

    cin>>x>>y;
    char ch[100000];
    for(i=1;i<=x;i++)
    {
        scanf("%s",ch);
        for(k=0;k<y;k++)
        {
            dp[i][k+1]=(ch[k]=='.')?0:1;
            if(ch[k]=='*')
                ans++;

        }
    }

    for(i=1;i<=x;i++)
    {
        sum=0;
        for(j=1;j<=y;j++)
            sum+=dp[i][j];

        for(j=1;j<=y;j++)
            dp1[i][j]=sum;

    }

      for(i=1;i<=y;i++)
    {
        sum=0;
        for(j=1;j<=x;j++)
            sum+=dp[j][i];

        for(j=1;j<=x;j++)
            dp2[j][i]=sum;

    }
    //cout<<dp1[1][2]+dp2[1][2]<<endl;

    for(i=1;i<=x;i++)
    {
        for(j=1;j<=y;j++)
        {
            if(dp1[i][j]+dp2[i][j]-dp[i][j]==ans)
            {
                cout<<"YES"<<endl;
                cout<<i<<" "<<j;
                exit(0);
            }
        }
    }

     cout<<"NO";

}
