#include <bits/stdc++.h>
using namespace std;
///https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007

map<string,ll> val;
int main()
{
  ll i,j,k,l,m,n,x,y;

  cin>>n>>k>>m;
  char ch[100];
  vector<string> v;
  for(int i=1;i<=n;i++)
  {
      scanf("%s",ch);
      string s=ch;
      v.pb(s);
  }
  fr(i,1,n)
  {
      in(x);
      val[v[i-1]]=x;
  }
  ll p;
  //cout<<"yo";
  fr(j,1,k)
  {
      //cout<<i<<endl;
      in(p);
      vector<string> temp;
      char cc[100];
      fr(i,1,p)
      {
           in(x);
           string s=v[x-1];
           temp.pb(s);
      }
      ll mm=val[temp[0]];
      for(i=0;i<temp.size();i++)
        mm=min(mm,val[temp[i]]);

     for(i=0;i<temp.size();i++)
        {
            string t=temp[i];
            val[t]=mm;
        }


  }
  //cout<<"hello";
   char cc[100];
  ll ans=0;
  for(i=1;i<=m;i++)
  {

      scanf("%s",cc);
        string s=cc;
        ans+=val[s];

  }

  cout<<ans;

}
