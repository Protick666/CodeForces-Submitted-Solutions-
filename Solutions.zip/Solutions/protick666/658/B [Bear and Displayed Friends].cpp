#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int
ll dp[1000000];
ll p[1000000];

bool cmp(int a, int b)
{
    return (p[b]>p[a]);

}
int main() {

    ll i,j,k,l,n,q,x,y,f,m;
    l=0;
    cin>>n>>k>>q;
    ll a[k];
    for(i=1;i<=n;i++)
        scanf("%I64d",&p[i]);

    for(i=1;i<=q;i++)
    {
        scanf("%I64d%I64d",&f,&x);
        if(f==1)
        {
            if(l<k)
            {
                a[l]=x;
                dp[x]=1;

            }
            else
            {
                j=0;
                while(p[x]>p[a[j]])
                {
                    j++;
                    if(j==k)
                        break;
                }
                if(j!=0)
                {
                    dp[x]=1;
                    dp[a[0]]=0;
                    for(m=0;m<=j-2;m++)
                        a[m]=a[m+1];

                    a[j-1]=x;


                }




            }
            l++;
            if(l==k)
                sort(a,a+k,cmp);

        }

        else
        {
            if(dp[x]==0)
                printf("NO\n");
            else
                printf("YES\n");


        }

    }





}
