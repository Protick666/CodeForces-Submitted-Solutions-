#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
ll n,i,j,m,k,p,ans,l,y,sum,x;
void print(ll a)
{
    ll i;
    for(i=1;i<=a/2;i++)
        cout<<4;
    for(i=1;i<=a/2;i++)
        cout<<7;

        ex;
}

ll check(ll a)
{
    ll x,i,t;
    t=0;

    for(i=1;i<=l;i++)
    {
        x=a & 1;
        if(x!=0)
            t++;
        a=a>>1;
    }
    if(t==l/2)
        return 1;
    else
        return 0;
}
ll val(ll a)
{
    ll x,i,t,p;
    t=0;
    p=1;


    for(i=1;i<=l;i++)
    {
        x=a & 1;
        if(x!=0)
        {
            t=p*7+t;
        }
        else
            t=p*4+t;
        p*=10;

        a=a>>1;
    }
    return t;
}

ll len(ll a)
{
    ll i;
    i=0;
    while(a!=0)
    {
        i++;
        a=a/10;
    }
    return i;
}

int main()
{
    cin>>n;
    y=1;
    l=len(n);
    //cout<<l<<endl;
    if((l%2)==1)
        print(l+1);
    for(i=1;i<=l;i++)
        y*=2;
       // cout<<y<<endl;
   y--;

   sum=maxx;

    for(i=0;i<=y;i++)
    {
        x=check(i);
        p=val(i);
        //cout<<i<<" "<<x<<" "<<p<<endl;
        if(x==1 && p>=n)
            sum=min(p,sum);
    }

    if(sum==maxx)
        print(l+2);

    cout<<sum;

}
