#include<stdio.h>
#include<math.h>


int isprime(long long int a)
{
    long long int i;
    for(i=2;i<=(int)(sqrt(a));i++){
        if(a%i==0)
            return 0;

    }
   return 1;
}
main()
{
long long int n,i,j,k,low,store,sum;
store=1;
scanf("%I64d",&n);

if(isprime(n)==1)
{
   store=n;
   printf("%I64d",n);
   exit(0);
}

for(i=2;i<=n;i++)
{if(n==1)
   break;
    if(n%i==0)
    {   store=store*i;
        while(n%i==0){
            n=n/i;

            }

      if(isprime(n)==1)
      {
          store=store*n;
          break;

      }

    }





}

printf("%I64d",store);





}