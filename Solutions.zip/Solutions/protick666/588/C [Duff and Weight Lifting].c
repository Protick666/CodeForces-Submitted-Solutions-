#include<stdio.h>
#include<math.h>
#define ma 1000001
long long int a[ma];

main()
{
long long int n,i,j,k,store,min,max,way;
min=ma;
max=-1;
way=0;
scanf("%I64d",&n);


for(i=1;i<=n;i++)
{
    scanf("%I64d",&store);
    a[store]++;
    a[store]=a[store];
    if(store<min)
        min=store;
    if(store>max)
        max=store;
}

for(i=min;;i++)
{
   if(a[i]==0 && i>max)
       break;
   if(a[i]==0)
       continue;

   a[i+1]=a[i+1]+(a[i])/2;
   a[i]=(a[i])%2;
   if(a[i]>0){
     way++;


   }




}




printf("%I64d",way);





}