#include<stdio.h>
main()
{
long long int n,i,j,k,low,store,sum;
sum=0;
low=101;
scanf("%I64d",&n);

int a[n][2];

for(i=0;i<n;i++)
{
scanf("%I64d%I64d",&a[i][0],&store);
if(store<low)
  low=store;
a[i][1]=low;

}

for(i=0;i<n;i++)
 sum=sum+(a[i][1])*(a[i][0]);
printf("%I64d",sum);














}