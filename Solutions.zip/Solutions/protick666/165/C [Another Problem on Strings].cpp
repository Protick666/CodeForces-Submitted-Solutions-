#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[1000004];

int main()
{
   ll n,i,j,k,l,sum,ans,z,x,y,w1,w2,d1,d2;
   cin>>k;
   string s;
   char ch[1000000];
   scanf("%s",ch);
   s=ch;

   l=1;
   z=s.length();
   for(i=0;i<z;i++)
   {
       //cout<<s[i]<<endl;
       if(s[i]=='1')
       {
           a[l]=i+1;
           l++;
       }
   }

   a[l]=z+1;
   l--;
   if(k==0)
   {
       ans=0;
       if(l==0)
       {
           sum=z*(z+1)/2;
           cout<<sum;
           exit(0);

       }
       for(i=2;i<=l;i++)
       {
           x=a[i-1];
           y=a[i];
           y=y-x-1;
           sum=y*(y+1)/2;
           ans+=sum;
       }
       y=a[1]-1;
       sum=y*(y+1)/2;
           ans+=sum;
        y=z-a[l];
        sum=y*(y+1)/2;
           ans+=sum;
           cout<<ans;
           exit(0);


   }
   ans=0;
   i=1;
   j=i+k-1;
   //cout<<l;
   while(1)
   {

       if(j>l)
        break;

       x=abs(a[i]-a[i-1]);
        y=abs(a[j+1]-a[j]);
        ans+=x*y;
        i++;
        j++;



   }

   cout<<ans;

}
