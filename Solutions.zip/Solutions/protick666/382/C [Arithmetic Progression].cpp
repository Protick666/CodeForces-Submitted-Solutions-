#include<stdio.h>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#define max 1000001
using namespace std;

int a[max];


int main()
{
  long long int n,i,j,k,mini,flag,p,sumo;
  cin>>n;
  for(i=0;i<n;i++)
  {
      cin>>a[i];

  }
  sort(a,a+n);

  if(n==1)
  {
      printf("-1");
      exit(0);
  }
  if(n==2)
  {   p=a[1]-a[0];
      if(a[0]==a[1])
      {
          cout<<"1"<<endl;
          cout<<a[0];
          exit(0);
      }
      else if((a[1]-a[0])%2==0)
      {
          cout<<"3"<<endl;
          cout<<a[0]-p<<" "<<a[0]+p/2<<" "<<a[1]+p;
          exit(0);


      }

       else
      {
          cout<<"2"<<endl;
          cout<<a[0]-p<<" "<<a[1]+p;
          exit(0);


      }
   }

  else{
        flag=0;
        j=0;
        sumo=0;
        mini=a[1]-a[0];
        for(i=0;i<n-1;i++)
        {
            if(a[i+1]-a[i]>mini)
            {
                flag++;
                j=i;

            }

            if(a[i+1]-a[i]<mini)
            {   mini=a[i+1]-a[i];
                flag=flag+sumo;


            }

            if(a[i+1]-a[i]==mini)
            {   sumo++;


            }

            if(flag>1)
                break;
        }

//cout<<mini<<" "<<a[j]<<" "<<a[j+1]<<" "<<flag<<endl;

    if(flag==0)
    {
        if(mini==0)
        {
            cout<<"1"<<endl;
            cout<<a[0];
            exit(0);
        }

        else{

            cout<<"2"<<endl;
            cout<<a[0]-mini<<" "<<a[n-1]+mini;
            exit(0);

        }

    }
     if(flag==1)
     {
         if(((a[j+1]-a[j])/2==mini) && ((a[j+1]-a[j])%2==0))
         {
             cout<<"1"<<endl;
            cout<<a[j]+mini;
            exit(0);

         }
         else{
            cout<<"0"<<endl;
            exit(0);

         }



     }

  else{
            cout<<"0"<<endl;
            exit(0);

         }









  }








}
