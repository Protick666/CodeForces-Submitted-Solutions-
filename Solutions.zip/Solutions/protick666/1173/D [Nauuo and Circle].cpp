#include <bits/stdc++.h>
#include <iostream>
#include <map>
//#include <stdio.h>
//#include "helper.h"
#include <math.h>
using namespace std;
#define ll long long int
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define IN(x) scanf("%lld, &x)
#define PI 3.14159265
#define modd 998244353
map<ll,vector<ll> > myMap;
ll fact[1000002];
ll vis[1000002];

ll calc(ll node, ll ex) {
    //cout<<"node : "<<node<<endl;
    vis[node] = 1;
    ll ans = 1; ll childs = 0;
    for(int i = 0; i < myMap[node].size(); i++) {
        if(vis[myMap[node][i]] == 0) {
            ans = (calc(myMap[node][i], 1) * ans) % modd;
            childs++;
        }
    }
    return (ans * fact[childs + ex]) % modd;
}

int main() {
    ll n,m,x,y;
    cin>>n;

    for(int i = 1; i < n; i++) {
        cin>>x>>y;
        myMap[x].push_back(y);
        myMap[y].push_back(x);
    }

    fact[1] = 1;
    for(ll i = 2; i <= 1000000; i++)
        fact[i] = (i * fact[i - 1]) % modd;

    cout << (n * calc(1, 0)) % modd;

}