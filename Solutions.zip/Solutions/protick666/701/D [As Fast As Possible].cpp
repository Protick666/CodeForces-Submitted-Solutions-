#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair

#define maxx 10000000000000000;
main()
{
    ll n,k,ans,sum,z,i,b;
    double p,q,t,v1,t1,v2,e,l,r,m,c,v,s,x,y;
    cin>>n>>l>>v1>>v2>>k;
    if(v1>=v2)
    {
        cout<<l/v1;
        exit(0);
    }
    z=(n+k-1)/k;
    if(z==1)
    {
        cout<<l/v2;
        exit(0);
    }
    x=0;
    y=l;

    for(b=1;b<=100;b++)
    {
        r=(x+y)/2;
        t=r/v2;
        p=t*v1;
        q=r;
        for(i=1;i<z;i++)
        {
            c=1/v1+1/v2;
            v=q/v2+p/v1;
            s=v/c;
            t1=(s-p)/v1;
            c=1/v1-1/v2;
            v=t1-s/v2+q/v1;
            m=v/c;
            t+=(m-q)/v1;
            p=s+((m-s)/v2)*v1;
            q=m;




        }

             if(m<l)
        {
            x=r;
        }
        else if(m>l)
        {
            y=r;
        }
        else
            break;


        //cout<<q<<endl;




    }

    std::cout << std::fixed;
    std::cout << std::setprecision(10);
    std::cout << t;

}
