#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
ll a[1000002];
vector<ll> v;

map<ll,ll> m;

int main()
{
  ll n,k,sum,ans,z,i,j,t,p,x,y;
  cin>>n>>k;
  loop(i,n)
    cin>>a[i+1];

    v.pb(1);
    if(k==-1)
        v.pb(-1);

  t=k;
  while(abs(t)<=100000000000000)
  {
      if(abs(k)==1)
        break;
      v.pb(t);
      t=t*k;
  }

  m[0]=1;
  sum=0;
  ans=0;
  for(i=1;i<=n;i++)
  {
      x=a[i];
      z=sum+x;
      for(j=0;j<v.size();j++)
      {
          y=v[j];
          ans+=m[z-y];
      }
      sum+=x;
      m[sum]++;

  }

  cout<<ans;




}
