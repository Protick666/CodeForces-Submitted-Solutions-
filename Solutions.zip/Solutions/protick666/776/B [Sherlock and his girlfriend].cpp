#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
map <ll,ll> m,val,pos;

ll a[100002];
ll p[100002];

int main()
{
    ll n,i,j,k,l,x,y,f,z,q;
    f=0;
    l=0;
    y=100002;

    for(i=1;i<=y;i++)
        a[i]=i;

    for(i=2;i<=y;i++)
    {
        if(a[i]==i)
            p[i]=1;
        else  cont;
        for(j=2;;j++)
        {
            x=j*i;
            if(x>y)
                break;
            a[x]=a[x]/i;
        }
    }

    cin>>n;
    for(i=1;i<=n;i++)
    {
        p[i+1]==0?f=1:l=1;
    }

    if(f==1 && l==1)
        cout<<2<<endl;
    else
        {cout<<1<<endl;


        for(i=1;i<=n;i++)
    {
        cout<<"1 ";

    }
    ex;


        }

        for(i=1;i<=n;i++)
    {
        p[i+1]==0?(cout<<1<<" "):(cout<<2<<" ");
    }






}
