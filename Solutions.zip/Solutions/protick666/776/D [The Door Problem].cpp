#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007



class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};

UF xx(200002);

ll m,t,z;

ll a[1000001];
ll f[1000001];
vector<ll> vv[1000001];
vector<ll> v[1000001];
vector<ll> inv[1000001];
ll vis[1000001];
ll no(ll p)
{
    if(p<=m)
        return p+m;
    else
        return p-m;
}

void dfs(ll p)
{
    vis[p]=1;
    ll i,q;
    t++;
    for(i=0;i<v[p].size();i++)
    {
        q=v[p][i];
        if(vis[q]==0)
        {
            dfs(q);
        }
    }
    t++;
    f[t]=p;
}


void dfs2(ll p)
{
    vis[p]=1;
    ll i,q;
    xx.merge(p,z);

    for(i=0;i<inv[p].size();i++)
    {
        q=inv[p][i];
        if(vis[q]==0)
        {
            dfs2(q);
        }
    }
}

int main()
{
    ll n,i,j,k,l,x,y,p,q;
    cin>>n>>m;

    fr(i,1,n)
      cin>>a[i];

    fr(i,1,m)
    {
        cin>>x;
        fr(j,1,x)
         {
             cin>>y;
             vv[y].pb(i);
         }
    }

    fr(i,1,n)
    {
        if(a[i]==1)
        {
            x=vv[i][0];
            y=vv[i][1];
            p=no(x);
            q=no(y);
            v[x].pb(y);
            v[y].pb(x);
            v[p].pb(q);
            v[q].pb(p);

            inv[x].pb(y);
            inv[y].pb(x);
            inv[p].pb(q);
            inv[q].pb(p);
        }
        else
        {
            x=vv[i][0];
            y=vv[i][1];
            p=no(x);
            q=no(y);
            v[x].pb(q);
            v[y].pb(p);
            v[p].pb(y);
            v[q].pb(x);

            inv[q].pb(x);
            inv[p].pb(y);
            inv[y].pb(p);
            inv[x].pb(q);
        }
    }



     fr(i,1,2*m)
      {
          if(vis[i]==0)
            dfs(i);
      }

    fr(i,0,2*m)
      vis[i]=0;

      for(i=5*m;i>=1;i--)
      {
          if(f[i]==0 || vis[f[i]]==1)
            cont;
          z=f[i];
          dfs2(z);
      }

    for(i=1;i<=m;i++)
    {
        if(xx.find(i) == xx.find(i+m))
           {
               cout<<"NO";
               ex;
           }
    }

    cout<<"YES";

}
