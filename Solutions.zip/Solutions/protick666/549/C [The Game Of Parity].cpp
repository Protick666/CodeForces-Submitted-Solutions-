#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;


main()
{
   long long int i,j,n,p,store,a,b,f,sum,o,e,k,l,d;

   cin>>n>>d;

   d=n-d;
   o=0;
   e=0;
   f=0;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d",&store);
       if(store%2==0)
        e++;
       else
        o++;



   }

   k=d/2;
   l=k+d%2;
   if(k==0 && l==0)
   {
       if(o%2==0)
       cout<<"Daenerys";
       else
        cout<<"Stannis";
       exit(0);

   }

   else if(k==l)
   {
       if(k>=o)
         f=1;
       else if(l<e)
         f=1;
       else
       {
           store=o-(l-e+k);
           if(store%2==0)
             f=1;

       }


   }

   else
   {
       if(k>=o)
         f=1;

       else if(k<e)
          f=0;
       else{

          store=o-(k-e+l);
          if(store%2==0)
             f=1;


       }





   }

   if(f==1)
    cout<<"Daenerys";
   else
    cout<<"Stannis";


}
