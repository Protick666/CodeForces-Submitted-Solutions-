#include <bits/stdc++.h>
#include <math.h>
using namespace std;
#define ll long long int
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

int main() {
    long long int n, m, p, r, l, mod;
    cin>> n >> m ;

    ll array[n + 1];
    ll segments[m+1][3];

    for(int i = 1; i<=n; i++)
        cin>>array[i];

    for(int i = 1; i<=m; i++) {
        cin>>segments[i][1]>>segments[i][2];
    }

    ll ans = -1;  ll x; ll y; ll subAns;

    for(int i = 1; i<=n; i++) {
        for(int j = 1; j<=n; j++) {
            ll big = array[j];
            ll small = array[i];
            ll t = 0;

            ll sumTillNow = big - small;
            for(int s = 1; s<=m; s++) {
                if(segments[s][1]<=j && segments[s][2]>=j) {
                    continue;
                }
                else if(segments[s][1]<=i && segments[s][2]>=i){
                    sumTillNow++;
                    t++;
                }
            }
            if(sumTillNow > ans) {
                ans= sumTillNow;
                subAns = t;
                x = i;  y = j;
            }
        }
    }

    cout<<ans<<endl;
    cout<<subAns<<endl;

    for(int s = 1; s<=m; s++) {
        if(segments[s][1]<=y && segments[s][2]>=y) {
            continue;
        }
        else if(segments[s][1]<=x && segments[s][2]>=x){
            cout<<s<<" ";
        }
    }
}