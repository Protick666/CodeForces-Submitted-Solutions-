#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int


int main() {

ll i,j,k,l,n,f,e,store,sum,b,r,c,d,h;
cin>>n;
ll a[n];
ll ans[n];
for(i=0;i<n;i++)
    scanf("%I64d",&a[i]);
sort(a,a+n);
j=0;
for(i=0;i<=n-1;i=i+2)
{
    ans[i]=a[j];
    j++;

}
for(i=1;i<=n-1;i=i+2)
{
    ans[i]=a[j];
    j++;

}

for(i=0;i<n;i++)
    printf("%I64d ",ans[i]);


}
