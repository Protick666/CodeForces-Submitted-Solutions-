#include <bits/stdc++.h>
using namespace std;
///https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
ll ft[2000010];

// Array size
int N;

// Point query: Returns the value at position b in the array
ll query(int b)	{
	ll sum = 0;
	for (; b; b -= LSOne(b)) sum += ft[b];
	return sum;
}

// Point update: Adds v to the value at all positions starting from  k in the array
void update(int k, int v) {
	for (; k <= N; k += LSOne(k)) ft[k] += v;
}

// Range update: Adds v to each element in [i...j] in the array
void range_update(int i, int j, int v)	{
	update(i, v);
	update(j + 1, -v);
}
ll val[1000002];
vector<pair<ll,ll> > v;
int main()
{


    ll i,h,j,k,l,m,n,x,y;
    N=1000002;
memset(ft, 0, (N+1) * sizeof(ll));

    cin>>n;

    fr(i,1,n)
    {
        in(val[i]);
        x=min(i-1,val[i]);
        v.pb(mp(x,i));

    }

    sort(all(v));

   
    ll c=0;
    ll sum=0;
    for(i=0;i<v.size();i++)
    {
        x=v[i].first;
        y=v[i].second;
        //cout<<"ola "<<x<<" "<<y<<endl;
        if(x>c)
        {

            for(j=c+1;j<=x;j++)
            {
                //cout<<"stuck";
                ll t=val[j];
                //cout<<"up "<<j<<" "<<t<<endl;
                range_update(1,t,1);


            }
            c=x;
        }
        //cout<<"ber";
       // cout<<"yo"<<y<<" "<<query(y)<<endl;

         sum+=query(y);

    }

    cout<<sum;
}
