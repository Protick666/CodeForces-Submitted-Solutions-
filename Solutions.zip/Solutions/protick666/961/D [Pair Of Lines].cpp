#include <bits/stdc++.h>
using namespace std;
///https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
bool collinear(ll x1, ll y1,ll x2, ll y2,ll x3, ll y3)
{
    /* Calculation the area of triangle. We have
       skipped multiplication with 0.5 to avoid
       floating point computations */
    ll a = x1 * (y2 - y3) + x2 * (y3 - y1) +
                             x3 * (y1 - y2);

    if (a == 0)
        return true;
    else
        return false;
}
vector<pair<ll,ll> > v,arr;
bool ck()
{

    if(arr.size()<=2)
        return true;
    ll x1,x2,y1,y2;
    x1=arr[0].first;
    x2=arr[1].first;
    y1=arr[0].second;
    y2=arr[1].second;

    for(int i=2;i<arr.size();i++)
    {
        if(!collinear(x1,y1,x2,y2,arr[i].first,arr[i].second))
            return false;
    }
    return true;

}


int main()
{
  ll i,j,k,l,m,n,x,y,ans,sum,p;

  cin>>n;

  fr(i,1,n)
  {
      in2(x,y);
     v.pb(mp(x,y));
  }

  if(n<=4)
  {
      cout<<"YES";
      ex;
  }

  for(i=2;i<n;i++)
  {
      if(!collinear(v[0].first,v[0].second,v[1].first,v[1].second,v[i].first,v[i].second))
         {
             p=i;
             arr.pb(mp(v[i].first,v[i].second));
         }
  }
  if(ck())
  {
      cout<<"YES";
      ex;
  }
  arr.clear();

  swap(v[1],v[2]);
  for(i=2;i<n;i++)
  {
      if(!collinear(v[0].first,v[0].second,v[1].first,v[1].second,v[i].first,v[i].second))
         {
             p=i;
             arr.pb(mp(v[i].first,v[i].second));
         }
  }
  if(ck())
  {
      cout<<"YES";
      ex;
  }
  arr.clear();

  swap(v[0],v[2]);

  for(i=2;i<n;i++)
  {
      if(!collinear(v[0].first,v[0].second,v[1].first,v[1].second,v[i].first,v[i].second))
         {
             p=i;
             arr.pb(mp(v[i].first,v[i].second));
         }
  }
  if(ck())
  {
      cout<<"YES";
      ex;
  }
  arr.clear();

  cout<<"NO";








}
