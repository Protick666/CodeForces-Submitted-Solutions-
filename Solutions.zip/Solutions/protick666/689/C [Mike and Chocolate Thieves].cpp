#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 10000000000000000
ll f;
ll comp(ll a)
{

ll i,j,sum,k,l,p;
l=-1;
sum=0;

for(i=2;;i++)
{
	j=i*i*i;

if((a/j)==0)
   {

   	      if(l==a)
            f=1;
            //cout<<sum<<" "<<p<<endl;

   	  return sum;

   }
 else
   {sum+=a/j;
   p=(a/j)*j;
   if(p>l)
    l=p;


   }


   }




}






main()

{

  ll i,j,k,l,n,h,x,y,r,p;

  cin>>n;

  x=1;
  y=maxx+4;

  while(1)

  {
      if(x==y)
      {
          f=0;
  	      p=comp(x);
  	      if(p==n && f==1)
          {
              cout<<x;

          }
          else
          {
              cout<<"-1";
          }
          exit(0);

      }
  	r=(x+y)/2;
  	//cout<<r<<endl;
  	f=0;
  	p=comp(r);
  	if(p>n)
  	  y=r;
  	else if(p<n)
  	  x=r+1;
  	else if(f==0)
  	   y=r;
  	else

  	  {cout<<r;
  	  exit(0);

  	  }


  }

}
