#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)

vector <double> v;

ll i,j,k,l,n;
double a[1000003];
double x,ans,y,sum;
main()
{
sum=-1;
    cin>>n;

    for(i=0;i<n;i++)
    {
        scanf("%lf%lf",&x,&y);
        ans=atan2(y,x);
        if(ans<0)
        {
            ans=2*3.1415926535897932-(-ans);
        }
        a[i]=ans;
        //cout<<ans<<endl;
    }

    if(n==1)
    {
        cout<<0;
        ex;
    }

    sort(a,a+n);

    for(i=0;i<n;i++)
    {
        x=a[i];
        //cout<<x<<endl;

            y=a[i+1];
        if(i!=n-1)
            {sum=max(sum,y-x);
            //cout<<1<<endl;

            }
        else
            {

                sum=max(sum,2*3.141592653589793238462643-(x-a[0]));
            //cout<<2*3.141592<<endl;
            //cout<<(x-a[0])<<endl;

            }

        //cout<<sum<<endl;
        //cout<<sum<<endl;
    }

    sum=2*3.141592653589793238462643-(sum);
    //cout<<sum<<endl;
    sum=(sum/3.141592653589793238462643)*180;

       cout << fixed << setprecision(10) << sum;












      //cin>>x>>y;
      //cout<<atan2(y,x)<<endl;





}
