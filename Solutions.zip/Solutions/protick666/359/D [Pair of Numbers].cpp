#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
ll a[1000000];
ll fin=0;
ll len=0;
vector <ll> bam;
vector <ll> dan;
vector <ll> val;
main()
{


    ll i,j,k,l,n,sum,p,q,r,store,cur,x,y;
    p=1;
    cin>>n;

    for(i=1;i<=n;i++)
        scanf("%I64d",&a[i]);
    l=1;
    r=1;
    while(1)
    {
        //cout<<l<<" "<<r<<endl;
        q=a[p];
        if(p!=1)
        {
            if((cur%a[p])!=0)
                  l=p;

            r=p;

        }

        while((a[l]%q)==0)
        {l--;
        if(l==0)
            break;
        }
        l=l+1;

        while((a[r]%q)==0)
        {r++;
        if(r==n+1)
            break;
        }
       r=r-1;

       cur=a[p];
       p=r+1;
       store=r-l+1;
       bam.push_back(l);
       dan.push_back(r);
       val.push_back(store);
       if(store>fin)
          fin=store;
        len++;

       if(r==n)
          break;








    }
    sum=0;
    for(i=0;i<len;i++)
    {
        x=bam[i];
        y=dan[i];

        store=y-x+1;

        if(store==fin)
        {
            sum++;
        }

    }

    cout<<sum<<" "<<fin-1<<endl;
    for(i=0;i<len;i++)
    {
        x=bam[i];
        y=dan[i];

        store=y-x+1;

        if(store==fin)
        {
            printf("%I64d ",x);
        }

    }



}
