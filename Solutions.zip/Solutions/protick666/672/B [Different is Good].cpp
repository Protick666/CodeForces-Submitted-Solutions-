#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

ll vis[100];

int main() {
ll i,j,n,sum,ans,store,p,k,f,l,w,x,y;
string s;
char c;
char ch[1000000];

cin>>n;
scanf("%s",ch);
s=ch;
if(n>26)
{
    cout<<"-1";
}
else
{
    sum=0;
    for(i=0;i<n;i++)
    {
        p=s[i]-'a';
        if(vis[p]==0)
        {
            sum++;
            vis[p]=1;
        }
    }
   cout<<n-sum;
}


}
