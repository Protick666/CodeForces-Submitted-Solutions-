#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char bigstr[600];


//int my_array[] = { 10, 5, 25, 15, 20, 30 };

	int comparetor (const void * a, const void * b)
	{
		return ( *(int*)a - *(int*)b );
	}















int main()
{

char str[1000];

char c;
int a[1000];
int s,i,j,b,k,l,prev,last;
s=0;
i=0;
b=0;
scanf("%s",bigstr);
//c=bigstr[0];
while(1)
{c=bigstr[b];
//scanf("%c",&c);
if(c==',')
{str[s]='\0';
s=0;
a[i]=atoi(str);
i++;
b++;
continue;


}
else if(c=='\0')
{
str[s]='\0';
a[i]=atoi(str);
b++;
break;




}






else
{
str[s]=c;

s++;
b++;
}




}


//for(j=0;j<=i;j++)
    //printf("%d\n",a[j]);

if(i==0){
    printf("%d",a[i]);
return 0;}
qsort (a, i+1, sizeof(int), comparetor );

//for(j=0;j<i;j++)
   // printf("%d ",a[j]);
//printf("\n");

for(j=0;j<i;j++){
    //printf("%d\n",a[j]);

     k=j+1;
     while(a[k]==a[k-1] || a[k]==a[k-1]+1)
                    k++;


     if(k-j==1){
        if(j==0)
        printf("%d",a[j]);
        else
        printf(",%d",a[j]);
     continue;
     }

     else{
       if(a[j]==a[k-1])
       {if(j==0)
        printf("%d",a[j]);
        else


        printf(",%d",a[j]);



       }
       else{
        if(j==0)
        printf("%d-%d",a[j],a[k-1]);
        else



        printf(",%d-%d",a[j],a[k-1]);


       }

        j=k-1;
        continue;


     }}

if(j==i)
    printf(",%d",a[i]);






}