#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007

ll a[1000];
void ck(ll n,ll k,ll t)
{
    if(n==0)
        return;
    else if(n==1)
    {
        cout<<1+t<<" ";
        return;
    }
    ll sum,p;
    if(a[n-1]>=k)
    {
        cout<<1+t<<" ";
        ck(n-1,k,t+1);
    }
    else
    {
        cout<<2+t<<" "<<1+t<<" ";
        ck(n-2,k-a[n-1],t+2);

    }
}

int main()
{

    ll i,j,m,n,k;
    a[1]=1;
    a[2]=2;
    fr(i,3,50)
      a[i]=a[i-1]+a[i-2];
    cin>>n>>k;
    ck(n,k,0);
}

