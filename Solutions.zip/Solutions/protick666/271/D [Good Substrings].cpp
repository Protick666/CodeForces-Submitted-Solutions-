#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity


struct tr
{

	tr* cs[26];
};

ll vis[25];
tr root;
ll a[10000];
ll k,ans,l;
void check(ll p)
{
    tr*  t;
    t=&root;
    ll i,j,vul;
    j=p;
    vul=0;
    for(i=p;i<=l;i++)
    {
        if(vis[a[i]]==0)
        {
            vul++;
            if(vul>k)
                break;
        }
        if(t->cs[a[i]]==NULL)
        {
            t->cs[a[i]]=new tr();
            ans++;
            t=t->cs[a[i]];
        }
        else
        {
            t=t->cs[a[i]];

        }
    }

}
int main()
{
    ll n,i,j;
    string s;
    cin>>s;
    l=s.length();
    for(i=0;i<l;i++)
        a[i+1]=s[i]-'a';

    cin>>s;
    for(i=0;i<26;i++)
        vis[i]=(s[i]=='1')?1:0;

    cin>>k;
    //cout<<"alright";
    for(i=1;i<=l;i++)
    {
        check(i);
    }


    cout<<ans;





}
