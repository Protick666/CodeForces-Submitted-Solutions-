#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int



int main() {
ll i,j,n,m,store,sum,v,f,k,ans;
cin>>n>>k;
if(k*3>n)
    cout<<"-1";
else
{
    j=1;
    for(i=1;i<=k;i++)
        {cout<<j<<" ";
        j++;}
    j=1;
    for(i=k+1;i<=2*k;i++)
        {cout<<j<<" ";
        j++;}
    j=1;
    for(i=2*k+1;i<=3*k;i++)
        {
            sum=j+1;
            if(sum>k)
                sum=1;
            cout<<sum<<" ";
            j++;

        }

    for(i=3*k+1;i<=n;i++)
        cout<<"1 ";

}



}
