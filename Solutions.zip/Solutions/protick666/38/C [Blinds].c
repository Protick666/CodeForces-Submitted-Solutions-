#include<stdio.h>

int a[101][2];
main()
{int i,j,k,sum,save,n,len,store,max;
max=0;
sum=0;
save=0;
scanf("%d%d",&n,&len);
for(i=1;i<=n;i++)
{
scanf("%d",&store);
if(store>max)
    max=store;
a[store][0]++;
}




for(i=len;i<=max;i++)
{
  sum=0;
  for(j=i;j<=max;j++)
     sum=sum+(j/i)*(a[j][0]);

//printf("%d\n",i*sum);
   if(i*sum>save){
    // printf("%d  %d\n",i,sum);

     save=i*sum;
   }




}



printf("%d",save);

}