#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007

vector<ll> v[1000000];
ll n;
ll vis[1000000];
ll done[1000000];

void ck(ll a,ll own,ll par)
{
    ll i,j,sum,p;
    p=0;
    done[a]=1;
    vis[a]=own;
    for(i=0;i<v[a].size();i++)
    {
        ll t=v[a][i];
        if(done[t]==1)
            cont;
        p++;

        while(p==own || p==par)
            p++;
        ck(t,p,own);
    }

}
int main()
{
    ll i,j,k,l,sum,ans,x,y;
     cin>>n;
     fr(i,1,n-1)
     {
         cin>>x>>y;
         v[x].pb(y);
         v[y].pb(x);
     }

     ck(1,1,-1);

     sum=-1;
     fr(i,1,n)
       sum=max(sum,vis[i]);

       cout<<sum<<endl;

       fr(i,1,n)
         cout<<vis[i]<<" ";




}


