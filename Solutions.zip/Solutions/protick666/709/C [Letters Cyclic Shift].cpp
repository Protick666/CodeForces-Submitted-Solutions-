#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int

char ch[1000000];
int main()
{
    int i,j,k,l,m,r,n,ans,sum;

    scanf("%s",ch);

    string s;
    s=ch;
    n=s.length();

    l=0;
    while(l<=n-1)
    {
        if(ch[l]!='a')
            break;
        else
            l++;
    }


    if(l<=n-1)
    {
        r=l;

        while(l<=n-1)
    {
        if(ch[l]=='a')
            break;
        else
            l++;
    }
    l--;

    }


    else
    {
        ch[n-1]='z';
        s=ch;
        cout<<s;
        exit(0);

    }

    for(i=r;i<=l;i++)
        ch[i]=ch[i]-1;


  s=ch;
  cout<<ch;


}
