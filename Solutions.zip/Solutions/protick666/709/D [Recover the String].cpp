#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;

//ll a[1000000];
//ll b[1000000];
void fail()
{
    cout<<"Impossible";
    exit(0);
}

ll go(ll a)
{
    if(a==0)
        return 0;
    ll i,j,sum;
    sum=0;
    j=1;
    for(i=1;;i++)
    {
        sum+=j;
        if(sum==a)
            return i+1;
        else if(sum>a)
            fail();
        j++;
    }
}
ll n,i,j,ans,p,q,r,s,t,a,b,c,d,x,y;
main()
{
    cin>>a>>b>>c>>d;
    x=go(a);
    y=go(d);
    if(x==0 && b+c>0)
        x=1;

  if(y==0 && b+c>0)
        y=1;

    if(x*y!=b+c)
        fail();
  if(x==0 && y==0)
    {
        cout<<"0";
        exit(0);
    }
if(x==0)
{
    for(i=1;i<=y;i++)
        cout<<"1";
    exit(0);
}

if(y==0)
{
    for(i=1;i<=x;i++)
        cout<<"0";
    exit(0);
}
    p=b/y;
    t=b%y;
    q=c/y;
    r=c%y;
    for(i=1;i<=p;i++)
        cout<<"0";
    for(i=1;i<=y;i++)
    {
        cout<<"1";
        if(i==r)
            cout<<"0";
    }

    for(i=1;i<=q;i++)
        cout<<"0";




}
