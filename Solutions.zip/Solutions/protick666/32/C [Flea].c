#include<stdio.h>
main()
{
long long int r,c,a,b,e,d,n;
scanf("%I64d%I64d%I64d",&r,&c,&n);
r=r-1;
c=c-1;
a=r/n;
b=r%n;
e=c/n;
d=c%n;
a++;
d++;
b++;
e++;
d=d*e*a*b;
printf("%I64d",d);




}