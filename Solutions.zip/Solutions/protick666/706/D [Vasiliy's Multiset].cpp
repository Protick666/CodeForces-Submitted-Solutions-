#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;
ll a[32];
ll b[32];

class pp
{
   public:
    pp *son[2];
    ll flag[2];
    //ll flag[2];

    pp()
    {
        //if(son[0]==NULL)
         flag[0]=0;
         flag[1]=0;
    }





};
void del(pp *t,ll n)
{
    if(n==32)
        return;


       (t->flag[a[n]])--;
       //t->son[a[n]]=new pp;
       del(t->son[a[n]],n+1);
}
void go(pp *t,ll n)
{
    ll i,j;
    if(n==32)
        return;
    i=(a[n]==1)?0:1;
    j=a[n];

   if(t->flag[i]!=0)
   {
       //t->flag[a[n]]++;
       //t->son[a[n]]=new pp;
       b[n]=1;
       //cout<<b[n]<<endl;

       go(t->son[i],n+1);
   }
   else
   {
       b[n]=0;
       //cout<<b[n]<<endl;
       go(t->son[j],n+1);
   }

}

void start(pp *t,ll n)
{
    if(n==32)
        return;
   if(t->flag[a[n]]==0)
   {
       t->flag[a[n]]++;
       t->son[a[n]]=new pp;
       start(t->son[a[n]],n+1);
   }
   else
   {
       t->flag[a[n]]++;
       //t->son[a[n]]=new pp;
       start(t->son[a[n]],n+1);
   }


}
void fil(ll p)
{
    ll i,j,k;
    j=1;
    for(i=31;i>=1;i--)
    {
       k=p & j;
       if(k==0)
        a[i]=0;
       else
        a[i]=1;
       p=p>>1;
       }
}
pp *root;
void add (ll p)
{
    fil(p);
    pp *t;
    t=root;
    start(t,1);
}
void bad (ll p)
{
    fil(p);
    pp *t;
    t=root;
    del(t,1);
}

void see (ll p)
{
    fil(p);
    pp *t;
    t=root;
    go(t,1);
}

main()
{ ll q,y,i,j,k,l,sum,p,ans;
root=new pp;
    cin>>q;
    string s;
    //fil(8);
    //for(i=1;i<=31;i++)
        //cout<<a[i];
        add(0);
    for(k=1;k<=q;k++)
    {
        cin>>s;
        if(s=="+")
        {
            cin>>p;
            add(p);
        }
         if(s=="-")
        {
            cin>>p;
            bad(p);
        }
         if(s=="?")
        {   cin>>p;
            see(p);
            sum=1;
            ans=0;
            for(i=31;i>=1;i--)
            {
                ans+=b[i]*sum;
                sum*=2;
            }
            cout<<ans<<endl;
        }
    }



}
