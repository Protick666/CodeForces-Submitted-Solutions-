#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector< pair<ll,pair<ll,ll> > > vv[200009];
vector<pair<ll,pair<ll,ll> > > v;
ll pre[1000000];
ll d;

ll ck(ll x,ll y,ll cost)
{
    ll d1=y-x+1;
    if(d-d1<=0)
        return maxx;
    ll d2=d-d1;
    ll lim=vv[d2].size();
    if(pre[d2]>=lim)
        return maxx;
    ll i,j,k,a,b;
    pair<ll,ll> p;

    for(i=pre[d2];i<lim;i++)
    {
       p=vv[d2][i].second;
        k=vv[d2][i].first;
         a=p.first;
         b=p.second;
         if(a>y)
         {
             pre[d2]=i;
             return k+cost;
         }
    }
    pre[d2]=i;
    return maxx;
}

int main()
{
    ll i,j,k,r,l,v1,v2,a,t,x,y,n,m,cost;
    cin>>n>>d;
    pair<ll,ll> p,q;
    fr(i,1,n)
    {
        in2(x,y);
        in(cost);
        p=mp(x,cost);
        v.pb(mp(y,p));
        ll len=y-x+1;
        p=mp(x,y);
        vv[len].pb(mp(cost,p));
    }
    sort(all(v));
    fr(i,0,200005)
    {
        sort(all(vv[i]));
    }
    t=maxx;

    fr(i,0,n-1)
    {
        p=v[i].second;
        y=v[i].first;
        x=p.first;
        cost=p.second;
        t=min(t,ck(x,y,cost));
    }
    if(t==maxx)
        cout<<-1;
    else
        cout<<t;


}
