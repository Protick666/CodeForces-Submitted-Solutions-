#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>


using namespace std;
main()
{
    long long int i,n,x,y;
    cin>>n;
    x=1;
    y=n;
    for(i=1;i<=n;i++)
    {
        if(i%2==1)
        {
            cout<<x<<" ";
            x++;
        }
        else{

            cout<<y<<" ";
            y--;
        }


    }





}
