#include<stdio.h>
main()
{

    int flag,flag2,candle,sum,ng,d,i,j,k,l,min;
    flag=0;
    candle=0;
    scanf("%d%d%d",&ng,&d,&min);
int chk[ng*min];
int a[ng][2];

for(i=0; i<ng; i=i+1)
    {
        scanf("%d",&a[i][0]);
        a[i][1]=0;
    }



    if(min>d)
    {

        printf("-1");
        exit(0);

    }



    for(i=ng-1; i>=0; i=i-1)
    {
        for(j=(a[i][0])-d+1; a[i][1]<min; j=j+1)
        {


            if(j>a[i][0])
              {
                  printf("-1");
                  exit(0);
              }
            flag2=0;
            for(k=0; k<flag; k=k+1)
            {
                if(j==chk[k])
                {
                    flag2=1;
                    break;
                }

            }
            if(flag2==1)
                continue;

            else
            {   candle=candle+1;
                chk[flag]=j;
                flag=flag+1;
                for(l=i; l>=0; l=l-1)
                {
                    if(j<=a[l][0])
                        a[l][1]=a[l][1]+1;

                }

            }

        }

    }





printf("%d",candle);









}
