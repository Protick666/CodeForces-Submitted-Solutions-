#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 100000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll cost[1000009];
ll base[1000009];
ll limit[1000009];
ll pen[1000009];
ll n,m;


ll ck(ll t)
{
    ll i,j,k,x,y,z,l,r;

    ll bs=base[t];
    ll lim=limit[t];
    ll pun=pen[t];
    ll cst=cost[t];

    if(m+bs>lim)
        x=cst+pun*m;
    else
        x=cst;
    y=maxx;
    if(bs<lim)
    {
        k=lim-bs;
        //if(k==)
        z=m/k;
        if((m%k)>0)
            z++;
        y=cst*z;
    }

    return min(x,y);



}



main()
{
    ll sum,j,k,l,i,x,y,ans,t,p;
    //cout<<maxx*10;
    cin>>n>>m;

    fr(i,1,n)
    {
        cin>>x>>y>>t>>p;
        base[i]=x;
        limit[i]=y;
        pen[i]=t;
        cost[i]=p;
    }

    ans=0;

    fr(i,1,n)
    {
        ll y=ck(i);
        //cout<<"incre "<<y<<endl;

        ans+=y;
    }

    cout<<ans;

}
