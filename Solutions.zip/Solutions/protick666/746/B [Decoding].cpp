#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity


ll vis[1000000];

main()
{   ll i,j,k,l,m,n,p,q,t;
string s;
char c[100000];
char ch;
   cin>>n>>s;
   p=n;
   t=0;
   while(1)
   {
       q=(p/2)+(p%2);
       m=0;
       for(i=0;i<n;i++)
       {
           if(vis[i]==0)
            m++;

           if(m==q)
           {
               c[i]=s[t];
               t++;
               vis[i]=1;
               break;
           }

       }
       p--;
       if(p==0)
        break;

   }

   s=c;
   cout<<s;



}


