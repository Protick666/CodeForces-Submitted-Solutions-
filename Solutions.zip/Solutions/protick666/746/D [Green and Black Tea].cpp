#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity
void fail()
{
    cout<<"NO";
    ex;
}

ll vis[1000000];

main()
{   ll i,j,k,l,x,y,a,b,n,z,f,u,c,exa;

  cin>>n>>k>>a>>b;
  char e;
  char o;
  if(a>=b)
  {
      e='G';
      o='B';
  }
  else
  {
      e='B';
      o='G';
  }

  y=max(a,b);
  x=min(a,b);
  if(y==0)
  {
      ex;
  }
  else if(x==0)
  {
      if(y>k)
        fail();
      for(i=1;i<=y;i++)
        cout<<e;
      
      ex;
  }
  b=y/k;
  if((y%k)!=0)
    b++;
  l=b-1;
  u=(b)*k;
  if((x<l))
     fail();
  if(k*(b-1)>=x)
    {f=0;
    z=(x)/(b-1);
    exa=(x)%(b-1);

    }
  else
    {f=1;
    z=(x)/(b);
    exa=(x)%(b);



    }

    //cout<<b<<" "<<f<<endl;
    //cout<<y<<" "<<x<<endl;
  for(i=1;i<=b;i++)
  {
      if(y>=k)
      {
          for(j=1;j<=k;j++)
            cout<<e;
        y-=k;
      }
      else
      {
          for(j=1;j<=y;j++)
            cout<<e;

            y=0;
      }

      if(i==b && f==0)
        break;

    for(j=1;j<=z;j++)
            cout<<o;

    if(i<=exa)
       cout<<o;





  }






}


