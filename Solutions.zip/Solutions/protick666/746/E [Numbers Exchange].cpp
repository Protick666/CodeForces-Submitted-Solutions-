#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity
ll a[1000000];
vector<ll> ee;
vector <ll> oo;
vector<ll> v;
ll marked [1000000];
map<ll,ll> vis;
    ll i,j,k,l,m,n,sum,e,o,x,y,z;

void fail()
{

    cout<<"-1";
    ex;
}


ll odi()
{
    while(vis[x]==1)
    {
        x+=2;
    }
    if(x>m)
        fail();
    vis[x]=1;
    x=x+2;
    return x-2;
}

ll eve()
{
    while(vis[y]==1)
    {
        y+=2;
    }
    if(y>m)
        fail();
    vis[y]=1;
    y=y+2;
    return y-2;
}
main()
{
    ll t,r;
    r=0;
    t=0;
    cin>>n>>m;
    ll p;
    x=1;
    y=2;
    for(i=1;i<=n;i++)
    {
        scanf("%I64d",&a[i]);
    }

    for(i=1;i<=n;i++)
    {
        t=a[i];
        if(vis[t]==0)
        {
            vis[t]=1;
            if((t%2)==1)
                {o++;
                oo.pb(i);
                }
            else
                {e++;
                ee.pb(i);
                }
        }

        else
        {
            marked[i]=1;
            r++;
            v.pb(i);
        }
    }

    sort(v.begin(), v.end(), std::greater<int>());
    sort(ee.begin(),ee.end(), std::greater<int>());
    sort(oo.begin(), oo.end(), std::greater<int>());


    n=n/2;
    if(o<n)
    {
        while(o!=n)
        {
            z++;

            if(r!=0)
            {
                j=v.back();
                v.pop_back();
                r--;
                a[j]=odi();
                o++;


            }

            else
            {

                j=ee.back();
                ee.pop_back();
                e--;
                a[j]=odi();
                o++;

            }
        }

    }


      if(e<n)
    {

        while(e!=n)
        {
            z++;
            if(r!=0)
            {
                j=v.back();
                v.pop_back();
                r--;
                a[j]=eve();
                e++;

            }

            else
            {
                j=oo.back();
                oo.pop_back();
                o--;
                a[j]=eve();
                e++;

            }
        }

    }

    cout<<z<<endl;

    for(i=1;i<=n*2;i++)
        cout<<a[i]<<" ";






}


