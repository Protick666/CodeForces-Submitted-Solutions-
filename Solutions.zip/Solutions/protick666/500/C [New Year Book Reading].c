#include<stdio.h>
main()
{
int f,s,i,j,k,l,sum,sum1,sum2,ik;
scanf("%d%d",&f,&s);
int w[f+1][3];
int a[s];
for(i=1;i<=f;i++)
{scanf("%d",&w[i][0]);
w[i][1]=-1;
w[i][2]=0;
}

for(i=0;i<s;i++)
{scanf("%d",&a[i]);

}


sum=0;
w[a[0]][1]=0;
for(i=1;i<s;i++)
{sum1=0;


for(j=(w[a[i]][1])+1;j<i;j++)
{
    if(w[a[j]][2]==0)
    {
        sum1=sum1+w[a[j]][0];
        w[a[j]][2]=1;



    }

}


for(j=1;j<=f;j++)
{


        w[j][2]=0;

}

w[a[i]][1]=i;
sum=sum+sum1;

}






printf("%d",sum);




}
