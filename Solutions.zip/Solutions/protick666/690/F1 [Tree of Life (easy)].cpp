#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<ll> v[1000000];
ll vis[1000000];
ll ans;

ll lol(ll a)
{
    if(a<1)
    {
        return 0;
    }
    return  a*(a-1)/2;
}

ll dfs(ll a)
{
    vis[a]=1;
    ll i,sum,j,k;
    sum=0;
    for(i=0;i<v[a].size();i++)
    {
        k=v[a][i];
        if(vis[k]==0)
        {
            sum++;
            ans+=dfs(k);
        }
    }
    ans+=lol(sum);
    return sum;
}

int main()
{
    ll i,j,k,l,n,m,p,x,y;
 cin>>n;
 loop(i,n-1)
 {
     cin>>x>>y;
     v[x].pb(y); v[y].pb(x);
 }

 dfs(1);


cout<<ans;

}


