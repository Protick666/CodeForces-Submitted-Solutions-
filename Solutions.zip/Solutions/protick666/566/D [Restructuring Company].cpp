#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 100000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//vector<ll> v[1000002];
ll leftt[1000009];
ll rightt[1000009];
ll a,b,n;
class UF
{
    ll *id, cnt, *sz;
public:
    // Create an empty union find data structure with N isolated sets.
    UF(ll N)
    {
        cnt = N;
        id = new ll[N+1];
        sz = new ll[N+1];
        for(ll i=1; i<=N; i++)
        {
            id[i] = i;
            sz[i] = 1;
        }
    }
    ~UF()
    {
        delete [] id;
        delete [] sz;
    }
    // Return the id of component corresponding to object p.
    ll find(ll p)
    {
        ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root)
        {
            ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
    // Replace sets containing x and y with their union.
    void merge(ll x, ll y)
    {
        ll i = find(x);
        ll j = find(y);
        if (i == j) return;

        // make smaller root point to larger one
        if   (sz[i] < sz[j])
        {
            id[i] = j;
            sz[j] += sz[i];
        }
        else
        {
            id[j] = i;
            sz[i] += sz[j];
        }
        cnt--;
    }
    // Are objects x and y in the same set?
    bool connected(ll x, ll y)
    {
        return find(x) == find(y);
    }
    // Return the number of disjoint sets.
    ll count()
    {
        return cnt;
    }
};
UF magi(1000009);
UF badurmagi(1000009);

void ck(ll par,ll curr,ll y)
{
    ll i,j,p;
    //a=min(a,left[curr]);
    //if(find(curr)>b)
       // b=find(curr);
    b=max(b,rightt[magi.find(curr)]);
    magi.merge(par,curr);
    badurmagi.merge(par,curr);

    p=magi.find(curr);
    //left[p]=a;
    rightt[p]=b;
    if(!(b>y || b>n))
        ck(curr,b,y);
}


main()
{
    ll i,j,k,q,m,sum,p,t,x,y;
    cin>>n>>q;




    fr(i,1,n)
    {
        leftt[i]=i-1;
        rightt[i]=i+1;
    }



    fr(k,1,q)
    {
        in(p);
          in2(x,y) ;

        if(p==3)
        {
            if(badurmagi.find(x)==badurmagi.find(y))
                cout<<"YES"<<endl;
            else
                cout<<"NO"<<endl;
        }
        else if(p==1)
        {
            badurmagi.merge(x,y);
        }

        else
        {
           a=maxx;
           b=-1;
           ck(x,x,y);
        }
    }


}
