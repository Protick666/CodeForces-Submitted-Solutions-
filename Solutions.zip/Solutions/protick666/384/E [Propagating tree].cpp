#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll ft1[400001];
ll ft2[400001];
ll dpo[500000];
ll dpe[500000];
ll dpol[500000];
ll dpel[500000];
// Array size
int N=400001;
// Point query: Returns the value at position b in the array
ll query1(int b)
{
    ll sum = 0;
    for (; b; b -= LSOne(b)) sum += ft1[b];
    return sum;
}
// Point update: Adds v to the value at position k in the array
void update1(int k, int v)
{
    for (; k <= N; k += LSOne(k)) ft1[k] += v;
}

// Range update: Adds v to each element in [i...j] in the array
void range_update1(int i, int j, int v)
{
    update1(i, v);
    update1(j + 1, -v);
}
// Point query: Returns the value at position b in the array
ll query2(int b)
{
    ll sum = 0;
    for (; b; b -= LSOne(b)) sum += ft2[b];
    return sum;
}
// Point update: Adds v to the value at position k in the array
void update2(int k, int v)
{
    for (; k <= N; k += LSOne(k)) ft2[k] += v;
}
// Range update: Adds v to each element in [i...j] in the array
void range_update2(int i, int j, int v)
{
    update2(i, v);
    update2(j + 1, -v);
}
ll t=1;
ll s[500000];
ll f[500000];
ll val[500000];
ll trans[500000];
vector<ll>  v[500000];
ll vis[500000];
ll l=1;
ll flag[500000];
ll suru[500000];
ll ses[500000];
void dfs(ll a)
{
    vis[a]=1;
    s[t]=a;
    suru[a]=t;
    t++;
    ll i,j;
    flag[a]=l%2;

    for(i=0; i<v[a].size(); i++)
    {
        j=v[a][i];
        if(vis[j]==1)
            cont;
        l++;
        dfs(j);
    }
    f[t]=a;
    ses[a]=t;
    t++;

    l--;

}

int main()
{


    ll m,q,i,j,k,l,sum,ans,x,y,b,c;
    scanf("%I64d%I64d",&m,&q);
    loop(i,m)
     scanf("%I64d",&val[i+1]);
    loop(i,m-1)
    {
        scanf("%I64d%I64d",&x,&y);
        v[x].pb(y);
        v[y].pb(x);
    }
    dfs(1);
    x=-1;//odd
    y=-1;//even
    ll p;
    for(i=1;i<=2*m;i++)
    {
        p=s[i];
        //cout<<p<<endl;
        if(p!=0)
        {
            if(flag[p]==1)
                x=i;
            else
                y=i;
        }
        dpo[i]=x;
        dpe[i]=y;
    }




    x=1000002;//odd
    y=1000002;//even

    for(i=2*m;i>=1;i--)
    {
        p=s[i];
        //cout<<p<<endl;
        if(p!=0)
        {
            if(flag[p]==1)
                x=i;
            else
                y=i;
        }
        dpol[i]=x;
        dpel[i]=y;
    }





    i=1;
    j=1;
    k=1;
                //cout<<query1(2)<<endl;

    for(i=1; i<=2*m; i++)
    {
        if(s[i]==0)
            cont;
        p=s[i];
        //cout<<val[p]<<" ";
        if(flag[p]==1)
        {
            //cout<<j<<" "<<val[p]<<endl;
            //cout<<query1(j)<<endl;
            trans[i]=j;
            j++;
        }
        else
        {
            trans[i]=k;
            k++;
        }
    }
    //cout<<trans[suru[5]]<<endl;
    //cout<<query1(2)<<endl;

    for(i=1; i<=q; i++)
    {
        cin>>p;
        if(p==1)
        {
            scanf("%I64d%I64d",&x,&y);
            if(flag[x]==1)
                {range_update1(trans[dpo[suru[x]]],trans[dpo[ses[x]]],y);

                  c=dpe[ses[x]];
                  b=dpel[suru[x]];
                  if(b<=c)
                    range_update2(trans[b],trans[c],-y);

                }
            else
                {range_update2(trans[dpe[suru[x]]],trans[dpe[ses[x]]],y);

                c=dpo[ses[x]];
                  b=dpol[suru[x]];
                  if(b<=c)
                    range_update1(trans[b],trans[c],-y);

                }
        }

        else
        {
            scanf("%I64d",&x);

            if(flag[x]==1)
                printf("%I64d\n",query1(trans[suru[x]])+val[x]);
            else
               printf("%I64d\n",query2(trans[suru[x]])+val[x]);

        }
    }

}
