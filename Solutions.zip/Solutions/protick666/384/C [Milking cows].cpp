#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll a[1000000];
ll dpr[1000000];
ll dpl[1000000];

int main() {

    ll i,j,k,l,sum,ans,n;
    ans=0;
    sum=0;
    cin>>n;

    for(i=1;i<=n;i++)
        scanf("%I64d",&a[i]);

    for(i=1;i<=n;i++)
    {
        if(a[i]==1)
            dpl[i]=1+dpl[i-1];
        else
            dpl[i]=dpl[i-1];
    }


      for(i=n;i>=1;i--)
    {
        if(a[i]==0)
            dpr[i]=1+dpr[i+1];
        else
            dpr[i]=dpr[i+1];
    }
    sum=0;

    for(i=1;i<=n;i++)
    {
        if(a[i]==0)
            continue;
        else
            sum+=dpr[i+1];


    }

    if(sum>ans)
        ans=sum;


       sum=0;

    for(i=n;i>=1;i--)
    {
        if(a[i]==1)
            continue;
        else
            sum+=dpl[i-1];


    }

    if(sum>ans)
        ans=sum;

cout<<ans;

}
