#include<stdio.h>
main()
{
long long int store,n,i,j,sum,x,k;
sum=0;

scanf("%I64d",&n);

long long int a[n][4];

for(i=0;i<n;i++)
{

    a[i][3]=0;
}


for(i=0;i<n;i++)
{

    scanf("%I64d%I64d%I64d",&a[i][0],&a[i][1],&a[i][2]);
}

for(i=0;i<n;i++)
{
    if(a[i][3]==1)
        continue;
    sum++;
    store=a[i][0];
    x=store;
    k=i;
    for(j=i+1;j<n;j++)
    {   if(store<=0)
           break;

       if(a[j][3]==0){
            k++;
        a[j][2]=a[j][2]-store;
        if(a[j][2]<0)
        {
            store=store+a[j][1];
            a[j][3]=1;



        }
     if(k-i<=x)
        store--;
       }

    }









}


printf("%I64d\n",sum);


for(i=0;i<n;i++)
{
    if(a[i][3]==0)
        printf("%I64d ",i+1);



}






}
