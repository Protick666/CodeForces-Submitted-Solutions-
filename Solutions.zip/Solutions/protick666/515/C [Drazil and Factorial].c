#include<stdio.h>
main()
{

int n,i;
int a[4];
for(i=0;i<4;i++)
a[i]=0;
scanf("%d",&n);
getchar();
char str[n+1];

scanf("%s",str);

for(i=0;i<n;i++)
{
if(str[i]=='2')
  a[0]++;
  if(str[i]=='3')
  a[1]++;
if(str[i]=='4'){
  a[0]=a[0]+2;
  a[1]++;}
  if(str[i]=='5')
  a[2]++;
if(str[i]=='6')
  {a[2]++;
  a[1]++;}
if(str[i]=='7')
  a[3]++;
if(str[i]=='8'){
  a[0]+=3;
  a[3]++;}
  if(str[i]=='9'){
  a[3]++;
  a[1]+=2;
  a[0]+=1;}
}


for(i=1;i<=a[3];i++)
 printf("7");
for(i=1;i<=a[2];i++)
 printf("5");

for(i=1;i<=a[1];i++)
 printf("3");

for(i=1;i<=a[0];i++)
 printf("2");




}












