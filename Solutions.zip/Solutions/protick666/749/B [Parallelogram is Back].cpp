#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity
ll a[10];
ll b[10];

ll calc(ll x,ll y,ll p)
{
    ll q;
    q=x+y-p;
    return q;
}
main()
{
    ll m,n,i,j,k,sum;
    cin>>a[1]>>b[1]>>a[2]>>b[2]>>a[3]>>b[3];

    cout<<"3"<<endl;
    cout<<calc(a[1],a[2],a[3])<<" "<<calc(b[1],b[2],b[3])<<endl;
    cout<<calc(a[1],a[3],a[2])<<" "<<calc(b[1],b[3],b[2])<<endl;
    cout<<calc(a[3],a[2],a[1])<<" "<<calc(b[3],b[2],b[1])<<endl;








}
