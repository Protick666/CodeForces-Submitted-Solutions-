#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity
ll a1,a2,n1,n2;
main()
{
    //std::list<int> mylist;
    //int myint;
    //mylist.push_back (myint);

    std::list<ll> my;
    ll n,m,i,k,j,l,sum,ans,x;
    cin>>n;
    char ch[1000002];
    string s;
    //cin>>s;
    scanf("%s",ch);
    s=ch;
    for(i=0; i<n; i++)
    {
        if(s[i]=='D')
        {
            my.pb(0);
            n1++;
        }
        else
        {
            my.pb(1);
            n2++;
        }
    }
    std::list<ll>::iterator fit;

    for (std::list<ll>::iterator it = my.begin();;)
    {
        if(it==my.end())
        {
            it=my.begin();
            cont;
        }

        if(n1==0)
        {
            cout<<"R";
            ex;
        }
         if(n2==0)
        {
            cout<<"D";
            ex;
        }
        x=*it;
        if(x==0)
        {
            if(a2>0)
            {
                a2--;
                fit=it;
                it++;
                my.erase(fit);
                n1--;

            }
            else
            {
                a1++;
                it++;

            }
            cont;
        }

        else
        {
            if(a1>0)
            {
                a1--;
                fit=it;
                it++;
                my.erase(fit);
                n2--;

            }
            else
            {
                a2++;
                it++;

            }
            cont;
        }


    }










}
