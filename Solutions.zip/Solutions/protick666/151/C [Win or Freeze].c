#include<stdio.h>
#include<stdlib.h>
#include<string.h>

long long int x,y;

//long long int dif[11];
//long long int base[12];

//int comparetor (const void * a, const void * b)
	//{
	//	return ( *(int*)a - *(int*)b );
	//



int chke(long long int a)
{
//printf("%I64d\n",a);
    long long int i;
    for(i=2;i<=(int)(sqrt(a))+1;i++)
    {
        if(a%i==0 && i!=a)
        {//printf("%I64d\n",i);
            x=i;
            return 2;
        }
    }

    return 3;

}



int main()
{
long long int n,sum,i,found;


//long long int a[2];
found=0;
sum=0;
scanf("%I64d",&n);
if(n==1){

    printf("1\n");
    printf("0");
    exit(0);




}

if(n==2){

    printf("1\n");
    printf("0");
    exit(0);




}


for(i=2;i<=(int)(sqrt(n))+1;i++){

        //printf("%I64d\n",i);
    if(n%i==0 && n!=i)
    {found=1;
//printf("%I64d\n",i);
        if(chke(n/i)==2){

                printf("1\n");
                printf("%I64d",i*x);
        exit(0);


        }

    else {
        printf("2");
        exit(0);}



}}

printf("1\n");
printf("0");


}
