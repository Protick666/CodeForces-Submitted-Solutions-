
#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000

ll vis[10000000];
ll dp[10000000];

main()
{
    ll i,j,k,l,n,m,q,sum,p,d;
    d=0;

    cin>>n;
    string s;
    //char ch[100000];

    cin>>s;
    //s=ch;
    l=s.length();

    for(i=0;i<l;i++)
        dp[i+1]=s[i]-'0';

    for(i=1;i<=l;i++)
        dp[i]=dp[i]+dp[i-1];

     //for(i=1;i<=l;i++)
       //// cout<<dp[i];

        //cout<<endl;

    for(i=1;i<=l;i++)
    {
        for(j=i;j<=l;j++)
        {
            d++;
            p=dp[j]-dp[i-1];

            vis[p]++;
        }
    }

    if(n==0)
    {
        p=2*d*vis[0];
        p=p-vis[0]*vis[0];
        cout<<p;
        //cout<<"lool";
        exit(0);
    }
    sum=0;

    for(i=1;i<=1000000;i++)
    {
        if(i>n)
            continue;

        if((n%i)!=0)
        {
            continue;
        }

        if((n/i)>1000999)
            {
                //cout<<"poop";
                continue;

            }
        //cout<<i<<" "<<n/i<<endl;

        sum+=vis[i]*vis[n/i];
    }
    cout<<sum;

}
