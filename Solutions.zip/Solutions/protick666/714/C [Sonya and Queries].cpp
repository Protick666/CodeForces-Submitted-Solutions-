#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
map<ll,ll> m;
ll a[1000000];

ll i,j,k,n,p,t,q,sum,r,u,ans,z,x,y,l,g,w;
string s;

ll add(ll p)
{
    ll i,j,q,n;
    q=0;
    n=1;

    for(i=1;i<=18;i++)
    {
        j=p%10;
        j=(j%2);
        q=q+n*j;
        p=p/10;
        n*=10;
        //q=q*10;


    }

    //cout<<q<<endl;

    m[q]++;
}

ll minu(ll p)
{
     ll i,j,q,n;
    q=0;
    n=1;

    for(i=1;i<=18;i++)
    {
        j=p%10;
        j=(j%2);
        q=q+n*j;
        p=p/10;
        n*=10;
        //q=q*10;


    }
    //cout<<q<<endl;

    m[q]--;
}
main()
{
    cin>>t;
    l=1;
    for(k=1;k<=t;k++)
    {
        cin>>s>>p;
        if(s=="+")
        {
            add(p);
        }
        else if(s=="-")
        {
            minu(p);
        }
        else
            cout<<m[p]<<endl;

    }


}
