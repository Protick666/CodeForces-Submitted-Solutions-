#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
ll a[1026];
ll b[1026];

int main()
{

    ll n,k,p,sum,l,t,ans,r,z,m,f,i,j;
    ll *x,*y;
    x=a;
    y=b;

    cin>>n>>k>>p;

    for(i=1; i<=n; i++)
    {
        cin>>t;
        x[t]++;
    }


    loop(j,k)
    {
        sum=0;
        for(i=0; i<=1025; i++)
        {
            t=x[i];
            if(x==0)
                cont;
            m=t/2;
            r=t%2;
            r+=m;
            z=sum%2;
            f=i^p;
            if(z==0)
            {
                y[f]+=r;
                y[i]+=m;
            }
            else
            {
                y[f]+=m;
                y[i]+=r;
            }

            sum+=t;
        }

        swap(x,y);
        for(i=0; i<=1025; i++)
            y[i]=0;
    }


   m=-1;
   k=maxx;
   for(i=0;i<=1025;i++)
   {
       if(x[i]==0)
        cont;
       m=max(m,i);
       k=min(k,i);
   }

   cout<<m<<" "<<k;


}
