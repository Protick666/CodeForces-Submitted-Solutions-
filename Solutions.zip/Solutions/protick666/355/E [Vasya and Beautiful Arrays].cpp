#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000000];
ll dp[3000000];

int main()
{

    ll i,j,n,k;
    cin>>n>>k;
    ll t=100000000000;

    fr(i,1,n)
    {
        cin>>a[i-1];
        t=min(t,a[i-1]);

    }

    fr(i,1,n)
    dp[a[i-1]]++;

    fr(i,1,2000002)
    dp[i]=dp[i-1]+dp[i];

    ll x,y,p,sum;
    for(i=t;i>=1;i--)
    {
        sum=0;
        for(j=1;;j++)
        {
            p=j*i;
            if(p>1000000)
                break;
            x=(j+1)*i-1;
            y=p+k;
            x=min(x,y);
            sum+=dp[x]-dp[p-1];
        }
        if(sum==n)
        {
            cout<<i;
            exit(0);
        }
    }



}

