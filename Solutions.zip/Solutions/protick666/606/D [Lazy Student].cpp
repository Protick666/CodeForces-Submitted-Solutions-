#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity


ll vis[1000001];
ll cap[1000002];
vector<ll> v;
vector < pair< pair<ll,ll>,ll> > t;
vector <pair < ll,pair<ll,ll> > > ans;
pair< ll,ll> p;
//pair<pair<ll,ll>,ll> z;
ll z;


void fail()
{
    cout<<"-1";
    ex;
}




//x pos,y neg,temp pos a, temp neg b
int main()
{
    ll i,j,k,l,sum,r,n,m,x,y,q;


    cin>>n>>m;

    for(i=1;i<=n;i++)
        cap[i]=i+2;

    for(i=1; i<=m; i++)
    {
        cin>>x>>y;
        if(y==0)
            y=1;
        else
            y=0;
        p=mp(x,y);
        t.pb(mp(p,i));
    }

    sort(t.begin(),t.end());
    vis[1]=1;
    v.pb(1);

    q=2;
    l=1;

    for(i=0; i<m; i++)
    {
        p=t[i].fi;
        z=t[i].se;

        x=p.fi;
        y=p.se;
        if(y==0)
        {
            vis[q]=1;
            p=mp(q-1,q);
            ans.pb(mp(z,p));
            v.pb(q);
            q++;
            l=1;
        }
        else
        {
            //cout<<"virgin"<<endl;
            while(1)
            {
                if(l>=q-1)
                {
                    //cout<<v.size()<<" "<<l<<" "<<r<<endl;
                    fail();

                }
                if(cap[l]>q-1)
                {
                    l++;

                    cont;
                }

                p=mp(l,cap[l]);
                ans.pb(mp(z,p));

                cap[l]++;
                break;


            }

        }

    }

    sort(ans.begin(),ans.end());

    for(i=0; i<ans.size(); i++)
        cout<<ans[i].se.fi<<" "<<ans[i].se.se<<endl;

}
