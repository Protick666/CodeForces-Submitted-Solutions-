#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;
int pos[100001];

main()
{

    long long int n,i,j,store,fm,m;
    cin>>n;
    fm=1;
    m=1;
    for(i=0;i<n;i++)
    {
        cin>>store;
        pos[store]=i;

    }

    for(i=2;i<=n;i++)
    {   m=1;
        j=i;
        //cout<<"jan"<<i<<endl;
        while(pos[j]>pos[j-1])
        {
            m++;
            //cout<<m<<" "<<j<<endl;
            j++;

            if(j>n)
                break;

        }
        i=j;

        if(m>fm)
            fm=m;
        if(i>n)
            break;



    }

    cout<<n-fm;

}