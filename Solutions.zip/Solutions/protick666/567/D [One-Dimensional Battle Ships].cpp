#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>


using namespace std;
map<pair<int,int>,int> mymap;
pair<int,int> mypair;
set<int> myset;
  set<int>::iterator it;
  set<int>::iterator stock1;
  set<int>::reverse_iterator stock2;
  pair<std::set<int>::iterator,bool> ret;
  int length,ship,siz;

int borderfinda(int sum)
{
    if(sum<siz)
        return 0;
    else
        return ((sum-siz)/(siz+1))+1;
}
int finda(int sum)
{
   if(sum<siz)
        return 0;
    else
        return ((sum-siz)/(siz+1))+1;
}
int main ()
{  int i,j,k,p,store,now,one,l,x,y,flag,gg;
flag=0;
cin>>length>>ship>>siz;
cin>>p;
for(i=1;i<=p;i++)
{   cin>>store;
    if(flag==1)
        continue;

    if(i==1)
    {    one=store;
        myset.insert(store);
        now=borderfinda(store-1)+borderfinda(length-store);
        //cout<<now<<endl;

    }
    else if(i==2)
    {
        myset.insert(store);
        if(store>one)
        {
            mypair=make_pair(one,store);
            now=finda(store-one-1)+borderfinda(one-1)+borderfinda(length-store);
            //cout<<now<<endl;
            mymap[mypair]=finda(store-one-1);
        }
        else
        {   l=store;
            store=one;
            one=l;
            mypair=make_pair(one,store);
            now=finda(store-one-1)+borderfinda(one-1)+borderfinda(length-store);
            //cout<<now<<endl;
            mymap[mypair]=finda(store-one-1);
        }


    }
    else{
        ret = myset.insert(store);


        it=ret.first;
        stock1=myset.begin();
        stock2=myset.rbegin();

        if(store==*stock1)
        {   std::advance(it,1);
            now=now-borderfinda(*it-1)+finda(*it-store-1)+borderfinda(store-1);
            mypair=make_pair(store,*it);
            mymap[mypair]=finda(*it-store-1);


        }
        else if(store==*stock2)
        {   //cout<<"ok"<<store<<endl;
            std::advance(it,-1);
            now=now-borderfinda(length-*it)+finda(store-*it-1)+borderfinda(length-store);
            mypair=make_pair(*it,store);
            mymap[mypair]=finda(store-*it-1);


        }
        else{
        std::advance(it, -1);
        x=*it;
        std::advance(it, 2);
        y=*it;
        mypair=make_pair(x,y);
        now=now-mymap[mypair]+finda(store-x-1)+finda(y-store-1);
        mypair=make_pair(store,y);
        mymap[mypair]=finda(y-store-1);
        mypair=make_pair(x,store);
        mymap[mypair]=finda(store-x-1);
        //cout<<now<<endl;
        }




    }
    //cout<<now<<" "<<i<<endl;
    if(now<ship)
    {
        flag=1;
        gg=i;

    }
}


  // set some initial values:



               // no new element inserted





    if(flag==1)
        cout<<gg;
    else
        cout<<"-1";
}
