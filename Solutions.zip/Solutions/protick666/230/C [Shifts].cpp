#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[101][10001];

ll dpr[101][10001];
ll dpl[101][10001];

ll val[1000000];
int main()
{
    ll n,i,j,k,l,sum,ans,temp,h,p,q,r,c,x,y,f,f1,f2;
    cin>>r>>c;
    ans=0;
    string s;
    char ch[1000000];
    for(i=1;i<=r;i++)
    {
        scanf("%s",ch);
        s=ch;
        for(j=1;j<=c;j++)
        {
            a[i][j]=(s[j-1]=='0')?0:1;
        }

    }


    for(i=1;i<=r;i++)
    {
        for(j=1;j<=c;j++)
        {
            if(a[i][j]==1)
                dpl[i][j]=j;
            else
                dpl[i][j]=dpl[i][j-1];

        }

        for(j=c;j>=1;j--)
        {
            if(a[i][j]==1)
                dpr[i][j]=j;
            else
                dpr[i][j]=dpr[i][j+1];

        }


    }

    /*for(i=1;i<=r;i++)
    {

        for(j=1;j<=c;j++)
        {
            cout<<dpl[i][j]<<" ";
        }
        cout<<endl;

    }

cout<<endl;
      for(i=1;i<=r;i++)
    {

        for(j=1;j<=c;j++)
        {
            cout<<dpr[i][j]<<" ";
        }
        cout<<endl;

    }

    cout<<endl;


        for(i=1;i<=r;i++)
    {

        for(j=1;j<=c;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl;

    }

    cout<<endl;

*/
    for(i=1;i<=r;i++)
    {
        for(j=1;j<=c;j++)
        {
            if(a[i][j]==1)
                val[i]=1;


        }




    }

    ans=1000000000;

    for(j=1;j<=c;j++)
    {
        sum=0;
        f=0;

        for(i=1;i<=r;i++)
        {
            if(val[i]==0)
            {
                f=1;
                break;
            }

            p=dpl[i][j];
            if(p==0)
                p=100000000;
            else
            p=abs(p-j);
             q=dpr[i][j];
             if(q==0)
                q=100000000;
            else
            q=abs(q-j);
            x=dpl[i][c];
            x=c-x+j;
            y=dpr[i][1];
            y=y+c-j;
           f1=min(x,y);
           f2=min(p,q);
           sum+=min(f1,f2);
           //if(j==4)
            //cout<<p<<" "<<q<<" "<<x<<" "<<y<<endl;
          //sum+=min(x,y,p,q);


        }
        if(f==1)
            continue;

       //cout<<sum<<" "<<j<<endl;
        if(sum<ans)
           {

            ans=sum;
            //cout<<j<<endl;

            }


    }


    if(ans==1000000000)
        cout<<"-1";
    else
        cout<<ans;




}
