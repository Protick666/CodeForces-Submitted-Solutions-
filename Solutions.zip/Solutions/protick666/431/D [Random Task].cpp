#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 1000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[66];
ll bi[66][66];


ll bii(ll i,ll j)
{
    if(i<j || j<0)
        return 0;
    else if(j==0 || j==i)
    {
        bi[i][j]!=1;
        return 1;
    }
    else if(bi[i][j]!=-1)
        return bi[i][j];

    else
    {
        bi[i][j]=bii(i-1, j-1) + bii(i-1,j);
        return bi[i][j];
    }


}

ll ck1(ll u,ll k)
{
    ll n=u;
    ll i,j,sum;
    ll p=1;
    for(i=1; i<=64; i++)
    {
        a[i]=p & n;
        //if(u==1776)
            //cout<<a[i]<<" ";
        n=n>>1;
    }
    //cout<<endl<<endl;
    sum=0;
    i=64;
    while(a[i]==0)
        i--;
    i--;
    //if(u==1776)
        //cout<<i<<endl;
    ll y=1;
    for(; i>=1; i--)
    {
        if(a[i]==0)
        {

            sum+=bii(i-1,k-y-1);
        }
        else
            y++;

    }

    return sum;
}

ll ck2(ll n,ll k)
{
    ll i,j,sum,t;
    ll p=1;
    t=0;
    for(i=1; i<=64; i++)
    {
        a[i]=p & n;
        t+=a[i];
        n=n>>1;
    }
    sum=0;
    i=64;
    while(a[i]==0)
        i--;
    i--;
    ll y=1;
    for(; i>=1; i--)
    {
        if(a[i]==1)
        {
            sum+=bii(i-1,k-y);
            y++;
        }
    }
    if(t==k)
        sum++;


    return sum;
}

int main()
{


    ll i,j,k,sum,n,r,m,l,v1,v2,a,t;
    cin>>m>>k;
    l=1;
    r=1000000000000000000;

    for(i=0; i<=65; i++)
    {
        for(j=0; j<=65; j++)
            bi[i][j]=-1;
    }
    while(1)
    {

        ll mid=(l+r)/2;
        //cout<<mid;
        ll result=ck1(mid,k)+ck2(mid*2,k);
        if(result==m)
        {
            cout<<mid;
            ex;
        }
        else if(result>m)
        {
            r=mid-1;
        }
        else
            l=mid+1;
    }


}
