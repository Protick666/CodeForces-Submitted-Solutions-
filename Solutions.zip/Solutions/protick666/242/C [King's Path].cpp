#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

#define m 1000000000
pair<long long int,long long int> p,s,f;
queue<pair<long long int,long long int> > q;
map<pair<long long int,int>,long long int> valid;
map<pair<long long int,long long int>,long long int> vis;
map<pair<long long int,long long int>,long long int> dis;




main()
{
    long long int k,n,s1,s2,sum,x,y,a,b,i,j,row,le,ri,l;
    cin>>x>>y>>a>>b;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>row>>le>>ri;
        for(j=le;j<=ri;j++)
        {
            p=make_pair(row,j);
            valid[p]=1;
        }



    }

    p=make_pair(x,y);
    f=make_pair(a,b);
    vis[p]=1;
    dis[p]=0;
    q.push(p);
    while(!q.empty())
    {
        p=q.front();
        q.pop();

        i=p.first;
        j=p.second;

        for(k=-1;k<=1;k=k+1)
        {
            for(l=-1;l<=1;l=l+1)
            {

                if(l==0 && k==0)
                    continue;

                s1=i+k;
                s2=j+l;

                if(((s1>=1) && (s1<=m))&&((s2>=1) && (s2<=m)))
                {
                    s=make_pair(s1,s2);
                    if(vis[s]==0 && valid[s]==1)
                    {
                        q.push(s);
                         //cout<<s.first<<" "<<s.second<<endl;
                        vis[s]=1;
                        dis[s]=dis[p]+1;
                        if(s==f)
                        {
                            cout<<dis[s];
                            exit(0);
                        }

                    }
                }
            }
        }



    }



    cout<<"-1"<<endl;



}











