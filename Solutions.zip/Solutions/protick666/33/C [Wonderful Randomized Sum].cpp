#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000009];
ll dpl[1000009];
ll dpr[1000009];
ll dp[1000009];
main()
{
    ll sum,j,k,l,i,n,x,y,ans,t,p;
    cin>>n;
    ans=0;
    fr(i,1,n)
    {
        cin>>a[i];
        ans+=a[i];

    }
    t=ans;
    fr(i,1,n)
    dpl[i]=a[i]+dpl[i-1];
    fur(i,n,1)
    dpr[i]=a[i]+dpr[i+1];
    dp[n+1]=n+1;
    sum=0;
    fur(i,n,1)
    {
        x=dpr[i];
        x*=-1;
        if(x>sum)
            {dp[i]=i;
             sum=x;
            }
        else
            dp[i]=dp[i+1];
    }


    fr(i,0,n)
    ans=max(ans,t+dpl[i]*(-2)+dpr[dp[i+1]]*(-2));

    cout<<ans;

}
