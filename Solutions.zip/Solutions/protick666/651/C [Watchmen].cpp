#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;
map <long long int,long long int> x;
map <long long int,long long int> y;
map <pair<long long int,long long int>,long long int > vis;
vector <pair<long long int,long long int> > same;
pair<long long int,long long int> p;
vector <long long int> vx;
vector <long long int> vy;
main()
{
   long long int i,j,n,q,store,a,b,f,sum,o,e,k,c,d,l,v,s,ex,oi;
ex=0;
oi=0;
s=0;
sum=0;

   cin>>n;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d%I64d",&a,&b);
       p=make_pair(a,b);
       if(vis[p]==0)
        vis[p]=1;
       else
       {
           if(vis[p]==1)
           {
               same.push_back(p);
               s++;
               vis[p]++;
           }
           else
            vis[p]++;



       }



       x[a]++;
       if(x[a]==1){
        vx.push_back(a);
        ex++;
       }

        y[b]++;
       if(y[b]==1){
        vy.push_back(b);
        oi++;
       }


   }



   for(i=0;i<ex;i++)
   {
       q=x[vx[i]];
       if(q==1)
        continue;


       sum=sum+(q*(q-1))/2;



   }

    for(i=0;i<oi;i++)
   {
       q=y[vy[i]];
       if(q==1)
        continue;


       sum=sum+(q*(q-1))/2;



   }

   for(i=0;i<s;i++)
   {
       p=same[i];
       q=vis[p];

       sum=sum-(q*(q-1))/2;



   }



cout<<sum;


}
