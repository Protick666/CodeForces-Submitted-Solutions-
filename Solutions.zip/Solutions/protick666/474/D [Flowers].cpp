#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

#define bal 1000000007
long long int dp[1000001];
long long int fin[1000001];

main()
{

long long int a,b,g,p,q,l,h,e,x,y,i,j,s1,s2,ans,m,sum,r,n;
cin>>q>>g;
for(i=1;i<=100000;i++)
{
    if(i<g)
        dp[i]=1;
    else if(i==g)
        dp[i]=2;
    else
        dp[i]=(dp[i-1]+dp[i-g])%bal;


}

for(i=1;i<=100000;i++)
    fin[i]=(dp[i]+fin[i-1])%bal;


for(i=1;i<=q;i++)
{
    scanf("%I64d%I64d",&a,&b);
    p=fin[b]-fin[a-1];
    if(p<0)
    {
        r=fin[b]+bal;
        p=r-fin[a-1];
    }

    printf("%I64d\n",p);


}



}

