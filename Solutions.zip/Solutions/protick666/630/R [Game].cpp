#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;











main()
{

    long long int i,flag,j,k,l,n,o,sum,q,a,b,store;
    cin>>n;

    if(n%2==1)
        cout<<"1";
    else
        cout<<"2";

}