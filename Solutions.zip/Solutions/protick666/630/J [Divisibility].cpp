#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

//ll a[1000004];

int main()
{
    ll n,i,j,k,l,sum,ans,x,y,temp,q,p,f,m,u,v,z;
    cin>>n;

    cout<<n/2520;

}
