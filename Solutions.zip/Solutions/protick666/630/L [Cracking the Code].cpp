#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int




int main() {
ll i,j,n,store,p,k,f,l,w,q,a,b,c,d,e,ans,sum;
ans=0;
cin>>n;

for(i=1;i<=5;i++)
{
    p=n%10;
    n=n/10;
    if(i==1)
        ans+=p*100;
    if(i==2)
        ans+=p*10;
    if(i==3)
        ans+=p*1000;
    if(i==4)
        ans+=p;
    if(i==5)
        ans+=p*10000;


}
sum=ans;
for(i=1;i<=4;i++)
{
    sum=sum*ans;
    sum=sum%100000;
}
p=0;
ans=sum;
while(ans!=0)
{
    p++;
    ans=ans/10;
}
p=5-p;
if(sum==0)
    p=4;
for(i=1;i<=p;i++)
    cout<<"0";
cout<<sum;


}
