#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

main()
{
    long long int n,i,j,a,b;
    cin>>n;
    if(n==1)
        cout<<1;
    else{
        a=1;
        for(i=n;i<=n+5-1;i++)
            a=a*i;
        a=a/120;

        b=1;
        for(i=n;i<=n+3-1;i++)
            b=b*i;
        b=b/6;

        a=a*b;
        cout<<a;





    }

}