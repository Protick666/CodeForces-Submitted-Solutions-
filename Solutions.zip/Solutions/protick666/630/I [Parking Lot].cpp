#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;


#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

     #define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _b : _a; })







main()
{
    long long int sum,n,k,i,j,a,b,p,q,r,g,aa,bb,flag;
    cin>>n;
    if(n==3)
    {
        cout<<24;
        exit(0);
    }
    sum=0;
    a=1;
    for(i=1;i<=n-3;i++)
    {
        a=a*4;
    }

    b=2*3*a+(n-3)*9*(a/4);
    b=b*4;
    cout<<b;}
