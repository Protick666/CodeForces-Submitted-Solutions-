#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000


int main()
{
   ll n,i,j,k,l,sum,ans,z,x,y,w1,w2,d1,d2,e,d;
   cin>>n;

   ans=2;
   sum=0;

   for(i=1;i<=n;i++)
   {
       sum+=ans;
       ans*=2;

   }



cout<<sum;



}
