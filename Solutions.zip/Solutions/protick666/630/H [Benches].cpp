#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

main()
{
    long long int n,i,j,a,b;
    cin>>n;
    a=n*(n-1)*(n-2)*(n-3)*(n-4)/120*(n)*(n-1)*(n-2)*(n-3)*(n-4);
    cout<<a;

}
