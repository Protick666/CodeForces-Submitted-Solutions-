#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

main()
{
    long long int n,i,j,a,b;
    cin>>n;
    a=n/2+n/3+n/5+n/7-n/6-n/10-n/14-n/15-n/21-n/35+n/30+n/42+n/70+n/105-n/210;
    n=n-a;
    cout<<n;

}