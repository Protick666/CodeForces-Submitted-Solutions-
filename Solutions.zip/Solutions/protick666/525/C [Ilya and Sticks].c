
#include<stdio.h>
#include<stdlib.h>
#define max 100001
long long int a[max];
int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)b - *(int*)a );
}

main()
{  long long int n,i,j,k,sum,store,flag;
store=1;
sum=0;
    scanf("%I64d",&n);
    for(i=0;i<n;i++)
        scanf("%I64d",&a[i]);

    qsort(a,n,sizeof(long long int),cmpfunc);
    printf("\n");



    flag=0;
    for(i=0;i<n-1;i++)
    {
        if(flag==2)
        {
            sum=sum+store;
            store=1;
            flag=0;

        }


        if((a[i]==a[i+1]))
          {
              store=store*a[i];

              i=i+1;
              flag++;
              //printf("yo\n");
              continue;

          }

          if((a[i]==1+a[i+1]))

          {
              store=store*a[i+1];

              i=i+1;
              flag++;
              //printf("bo\n");
              continue;

          }




    }

    if(flag==2)
        {
            sum=sum+store;
            store=0;
            flag=0;

        }


    printf("%I64d",sum);







}
