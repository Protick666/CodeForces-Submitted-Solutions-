#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
    string s;
    ll a[1000];
ll p[1000];


    ll i,j,k,l,n,h,x,y,r,ans,sum,m,q,t,z;

    void print()

    {
        cout<<"Possible"<<endl;
        ll i,j;

        for(i=0;i<=k;i++)
        {
            if(i==0)
                cout<<a[i]<<" ";
            else
            {
                if(p[i]==1)
                    cout<<"+ ";
                else
                    cout<<"- ";
                cout<<a[i]<<" ";
            }
        }
        cout<<"= ";
        cout<<n;
        ex;
    }

ll check(string s)
{
    ll i,j,sum,k;
    sum=0;
    k=1;
    j=s.length();
    for(i=j-1;i>=0;i--)
    {
        sum=sum+(s[i]-'0')*k;
        k*=10;
    }

    return sum;



}


main()
{
ll f,maxx,minn;
  //t=0;
  p[0]=1;
  k=1;
  x++;
  f=0;
   while(1)
   {
       string s;
       cin>>s;
       if(s=="+" || s=="-")
        {
            (s=="+")?(x++):(y++);
            p[k]=(s=="+")?1:-1;
            //cout<<p[t]<<endl;
            k++;
        }
        else if(s=="=")
            f=1;
        else if(f==1)
        {
            n=check(s);
            break;
        }

    }


    //cout<<n<<endl;

    //for(i=0;i<k;i++)
        //cout<<p[i]<<" ";


       maxx=x*n-y;
       minn=x-y*n;
       if(!(maxx>=n && minn<=n))
       {
           cout<<"Impossible";
           ex;
       }

       k--;
       sum=x*1-y*1;
       for(i=0;i<=k;i++)
        a[i]=1;

        //cout<<k<<" "<<sum<<endl;

       while(1)
       {

           if(sum==n)
            print();

            else if(sum>n)
            {
                for(i=0;i<=k;i++)
                {
                    if(p[i]==-1 && a[i]<n)
                    {
                        m=n-a[i];
                        z=sum-n;
                        z=min(m,z);
                        a[i]+=z;
                        sum-=z;
                        break;

                    }
                }

            }

            else if(sum<n)
            {

                for(i=0;i<=k;i++)
                {
                    if(p[i]==1 && a[i]<n)
                    {
                        m=n-a[i];
                        z=n-sum;
                        z=min(m,z);
                        a[i]+=z;
                        sum+=z;
                        break;

                    }
                }

            }


       }


}












