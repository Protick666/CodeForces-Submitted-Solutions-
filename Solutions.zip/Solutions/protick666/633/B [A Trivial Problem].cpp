#include <cstdio>
#include <iostream>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;

#define modd 1000000007;





main()
{

	long long int n,i,j,k,l,store,p,cat,jam,d,diva,sum,power;
	cin>>n;
	sum=0;

	for(i=1;;i++)
    {
        store=i;

        while(store%5==0)
        {
            store=store/5;
            sum++;

        }

        if(sum==n)
                break;
        if(sum>n)
            break;



    }

    if(sum>n)
        cout<<"0";
    else{


        cout<<"5"<<endl;

        for(j=i;j<=i+4;j++)
            cout<<j<<" ";



    }


}