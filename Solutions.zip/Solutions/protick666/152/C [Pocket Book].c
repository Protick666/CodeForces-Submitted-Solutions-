#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{int a,b,c,d,e,i,j,k,p,q;
 long long int r=1,count=0;
 char *x[105];
 int z[30];
 for(i=0;i<30;i++)
 {z[i]=0;}
 scanf("%d %d",&a,&b);
 for(i=0;i<a;i++)
 {x[i]=(char *)malloc(b+1);
  scanf("%s",x[i]);}
  for(i=0;i<b;i++)
  { count=0;
    for(k=0;k<30;k++)
    {
                 z[k]=0;
    }
    for(j=0;j<a;j++)
  { if(z[x[j][i]-65]!=1)
     {z[x[j][i]-65]=1;
      count++;}}
      r=(r*count)%1000000007;}


      printf("%I64d",r%1000000007);
      return 0;}