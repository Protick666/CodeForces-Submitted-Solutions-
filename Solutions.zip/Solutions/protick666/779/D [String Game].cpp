#include <bits/stdc++.h>
using namespace std;


#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl

ll a[1000002];
ll val [200003];
string s,t;

ll chk(ll q)
{
        //cout<<q<<" "<<t.length()<<endl;

    if(q>s.length())
        return 0;
    ll i,j,k;

    for(i=0; i<=200002; i++)
        val[i]=0;

    for(i=1; i<=q; i++)
        val[a[i]]=1;
    i=0;
    j=0;
    for(j=0; j<t.length(); j++)
    {
        //cout<<j<<endl;
        while(s[i]!=t[j] || val[i]==1)
        {
            i++;
            if(i>=s.length())
                return 0;
        }
        i++;
        if(i>=s.length() && j<t.length()-1)
            return 0;
    }
    return 1;
}

int main()
{
    ll n,i,j,k,l,x,y,z,q,f,pos,sum,r,m;
    cin>>s>>t;
    for(i=1; i<=s.length(); i++)
    {
        cin>>x;
        a[i]=x-1;
    }
    l=1;
    r=s.length();

    while(1)
    {
        //cout<<l<<" "<<r<<endl;
        if(l>r)
        {
            sum=0;
            break;
        }
        m=(l+r)/2;
                //cout<<m<<endl;

        x=chk(m);
        //cout<<m<<endl;
        if(x==0)
        {
            r=m-1;
            cont;
        }
        else
        {
            y=chk(m+1);
            if(y==0)
            {
                sum=m;
                break;
            }
            else
            {
                l=m+1;
                cont;
            }
        }
    }
    cout<<sum;

}
