#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};
ll head[10000];
ll vis[10000];
ll lol[10000];
ll g[10000];
ll marked[10000];

ll fix(ll a)
{
    if(a==0)
        return 0;
    else if(a==1)
        return 0;
    return a*(a-1)/2;

}
vector<ll> v;

main()
{   ll i,j,k,l,n,m,e,x,y,r,p,b,h,c;

    /*//pad=new UF(5);
    t.merge(1,2);
    t.merge(3,4);
    //t.merge(3,2);
    for(i=1;i<=5;i++)
        t.find(i);
    for(i=1;i<=5;i++)
        cout<<t.find(i)<<endl;*/
    cin>>n>>m>>k;
     UF t(n);
    for(i=1;i<=k;i++)
        cin>>g[i];

    for(i=1;i<=m;i++)
    {
        scanf("%I64d%I64d",&x,&y);
          t.merge(x,y);
    }

    for(i=1;i<=n;i++)
    {
        x=t.find(i);
        vis[x]++;

    }
    for(i=1;i<=k;i++)
    {
        x=t.find(g[i]);
        marked[x]=1;
    }
    e=0;
    for(i=1;i<=n;i++)
    {
        x=t.find(i);
        if(lol[x]==0 && marked[x]==0)
        {
            v.pb(vis[x]);
            e+=vis[x];
            lol[x]=1;
        }
    }
    y=-1;

    for(i=1;i<=n;i++)
    {
        if(marked[i]==1)
            y=max(y,vis[i]);
    }



    r=0;
    for(i=1;i<=n;i++)
    {
        p=vis[i];
        r+=fix(p);
    }

    b=0;
    c=e;
    for(i=0;i<v.size();i++)
    {
        x=v[i];
        h=c-v[i];
        b+=x*h;
        c=c-v[i];
    }


    cout<<b+r+y*e-m<<endl;
    /*cout<<y<<" "<<e<<endl;
    for(i=1;i<=n;i++)
        cout<<marked[i]<<" ";

    cout<<endl;
    for(i=1;i<=n;i++)
        cout<<vis[i]<<" ";*/



}


