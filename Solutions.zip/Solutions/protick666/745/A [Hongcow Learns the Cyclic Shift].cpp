#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

map < string,int> m;

int main()
{
    ll i,j,k,sum,ans,n,d,x,b,r,q,p,l;
    string s;
    cin>>s;
    l=s.length();
    ans=0;
    string t;
    for(int i = 0; i < l; i++)
        {t=s.substr(i) + s.substr(0, i);
        if(m[t]==0)
        {
            m[t]=1;
            ans++;
        }
        }

        cout<<ans;





}
