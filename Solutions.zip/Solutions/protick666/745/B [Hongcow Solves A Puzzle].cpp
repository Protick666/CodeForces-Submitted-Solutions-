#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity
ll a[1000][1000];
ll vis[10000];


void fail()
{
    cout<<"NO";
    ex;
}
main()
{   ll i,j,k,l,n,m,e,x,y,r,p,b,h,c,u,v,d,t,o;
   cin>>n>>m;
   e=0;
   string s;
   for(i=1;i<=n;i++)
   {
       cin>>s;
       for(j=0;j<m;j++)
       {
           if(s[j]=='X')
           {
               e++;
               a[i][j+1]=1;
               vis[i]=1;
           }
           else
           {
               a[i][j+1]=0;
           }

       }
   }

 //x y  u v
 //d t  l m

 for(i=1;i<=n;i++)
 {
     if(vis[i]==1)
     {
         for(j=1;j<=m;j++)
         {
             if(a[i][j]==1)
             {
                 x=i;
                 y=j;
                 break;
             }
         }

         for(j=m;j>=1;j--)
         {
             if(a[i][j]==1)
             {
                 u=i;
                 v=j;
                 break;
             }
         }

         break;
     }
 }




  for(i=n;i>=1;i--)
 {
     if(vis[i]==1)
     {
         for(j=1;j<=m;j++)
         {
             if(a[i][j]==1)
             {
                 d=i;
                 t=j;
                 break;
             }
         }

         for(j=m;j>=1;j--)
         {
             if(a[i][j]==1)
             {
                 l=i;
                 o=j;
                 break;
             }
         }

         break;
     }
 }




 if(y!=t || v!=o)
    {

        fail();

    }
 if((d-x+1)*(v-y+1)!=e)
    {

        fail();

    }


 for(i=x;i<=d;i++)
 {
     for(j=y;j<=v;j++)
     {
         if(a[i][j]==0)
            fail();
     }
 }




cout<<"YES";



}


