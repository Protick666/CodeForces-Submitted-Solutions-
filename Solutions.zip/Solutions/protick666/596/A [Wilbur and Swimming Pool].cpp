#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>

using namespace std;


main()
{    int i,n,j,k,a,b,x,y,store;
    pair<int,int> poop[4];
    cin>>n;


    if(n==1)
    {  cin>>x;
        cout<<"-1";
        //exit(0);
    }
    else if(n==2)
    {
        cin>>a>>b;
        cin>>x>>y;

        if(a==x || b==y)
        {
            cout<<"-1";
            //exit(0);
        }
        else{

            cout<<abs(a-x)*abs(b-y);
            //exit(0);

        }


    }
    else
    {     for(i=0;i<n;i++)
        {
            cin>>a>>b;
            poop[i]=make_pair(a,b);
        }


        sort(poop,poop+n);

        if(poop[0].first==poop[1].first)
        {
            store=abs(poop[0].second-poop[1].second)*abs(poop[0].first-poop[2].first);
            cout<<store;
        }
        else{
            store=abs(poop[2].second-poop[1].second)*abs(poop[0].first-poop[1].first);
            cout<<store;

        }
    }




}
