#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>

using namespace std;



main()
{    long long int i,n,j,k,a,b,x,y,store,sum;
     sum=0;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>x;
        if(i==0){
            store=x;
          sum=sum+abs(x);
          continue;
        }

        sum=sum+abs(store-x);
        //cout<<sum<<endl;
        store=x;





    }

cout<<sum;


}
