
#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include <map>
#include<algorithm>
#include<set>


using namespace std;
#define max 100004

int weight[max];
int w;
int ori[max];
pair<int,int> poop[max];
map<int,vector<pair<int,int> > > mymap;
vector<pair<int,int> > fin;
map<int,int> county;
map<int,int> iter;

pair<int,int> mag,mag1;

set<int> ase;


bool compare(const pair<int, int>&p1, const pair<int, int>&p2)
{    if(p1.second == p2.second && p1.first == p2.first) return true;
    else if(p1.second < p2.second && p1.first < p2.first) return true;
    else if(p1.second > p2.second && p1.first > p2.first) return false;
    else if(p1.second == p2.second )
        return p2.first>p1.first;
    else if(p1.first == p2.first)
        return p2.second>p1.second;
    else return abs(p1.second-p1.first) <= abs(p2.second-p2.first);

}
main()
{    int i,n,j,k,a,b,x,y,store,flag1,flag2,found,jj;
found=0;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>x>>y;
        mag=make_pair(x,y);
        mymap[y-x].push_back(mag);
        county[y-x]++;
        ase.insert(y-x);
    }

    for (set<int>::iterator m = ase.begin(); m != ase.end(); m++) {
   sort(mymap[*m].begin(),mymap[*m].end(),compare);


}






    for(i=0;i<n;i++){
        cin>>weight[i];

    }
  found=0;

   for(i=0;i<n;i++){
        jj=weight[i];

        if(county[jj]==0)
        {
            found=1;
            break;

        }
        if(iter[jj]>=county[jj])
                {
            found=1;
            break;

        }
        if(i==0)
        {
            fin.push_back(mymap[jj][iter[jj]]);
            iter[jj]++;
            continue;
        }

        mag=mymap[jj][iter[jj]];
        mag1=fin.back();
        if(mag1.second >= mag.second && mag1.first >= mag.first)
             {
            found=1;
            break;
            }

        else{

            fin.push_back(mag);
            iter[jj]++;
            continue;
            }









    }

    if(found==1)
    {
        cout<<"NO";
        exit(0);
    }
    else{
         cout<<"YES"<<endl;
        for(i=0;i<fin.size();i++)
            cout<<fin[i].first<<" "<<fin[i].second<<endl;


    }







}