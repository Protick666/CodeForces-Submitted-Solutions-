#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000
//#define LSOne(S) (S & (-S))



ll a[100000][10];

ll dp[100000][10];

int main()
{

    ll n,i,j,k,sum,ans,store,x,y,m,p,r,g,b,t,q;

    cin>>n>>m;

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
            scanf("%I64d",&p);
            a[i][j]=p;
            dp[i][j]=p;
        }
    }






    for(i=1;i<=n;i++)
    {

        for(j=1;j<=m;j++)
        {

            if(j==1)
                dp[i][j]=dp[i-1][j]+a[i][j];
            else
            {
                p=dp[i-1][j];
                q=dp[i][j-1];
                p=max(p,q);
                dp[i][j]=p+a[i][j];
            }

        }



    }


    for(i=1;i<=n;i++)
        cout<<dp[i][m]<<" ";






}
