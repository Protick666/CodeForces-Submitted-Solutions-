#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair

ll a[1000000];

ll b[1000000];
ll root[1000000];
ll f[1000000];
vector<ll> v;

class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};


main()
{   ll i,n,j,k,l,sum,x,y,ans;
cin>>n;
   for(i=1;i<=n;i++)
    cin>>a[i];
   for(i=1;i<=n;i++)
    cin>>b[i];
    UF t(n);
    ans=0;
    for(i=1;i<=n;i++)
        f[b[i]]=1;
  f[n+1]=1;
  f[0]=1;
    for(i=1;i<=n;i++)
    {
        if(f[i]==1)
            continue;
      j=i;
      while(f[j]!=1)
        j++;
      j--;
      for(k=i;k<=j;k++)
        t.merge(i,k);
      sum=0;
      for(k=i;k<=j;k++)
        sum+=a[k];
      if(sum>ans)
        ans=sum;
    l=t.find(i);
    root[l]=sum;
    i=j+1;


    }

    v.pb(ans);

    for(i=n;i>=2;i--)
    {
        l=b[i];
        f[l]=0;
        x=l-1;
        y=l+1;
        if(f[x]==1 && f[y]==1)
        {
            root[l]=a[l];
            if(a[l]>ans)
                ans=a[l];

        }
        else if(f[x]==1)
        {
            sum=root[t.find(y)]+a[l];
            t.merge(l,y);
            root[t.find(y)]=sum;
            if(sum>ans)
                ans=sum;

        }

         else if(f[y]==1)
        {
            sum=root[t.find(x)]+a[l];
            t.merge(l,x);
            root[t.find(x)]=sum;
            if(sum>ans)
                ans=sum;


        }
        else
        {
            sum=root[t.find(x)]+a[l]+root[t.find(y)];
            t.merge(l,x);
             t.merge(l,y);
            root[t.find(x)]=sum;
            if(sum>ans)
                ans=sum;

        }

      v.pb(ans);

    }


    for(i=n-1;i>=0;i--)
        cout<<v[i]<<endl;









    /*//pad=new UF(5);
    pad.merge(1,2);
    pad.merge(3,4);
    //pad.merge(3,2);
    for(i=1;i<=5;i++)
        pad.find(i);
    for(i=1;i<=5;i++)
        cout<<pad.find(i)<<endl;*/


}
