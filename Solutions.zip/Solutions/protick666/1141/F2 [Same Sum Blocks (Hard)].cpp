#include <bits/stdc++.h>
#include <iostream>
#include <map>
//#include "helper.h"
#include <math.h>
using namespace std;
#define ll long long int
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define PI 3.14159265
map<ll,vector<pair<ll,ll> > > myMap;
map<ll,ll> vis;
vector<ll> nums;
ll a[10000];

int main() {
    ll n,m,health;
    cin>>n;
    for(int i = 1; i <= n; i++) {
        cin>>a[i];
    }

    for(int i = 1; i <= n; i++) {
        ll sum = 0;
        for(int j = i; j>=1; j--) {
            sum += a[j];
            if(vis[sum] == 0) {
                vis[sum]++;
                nums.push_back(sum);
            }
            myMap[sum].push_back(make_pair(j, i));
        }
    }

    ll len = 0; ll candidate = 0;

    for(int i = 0; i < nums.size(); i++) {
        ll sum = nums[i];
        ll p = -1000000000000;
        ll temp = 0;
        for(int j = 0; j < myMap[sum].size(); j++) {
            if(myMap[sum][j].first > p) {
                temp++;
                p = myMap[sum][j].second;
            }
        }
        if(temp > len) {
            len = temp;
            candidate = sum;
        }
    }

    cout<<len<<endl;
    ll sum = candidate;
    ll p = -1000000000000;
    ll temp = 0;
    for(int j = 0; j < myMap[sum].size(); j++) {
        if(myMap[sum][j].first > p) {
            cout<<myMap[sum][j].first<<" "<<myMap[sum][j].second<<endl;
            p = myMap[sum][j].second;
        }
    }

}
