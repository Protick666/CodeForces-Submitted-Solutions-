#include <bits/stdc++.h>
#include <iostream>
#include <map>
//#include "helper.h"
#include <math.h>
using namespace std;
#define ll long long int
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define PI 3.14159265

int main() {
    ll n,m,health;
    cin>>health>>n;
    ll val[n + 2];
    val[0] = 0;

    for(int i=1; i<=n; i++) {
        cin>>val[i];
    }

    for(int i=1; i<=n; i++) {
        val[i] = val[i-1] + val[i];
    }

    if(val[n] >= 0) {
        int i;
        for(i = 1; i<=n; i++) {
            if(val[i] + health <= 0) {
                cout<<i<<endl;
                break;
            }
        }
        //cout<<i<<endl;
        if(i == n+1)
            cout<<-1<<endl;
    }
    else {
        //cout<<"2nd logic"<<endl;
        ll ans = -1;
        for(int i = 1; i<=n; i++) {
            if(val[i] >= 0)
                continue;
            ll leftHealth = health + val[i];
            ll neededPreRounds = 0;
            if(leftHealth > 0) {
                neededPreRounds = leftHealth / (-val[n]);
                if((leftHealth % (-val[n])) != 0)
                    neededPreRounds++;
            }

            if(ans == -1)
                ans = neededPreRounds * n + i;
            else
                ans = MIN(ans, neededPreRounds * n + i);
        }
        cout<<ans<<endl;
    }
}