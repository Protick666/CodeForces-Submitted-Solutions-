#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000
ll a[1000002];



int main()
{
    ll n,i,j,k,l,sum,ans,temp,h,m,p,q;
ans=0;
    cin>>n>>h>>m;
    for(i=1;i<=n;i++)
        scanf("%I64d",&a[i]);

    ans=0;
    q=0;
    for(i=1;i<=n;i++)
    {
        p=(a[i]+q)/m;
        q=(a[i]+q)%m;
        ans+=p;
        if(a[i+1]+q>h)
        {
            ans++;
            q=0;
        }



    }
    if(q!=0)
        ans++;
    cout<<ans;

}
