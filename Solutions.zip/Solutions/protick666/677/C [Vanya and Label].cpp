#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

map <char, ll > m;
ll dp[1000];

ll check(ll a)
{
    ll i,j,p,sum,l;
    sum=0;
    l=a;

    p=1;
    for(i=1;i<=6;i++)
    {
        j=p&a;
        if(j==0)
            sum++;
        a=a>>1;

    }

    return sum;
}


int main()
{
    ll n,i,j,k,l,sum,ans,temp,h,p,q;
    char c;
    c='0';
    p=1;
    for(i=0;i<=10;i++)
    {
        dp[i]=p;
        p*=3;
    }
    for(i=0;i<=9;i++)
    {


        m[c]=check(i);

        c++;

    }
    c='A';
     for(i=10;i<=35;i++)
    {
        m[c]=check(i);
        c++;

    }

     c='a';
     for(i=36;i<=61;i++)
    {
        m[c]=check(i);
        c++;

    }
    c='-';
    m[c]=check(62);
     c='_';
    m[c]=check(63);

    ans=1;

    char ch[1000000];

    scanf("%s",ch);
    string s;
    s=ch;
    l=s.length();

    for(i=0;i<l;i++)
    {
        p=m[s[i]];
        q=dp[p];
        ans=(ans*q)%1000000007;
    }

cout<<ans;

}
