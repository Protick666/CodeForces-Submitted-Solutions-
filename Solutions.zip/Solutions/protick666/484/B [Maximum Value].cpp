#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;



long long int vis[1000001];
long long int dp[1000001];
long long int done[100001];
long long int a[1000001];
main()
{

long long int i,j,k,n,t,sum,store,big,ans,p,q,r;
ans=0;
big=-1;
cin>>n;
for(i=1;i<=n;i++)
{
    scanf("%I64d",&store);
    a[i]=store;
    if(store>big)
        big=store;

    vis[store]=1;
}
dp[0]=0;

for(i=1;i<=big;i++)
{
    if(vis[i]==1)
        dp[i]=i;
    else
        dp[i]=dp[i-1];
}

for(i=1;i<=n;i++)
{
    p=a[i];
    if(done[p]==1)
        continue;
    done[p]=1;
    for(j=2;;j++)
    {
        q=j*p;
        if(q>big)
        {
            r=big;
            sum=big%p;
            if(sum>ans)
                ans=sum;
            break;

        }
        else
        {
            r=dp[q-1];
            sum=r%p;
            if(sum>ans)
                ans=sum;



        }

    }



}


cout<<ans;



}

