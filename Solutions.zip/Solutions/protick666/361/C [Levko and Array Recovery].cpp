#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define modd 1000000007
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

ll vis[10000];
ll f[10000];
ll x[10000];
ll y[10000];
ll val[10000];

ll dp[10000];
vector <ll> v[10000];
ll num[10000];
void fail()
{
    cout<<"NO";
    ex;
}

int main()
{

    ll i,j,k,sum,ans,n,m,d,a,b,r,q,t,p;
    cin>>n>>m;

    for(i=1;i<=n;i++)
        dp[i]=maxx;
    for(i=1;i<=m;i++)
    {
        cin>>f[i]>>x[i]>>y[i]>>val[i];
    }

    for(k=m;k>=1;k--)
    {
        t=f[k];
        if(t==1)
        {
            a=x[k];
            b=y[k];
            d=val[k];
            for(i=a;i<=b;i++)
            {
                dp[i]-=d;

            }

        }

        else
        {
            a=x[k];
            b=y[k];
            d=val[k];
            q=0;
            for(i=a;i<=b;i++)
            {
                r=dp[i];
                vis[i]=1;
                if(r<d)
                    cont;
                else if(r==d)
                {
                    num[k]++;
                    v[i].pb(k);
                    q++;
                }
                else
                {
                    for(j=0;j<v[i].size();j++)
                    {
                        p=v[i][j];
                        num[p]--;
                        if(num[p]==0)
                            fail();

                    }
                    v[i].clear();
                    num[k]++;
                    q++;
                    v[i].pb(k);
                    dp[i]=d;


                }


            }
            if(q==0)
                fail();

        }
    }

    for(i=1;i<=n;i++)
    {
        if(vis[i]==0)
            dp[i]=-1000000000;
    }
    for(i=1;i<=n;i++)
    {
        a=abs(dp[i]);
        if(a>1000000000)
            fail();
    }
    cout<<"YES"<<endl;

    for(i=1;i<=n;i++)
        cout<<dp[i]<<" ";


}
