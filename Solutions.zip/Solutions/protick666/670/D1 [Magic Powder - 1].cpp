#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

ll need[10000];
ll has[10000];
ll sol[10000];
ll ex[10000];

int main() {
ll i,j,k,l,m,n,sum,ans,val,mini,maxi,store,a,taka,x,y;
sum=0;

cin>>n>>k;
val=0;

for(i=1;i<=n;i++)
    {scanf("%I64d",&need[i]);
          val+=need[i];

    }
for(i=1;i<=n;i++)
{
    scanf("%I64d",&has[i]);


}

for(i=1;i<=n;i++)
{
    sol[i]=has[i]/need[i];
    ex[i]=has[i]%need[i];
}
maxi=-1;
mini=100000000;

for(i=1;i<=n;i++)
    {
        a=sol[i];
        if(a>maxi)
            maxi=a;
        if(a<mini)
            mini=a;

    }
sum+=mini;
for(i=1;i<=n;i++)
{
    sol[i]-=mini;
}
maxi=-1;
mini=100000000;

while(1)
{
    for(i=1;i<=n;i++)
    {
        a=sol[i];
        if(a>maxi)
            maxi=a;
        if(a<mini)
            mini=a;

    }
    if(mini==maxi)
    {
        sum+=(k/val);
        cout<<sum;
        exit(0);
    }
    x=mini++;
    taka=0;
    for(i=1;i<=n;i++)
    {
        if(sol[i]>=mini)
            {
                sol[i]=sol[i]-mini;
                continue;}
        y=(need[i]-ex[i])+(mini-1)*need[i];
        if(y>k)
        {
            cout<<sum;
            exit(0);
        }
        k=k-y;
        ex[i]=0;


    }
    sum+=mini;

}
cout<<sum;

}
