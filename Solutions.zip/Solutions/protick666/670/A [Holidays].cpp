#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int




int main() {
ll i,j,n,a,b;
cin>>n;

if(n<=2)
    {
        i=0;
        j=n;
    }

else
{
    a=(n-2)/7;
    a=a*2+2;
    b=(n-2)%7;
    if(b==6)
        a++;

    j=a;

    a=(n/7);
    b=n%7;
    a=a*2;
    if(b==6)
        a++;
    i=a;


}

cout<<i<<" "<<j;





}
