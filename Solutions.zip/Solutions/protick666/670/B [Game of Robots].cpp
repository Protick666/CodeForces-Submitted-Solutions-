#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


ll a[1000000];

int main() {
ll i,j,n,sum,store,k,x,y,z;
cin>>n>>k;
for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);

for(x=1;;x++)
{
    y=x*(x+1)/2;
    if(y>k)
        break;
}

x--;
y=x*(x+1)/2;
z=k-y;
if(z==0)
    cout<<a[x];
else
    cout<<a[z];







}
