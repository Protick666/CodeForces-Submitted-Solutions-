#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

ll need[1000000];
ll has[1000000];
ll sol[1000000];
ll ex[1000000];
vector < pair<ll,ll> > v;
pair <ll,ll> p;

int main() {
ll i,j,k,l,m,n,sum,ans,val,mini,maxi,store,a,taka,x,y,s;
sum=0;
store=0;

cin>>n>>k;
val=0;

for(i=1;i<=n;i++)
    {scanf("%I64d",&need[i]);
          val+=need[i];

    }
for(i=1;i<=n;i++)
{
    scanf("%I64d",&has[i]);


}

for(i=1;i<=n;i++)
{
    sol[i]=has[i]/need[i];
    ex[i]=has[i]%need[i];
}
maxi=-1;
mini=100000000000;

for(i=1;i<=n;i++)
    {
        a=sol[i];
        if(a>maxi)
            maxi=a;
        if(a<mini)
            mini=a;

    }
sum+=mini;

//cout<<sum<<"firsy"<<endl;

for(i=1;i<=n;i++)
{
    sol[i]-=mini;
    p=make_pair(sol[i],i);
    v.push_back(p);
}
//cout<<sum<<" "<<k<<"taka"<<endl;
sort(v.begin(),v.end());
s=1;

    for(i=0;i<n;i++)
    {
        x=v[i].first;
        y=v[i].second;
        //cout<<x<<" "<<ex[y]<<" "<<need[y]<<"here"<<endl;
        if(x>=s)
        {
            taka=(x+1-s)*store;
            //cout<<taka<<endl;
            if(taka<=k)
            {
                s=x+1;
                k-=taka;
            }
            else
            {
                y=k/store;
                s=s+y;
                cout<<s+sum;
                exit(0);

            }

        }
        taka=need[y]-ex[y];
        if(taka>k)
        {


            break;

        }
        k=k-taka;
        store=store+need[y];

        //cout<<k<<" "<<taka<<" "<<store<<" "<<s<<endl;


    }

    if(i==n)
        {
            y=k/val;
            s=s+y;
            cout<<sum+s;


        }
    else
        cout<<s-1+sum;






}
