#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

map <ll,ll> v;
map <ll,ll> a;



ll lang[1000000];
ll sub[1000000];

int main() {
ll i,j,n,m,sum,store,k,x,y,z,ans;
cin>>n;
sum=-1;
z=-1;
for(i=1;i<=n;i++)
{
    scanf("%I64d",&x);
    v[x]++;
    a[x]++;

}
cin>>m;

for(i=1;i<=m;i++)
{
    scanf("%I64d",&lang[i]);
}

for(i=1;i<=m;i++)
{
    scanf("%I64d",&sub[i]);
}

for(i=1;i<=m;i++)
{
    x=lang[i];
    y=sub[i];
    if(v[x]>sum)
    {
        sum=v[x];
        z=a[y];
        ans=i;
    }

    if(v[x]==sum)
    {
        if(a[y]>z)
        {
            z=a[y];
            ans=i;
        }

    }

}

cout<<ans;


}
