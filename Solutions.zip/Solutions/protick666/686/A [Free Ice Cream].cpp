#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000
//#define LSOne(S) (S & (-S))



ll a[100000][10];

ll dp[100000][10];

int main()
{

    ll n,i,j,k,sum,ans,store,x,y,m,p,r,g,b,t,q;
    cin>>n>>x;
    char c;

t=0;
    for(i=1;i<=n;i++)
    {
        cin>>c>>p;

        if(c=='+')
        {
            x+=p;
        }
        else
        {
            if(p<=x)
            {
                x-=p;
            }
            else
                t++;

        }

    }

cout<<x<<" "<<t;

}
