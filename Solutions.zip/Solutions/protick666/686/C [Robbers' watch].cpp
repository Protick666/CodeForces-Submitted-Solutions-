#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000
//#define LSOne(S) (S & (-S))

ll x,y,m,n,ans;

ll pos1[10];
ll pos2[10];


ll vis1[10];
ll vis2[10];

ll vis[10];

ll val1[10];
ll val2[10];
ll fin[1000];

void calc()
{
ll sum1,sum2,q,i;





    sum1=0;
    sum2=0;


    for(i=1;i<=x;i++)
    {
        sum1+=fin[i]*val1[i];
    }


     for(i=1;i<=y;i++)
    {
        sum2+=fin[x+i]*val1[i];
    }

    //cout<<"eije  "<<sum1<<" "<<sum2<<endl;



    for(i=1;i<=x+y;i++)
    {
        q=fin[i];

        if(vis[q]==1)
            return;
        vis[q]=1;

    }



    if(sum1>n-1 || sum2>m-1)
        return;
    //cout<<"lool "<<sum1<<endl;

    ans++;
    //for(i=1;i<=x+y;i++)
        //cout<<fin[i]<<" ";

         //cout<<endl;



}


void gen(ll a)
{
    ll i,j;
    if(a==x+y+1)
    {
        for(i=0;i<=6;i++)
            vis[i]=0;
        calc();
        return;
    }

    for(i=0;i<=6;i++)
    {
        fin[a]=i;
        gen(a+1);
    }



}


int main()
{

    ll i,j,k,sum,store,p,r,g,b,t,q;
    cin>>n>>m;
    p=1;
    x=1;
    y=1;
    ans=0;

    for(i=1;i<=10;i++)
    {
        val1[i]=p;
         val2[i]=p;
         p=p*7;
    }

    for(i=2;;i++)
    {
        if(val1[i]<=n-1)
            x++;
        else
            break;

         if(x>7)
            break;
    }


    for(i=2;;i++)
    {
        if(val2[i]<=m-1)
            y++;

         else
            break;

        if(y>7)
            break;
    }
     //cout<<x<<" "<<y<<endl;
      if(x>7)
    {
        cout<<"0";
        exit(0);
    }
    if(y>7)
    {
        cout<<"0";
        exit(0);
    }

    if(x+y>7)

     {
        cout<<"0";
        exit(0);
    }

    //cout<<x<<" "<<y<<endl;
    //cout<<val1[7]<<endl;


    gen(1);


cout<<ans;


}
