#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000
//#define LSOne(S) (S & (-S))



ll a[1000];

int main()
{

    ll n,i,j,k,sum,ans,store,x,y,m,p,r,g,b,t,q;
    cin>>n;

    for(i=1;i<=n;i++)
        cin>>a[i];

    p=1;


    for(i=1;i<=n;i++)
    {
        sum=maxx;
        for(j=p;j<=n;j++)
        {
            if(a[j]<sum)
                {sum=a[j];
                x=j;
                }

        }

        //cout<<x<<endl;
        //if(i==3)
            //cout<<a[5]<<"koo"<<endl;



        sum=a[x];

        for(j=x;j>=p+1;j--)
            a[j]=a[j-1];
        a[p]=sum;

        for(j=x-1;j>=p;j--)
            cout<<j<<" "<<j+1<<endl;

        p++;

    }

}
