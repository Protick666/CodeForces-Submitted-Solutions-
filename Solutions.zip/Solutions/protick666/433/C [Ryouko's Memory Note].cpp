#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll cost[100003];
 vector<ll> v[100003];
ll vis[100003];
ll a[100003];
ll done[100003];

int main() {
    // your code goes here
   ll i,j,k,l,sum,n,m,x,y,r,ans,c,p;

   c=0;
   cin>>n>>m;
   ans=0;
   for(i=1;i<=m;i++)
   {
       scanf("%I64d",&a[i]);
   }

   for(i=1;i<=m;i++)
   {
       r=a[i];




        if(a[i+1]!=r && i!=m)
            {


           vis[r]++;
           cost[r]+=abs(r-a[i+1]);
           c+=abs(r-a[i+1]);
           v[r].push_back(a[i+1]);

           }


           if(a[i-1]!=r && i!=1)
            {


           vis[r]++;
           cost[r]+=abs(r-a[i-1]);
           //c+=abs(r-a[i-1]);
           v[r].push_back(a[i-1]);}






   }
//cout<<c<<endl;
   for(i=1;i<=m;i++)
   {
       r=a[i];
       if(done[r]==1)
        continue;
   if(vis[r]==0)
   {
       done[r]=1;
       continue;
   }
    sort(v[r].begin(),v[r].end());
    j=vis[r]>>1;

    l=v[r][j];
    p=0;
    for(j=0;j<vis[r];j++)
    {
        p+=abs(l-v[r][j]);

    }

    p=abs(cost[r]-p);
    if(p>ans)
        {ans=p;
        //cout<<r<<" "<<l<<endl;

        }

    done[r]=1;







   }



  cout<<c-ans<<endl;


}
