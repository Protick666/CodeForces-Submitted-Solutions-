#include<stdio.h>
int g=0;
int b=0;
long long int c1=0;
long long int c2=0;
main()
{
long long int i,j,k,l,n,ir,jr;
scanf("%I64d",&n);
int c[n];
i=0;
j=n-1;
for(k=0;k<n;k++)
scanf("%d",&c[k]);
//printf("%I64d %I64d ",i,j);
while(1)
{



if(i>j)
    break;
if(i==j)
{ if(c1==0 && c2==0)
   {
       c1++;
       break;
   }

    else if(b==0 && g==0)
    {c1++;
    break;
    //printf("one");
    }
  else if(b==0)
  {  // printf("two");
      c1++;
      break;
  }
  else if(g==0)
  {  //printf("three");
      c2++;
      break;

  }

}

if(b==0)
   {
       b=1;
    jr=c[j];}
if(g==0)
    {ir=c[i];
    g=1;
    }


if(ir>jr)
{c2++;
b=0;
ir=ir-jr;
j--;
}
else if(jr>ir)
{c1++;
g=0;
jr=jr-ir;
i++;
}
else if(ir==jr)
{c2++;
c1++;
b=0;
g=0;
i++;
j--;
//printf("lol");
}

//printf("%I64d %I64d %I64d %I64d %I64d %I64d\n",ir,jr,i,j,c1,c2);

}



printf("%I64d %I64d",c1,c2);








}
