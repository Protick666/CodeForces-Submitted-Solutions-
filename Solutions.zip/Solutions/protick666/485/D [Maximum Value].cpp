#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int
ll dp[1000001];
ll done[1000001];
ll a[1000001];



int main() {

    ll i,j,k,l,n,q,x,f,m,store,sum,p,y,ans;

    ans=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        scanf("%I64d",&x);
        dp[x]=1;
        a[i]=x;
    }
    for(i=1;i<=1000000;i++)
    {
        if(dp[i]==1)
            dp[i]=i;
        else
            dp[i]=dp[i-1];
    }

    for(i=1;i<=n;i++)
    {
        x=a[i];
        if(x==1)
            continue;
        if(done[x]==1)
            continue;
        done[x]=1;

        for(j=2;;j++)
        {
            k=j*x;
            if(k>1000000)
            {
                sum=dp[1000000];
                if(sum!=x)
                {
                    sum=sum-x*(j-1);
                    if(sum>ans)
                       ans=sum;
                }
                break;

            }
            sum=dp[k-1];
             if(sum!=x)
                {
                    sum=sum-x*(j-1);
                    if(sum>ans)
                       ans=sum;
                }


        }


    }


cout<<ans<<endl;

}
