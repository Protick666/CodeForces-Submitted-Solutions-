#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

#define mod 1000000007

long long int c[26];
//vector <long long int > v[26];
long long int z[1000001];
long long int v[25][1000001];


main()
{

long long int ans,n,i,j,l,q,k,d,r,a,b,w,x,flag,m,sum,e;
string s;
char gg[1000002];

flag=0;
ans=1;
sum=0;
char ch;
cin>>w>>q;
//scanf("%s",gg);
//s=gg;
cin>>s;
n=s.length();


long long int L = 0, R = 0;
for (i = 1; i < n; i++) {
  if (i > R) {
    L = R = i;
    while (R < n && s[R-L] == s[R]) R++;
    z[i] = R-L; R--;
  } else {
    k = i-L;
    if (z[k] < R-i+1) z[i] = z[k];
    else {
      L = i;
      while (R < n && s[R-L] == s[R]) R++;
      z[i] = R-L; R--;
    }
  }
}
//cout<<l<<endl;
/*for(i=0;i<l;i++)
{
    ch=s[i];
    d=ch-'a';
    v[d][c[d]]=i+1;
    c[d]++;
}*/

/*for(i=0;i<26;i++)
{
    j=c[i];
    cout<<i<<": ";
    for(k=0;k<j;k++)
        cout<<v[i][k]<<" ";
    cout<<endl;


}*/

//cout<<" here baby"<<c[25]<<endl;
/*for(i=0;i<l;i++)
{
    ch=s[i];
    d=ch-'a';
    m=c[d];
    for(j=m-1;j>=0;j--)
    {
        r=v[d][j];
        r=r-i;
        //cout<<r<<" "<<d<<" "<<j<<endl;
        //cout<<c[d]<<endl;
        //cout<<"pooi";
        if(r<=0)
            break;
        if(i==0)
            f[r]=1;
        else
        {
            f[r]++;
            //cout<<"gui";

        }

    }


*/

//cout<<" here baby"<<c[25]<<endl;

//cout<<"pad";

/*for(i=1;i<=l;i++)
{

    cout<<f[i]<<" ";

}

cout<<endl;
cout<<l<<endl;*/



for(i=1;i<=q;i++)
{
    scanf("%I64d",&r);
    if(i==1)
    {
        a=r;
        sum=sum+r-1;
    }

    else
    {
        e=a+n-1;
        b=r;
        if(e<b)
        {
            sum=sum+b-e-1;
            a=r;
        }

        else
        {
            x=e-b;
            x=n-x;
            x=x-1;
            if(z[x]==n-x)
            {
                a=r;
            }
            else

            {
                flag=1;
                break;
            }


        }


    }
if(i==q)
    sum=sum+w-(r+n-1);


}

if(flag==1)
{
    cout<<"0";
    exit(0);

}
if(q==0)
sum=w;


for(i=1;i<=sum;i++)
{
    ans=(ans*26)% mod;
}


cout<<ans;

}
















