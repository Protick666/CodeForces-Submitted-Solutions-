#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;





main()
{
   int i,j,k,n,p,x,y,a,b;
  cin>>n>>k;
  i=1;
  j=n*n-(n-k+1)*n+1;
  p=0;
  for(a=j;a<=n*n;a=a+(n-k+1))
    p=p+a;

  cout<<p<<endl;

  for(x=1;x<=n;x++)
  {
      for(y=1;y<=n;y++)
      {if(y<k)
           printf("%d ",i++);
        else
            printf("%d ",j++);


      }
    printf("\n");
  }



}
