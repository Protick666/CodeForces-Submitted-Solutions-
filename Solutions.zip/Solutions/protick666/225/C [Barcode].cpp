#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define maxx 1000000000000
//#define LSOne(S) (S & (-S))

ll a[1001][1001];
ll vis1[1001][1001];
ll vis2[1001][1001];

ll vis[1001];
ll dp1[1001];
ll dp2[1001];
ll min1[1001];
ll min2[1001];

int main()
{

    ll n,i,j,k,sum,ans,store,x,y,m,p;

    char ch[10000];
    string s;

    cin>>n>>m>>x>>y;

    for(i=1;i<=n;i++)
    {
        scanf("%s",ch);

        for(j=1;j<=m;j++)
            a[i][j]=ch[j-1]=='.'?1:0;
    }

    for(j=1;j<=m;j++)
    {
        sum=0;
        for(i=1;i<=n;i++)
           sum+=a[i][j];

        vis[j]=sum;

    }


    for(j=1;j<=m;j++)
        dp1[j]=vis[j];


    for(i=1;i<=m;i++)
        dp2[i]=n-dp1[i];
   for(i=1;i<=m;i++)
        dp1[i]=dp1[i]+dp1[i-1];
    for(i=1;i<=m;i++)
        dp2[i]=dp2[i]+dp2[i-1];

    for(i=1;i<=m;i++)
    {
        sum=maxx;
        for(j=x;j<=y;j++)
        {
            if(j>i)
            {
                p=maxx;
            }
            else if(j==i)
                p=dp1[i];
            else
            {
                p=dp1[i]-dp1[i-j]+min2[i-j];
            }

            vis1[i][j]=p;
            if(p<sum)
                sum=p;

        }
        min1[i]=sum;







        sum=maxx;
        for(j=x;j<=y;j++)
        {
            if(j>i)
            {
                p=maxx;
            }
            else if(j==i)
                p=dp2[i];
            else
            {
                p=dp2[i]-dp2[i-j]+min1[i-j];
            }

            vis2[i][j]=p;
            if(p<sum)
                sum=p;

        }
        min2[i]=sum;


//cout<<min1[i]<<" "<<min2[i]<<endl;
    }

    //for(i=1;i<=m;i++)
        //cout<<dp1[i]<<" ";

    //cout<<endl;



cout<<min(min1[m],min2[m]);


}
