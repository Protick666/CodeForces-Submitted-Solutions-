#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007

string s[1000001];
vector<string> v[1000001];
ll a[1000001];
ll n;

stack<ll> my;
int main()
{
    /*string s="100";
    int x=0;
    stringstream c(s);
    c>>x;
    cout<<x;*/
    ll i,j,x,l,p;
    string c,k;
    char ch[1000002];
    scanf("%s",ch);
    c=ch;
    i=0;
    j=0;
    n=0;
    c.append(",");
    //cout<<c<<endl;

    while(i<c.length())
    {
        while(c[j]!=',')
            j++;
        k=c.substr(i,j-i);
        //cout<<k<<endl;
        s[n]=k;
        i=j+1;
        j=i;
        while(c[j]!=',')
            j++;
        string t=c.substr(i,j-i);
        stringstream g(t);
        g>>x;
        //cout<<x<<endl;
        a[n]=x;
        n++;
        i=j+1;
        j=i;
    }

    //cout<<n<<"o"<<endl;
    //fr(i,0,n-1)
      //cout<<s[i]<<" ";

    l=1;

    for(i=0;i<n;i++)
    {
        //cout<<i<<" ";
        if(my.size()!=0)
        {


        while(my.top()==0)
        {
            l--;
            my.pop();
            if(my.size()==0)
                break;
        }

        }
        //cout<<"poop1";

        if(my.size()!=0)
            my.top()--;
            //cout<<"poop2";

            v[l].pb(s[i]);
            //cout<<l<<" "<<s[i]<<endl;
            if(a[i]!=0)
            {
                            //cout<<"poop3";

                my.push(a[i]);
                l++;
            }
    }
    //cout<<"yo";

    l=-1;
    i=1;
    while(v[i].size()!=0)
        i++;
    cout<<i-1<<endl;
    for(j=1;j<i;j++)
    {
        for(p=0;p<v[j].size();p++)
            cout<<v[j][p]<<" ";
        cout<<endl;
    }



}
