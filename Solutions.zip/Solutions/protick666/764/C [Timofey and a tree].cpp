#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)

vector<ll> v[1000002];
ll val[1000001];
ll x[1000002];
ll y[1000002];
ll n,f;
ll vis[1000002];
int ck(ll a);
void check(ll a)
{
    vis[a]=1;
    ll i,sum,p,t;
    for(i=0;i<v[a].size();i++)
    {
        t=v[a][i];
        //cout<<t<<endl;
        p=ck(t);
        //cout<<p<<endl;
        if(p==0)
            return;

    }
    cout<<"YES"<<endl;
    cout<<a;
    ex;

}
int ck(ll a)
{
    vis[a]=1;
    ll i,sum,p,t;
    for(i=0;i<v[a].size();i++)
    {
        t=v[a][i];
        //cout<<t<<endl;
        if(vis[t]==0)
        {
            if(val[t]!=val[a])
                {
                    //cout<<"lool"<<a<<endl;;
                    return  0;
                }
            else
               {
                   p=(ck(t));
                   if(p==0)
                     return 0;
               }
        }


    }
    return 1;

}


main()
{
    ll i,j,k,p,t,z,a,b;
    cin>>n;
    for(i=1;i<n;i++)
    {
        cin>>a>>b;
        x[i]=a;
        y[i]=b;
        v[a].pb(b);
        v[b].pb(a);
    }
    for(i=1;i<=n;i++)
        cin>>val[i];

    for(i=1;i<n;i++)
    {
        a=x[i];
        b=y[i];
        if(val[a]!=val[b])
        {
            check(a);
            for(i=1;i<=1000001;i++)
                vis[i]=0;
            check(b);
             cout<<"NO";
             ex;
        }
    }

    cout<<"YES"<<endl;
    cout<<"1";


}
