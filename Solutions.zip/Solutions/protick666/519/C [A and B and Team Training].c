#include<stdio.h>
int main()
{

long long int a,b,max;
scanf("%I64d%I64d",&a,&b);
if(a>=2*b)
max=b;
else if(b>=2*a)
max=a;
else
max=(a+b)/3;
printf("%I64d",max);
















}
