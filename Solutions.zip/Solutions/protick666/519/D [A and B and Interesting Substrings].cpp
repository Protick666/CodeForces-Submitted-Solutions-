#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


map <long long int,long long int> m[26];
long long int val[26];




main()
{
long long int n,i,j,p,q,x,y,b,k,l,w,u,v,flag,z,d,sum;
sum=0;
for(i=0;i<26;i++)
{
    scanf("%I64d",&val[i]);
}
string s;
char c;
cin>>s;
l=s.length();
long long int f[l+1];
f[0]=0;

for(i=1;i<=l;i++)
{

    c=s[i-1];
    d=c-'a';
    z=f[i-1];
    if(m[d][z]!=0)
        sum=sum+m[d][z];
    f[i]=f[i-1]+val[d];
    m[d][f[i]]++;







}




cout<<sum;



}
