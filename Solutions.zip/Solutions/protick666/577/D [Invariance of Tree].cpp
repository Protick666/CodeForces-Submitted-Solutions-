#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 1000000007
#define ex  exit(0)

vector<ll> v;

ll a[1000000];
ll gu[2];

ll vis[1000000];
ll print[1000000];

void fail()
{
    cout<<"NO";
    ex;
}
void dfs(ll p)
{
    v.pb(p);
    vis[p]=1;
    if(vis[a[p]]==1)
        return;
    else dfs(a[p]);

}
void process()
{
    ll i,j,sum,k;
    j=0;
    for(i=0;i<v.size();i++)
        {print[v[i]]=gu[j];
         j=(j+1)%2;

        }

}
main()
{

    ll i,j,k,l,n,h,x,y,r,p,ans,sum,m,q;
    cin>>n;
    p=-1;
    for(i=1;i<=n;i++)
       {

       cin>>a[i];
       if(a[i]==i)
        p=i;
       }

       if(p!=-1)
       {

           cout<<"YES"<<endl;

           for(i=1;i<=n;i++)
           {
               if(i!=p)
               {
                   cout<<i<<" "<<p<<endl;

               }

           }
           ex;

       }

       for(i=1;i<=n;i++)
       {
           x=i;
           y=a[i];
           if(a[y]==x)
           {
               gu[0]=x;
               gu[1]=y;
               vis[x]=1;
               vis[y]=1;
               break;

           }
       }

       if(i==n+1)
          fail();

    for(i=1;i<=n;i++)
    {
        if(vis[i]==1)
            continue;

        dfs(i);

        p=v.size();
        //cout<<p<<endl;

        if((p%2)==1)
            fail();
        process();
        v.clear();
    }

    cout<<"YES"<<endl;
    for(i=1;i<=n;i++)
    {
        if(i==x || i==y)
            continue;

      cout<<i<<" "<<print[i]<<endl;

    }

    cout<<x<<" "<<y<<endl;











}






