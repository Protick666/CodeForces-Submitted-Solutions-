#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define bal 10000000000000
   ll i,j,k,l,n,sum,ans,p,q,y,u,v,r;
   ll a[1000000];
   ll vis[1000000];
main()
{
    cin>>n;
    string s;
    char ch[1000000];
    scanf("%s",ch);
    s=ch;
    n=s.length();
    l=1;

    for(i=0;i<n;i++)
    {    p=digit(s[i]);
        if(i==0)
        {

            a[l]=p;
            vis[l]++;
            //continue;
        }
        else if(p==a[l])
        {
            vis[l]++;
            continue;

        }
        else
        {
            l++;
            a[l]=p;
            vis[l]++;
            continue;

        }

    }

   // for(i=1;i<=l;i++)
        //cout<<vis[i];

        ans=l;

        y=0;
        u=0;
        v=0;

        n=l;
        l=1;
        r=n;
        //ans=l;
        while(1)
        {
            if(l>n)
            {
                break;
            }


            if(vis[l]==1)
                {l++;
                continue;
                }

            if(vis[r]==1)
                {r--;
                continue;
                }

        if(l==r)
        {
            if(l==1 || l==n)
            {
                p=vis[l];
                if(p==2)
                {
                    ans++;

                }
                else
                {
                    ans+=2;
                }

            }

            else
            {
                if(vis[l]>2)
                     ans+=2;
            else
                ans++;
            }

            break;
            }

        else
        {ans+=2;
        break;

        }
        }
cout<<ans;
}
