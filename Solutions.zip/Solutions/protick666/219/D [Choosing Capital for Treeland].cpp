#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define con continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity


//map<ll,map<ll,ll> > m;
vector<ll> v[1000001];
vector<ll> m[1000001];

ll vis[1000003];
ll x,y,p;
ll ans[1000002];

void dfs(ll a)
{
    ll i,j,t,z;
    vis[a]=1;
    for(i=0;i<v[a].size();i++)
    {
        t=v[a][i];
        if(vis[t]==0)
        {
            p+=m[a][i];
            dfs(t);
        }

    }
}

ll dfs1(ll a,ll d)
{
    vis[a]=1;
    //cout<<a<<" "<<d<<endl;
    ll i,j,sum,t;
    sum=d+y;
    ans[a]=sum;
    for(i=0;i<v[a].size();i++)
    {
        t=v[a][i];
        if(vis[t]==0)
        {

            dfs1(t,d+m[a][i]);
        }

    }




}

//x pos,y neg,temp pos a, temp neg b
int main()
{
    ll n,i,j,k,l,a,b,sum;

    cin>>n;
    for(i=1;i<=n-1;i++)
    {
        cin>>x>>y;
        v[x].pb(y);
        v[y].pb(x);
        m[x].pb(1);
        m[y].pb(-1);
    }
    dfs(1);
    //cout<<"mama"<<endl;
    x=(p+n-1)/2;
    y=n-1-x;
    //cout<<x<<" "<<y<<endl;
    for(i=0;i<=n;i++)
        vis[i]=0;

    dfs1(1,0);
    //cout<<"mama"<<endl;
    sum=maxx;
    for(i=1;i<=n;i++)
        sum=min(sum,ans[i]);

    cout<<sum<<endl;

    for(i=1;i<=n;i++)
    {
        if(ans[i]==sum)
            cout<<i<<" ";
    }


}
