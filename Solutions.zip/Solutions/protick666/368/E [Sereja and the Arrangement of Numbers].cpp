#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 1000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<ll> v;
ll dp[1000009];

ll ck(ll n)
{
  if(n==1)
        return 1;
  else if(n==2)
    return 2;
  else{
        ll t=dp[n];
        if((n%2)==1)
            return t+1;
        else

        {
            //if(n==10)
                ////cout<<t<<" tt"<<endl;
                            return t+(n/2)-1+1;

        }

  }
}
int main()
{


    ll i,j,k,sum,n,r,m,l,v1,v2,a,t,x,y;
    cin>>n>>m;
    fr(i,1,m)
    {
        cin>>x>>y;
        v.pb(y);

    }
    sort(all(v));;

    t=1;
    for(i=2;i<=1000006;i++)
    {
        dp[i]=t+dp[i-1];
        t++;
    }

    for(i=1;;i++)
    {
        t=ck(i);
        //if(i==10)
                    //cout<<dp[10]<<endl;
        if(t>n)
            {

                break;}
    }
   t=i-1;
   ll p=min(t,m);
   //cout<<t<<" "<<m<<endl;
   sum=0;
   for(i=v.size()-1,j=1;j<=p;j++,i--)
     sum+=v[i];

   cout<<sum;





}
