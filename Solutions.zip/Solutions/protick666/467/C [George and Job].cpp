#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

long long int bal[100000];
long long int sal[100000];
long long int dp[10000];
long long int a[10000];





main()
{

long long int  l,g,i,j,k,n,f1,f2,sum,f,p,q,b,r,w;
sum=0;
cin>>n>>l>>g;
long long int  *s;
long long int  *t;
long long int  *temp;

s=bal;
t=sal;
for(i=1;i<=n;i++)

{
    scanf("%I64d",&a[i]);
    dp[i]=dp[i-1]+a[i];
}

for(j=1;j<=g;j++)
{
    for(i=1;i<=n;i++)
    {
        if(i<j*l)
            t[i]=0;
        else
        {
            p=s[i-l]+dp[i]-dp[i-l];
            q=t[i-1];
            r=p>q?p:q;
            t[i]=r;
        }



    }


    temp=s;
    s=t;
    t=temp;

}


cout<<s[n];

}
