
#include<stdio.h>
main()
{
    double a,min,p;
    long long int n,x,y;
    scanf("%I64d%I64d",&x,&y);
    if(y>x)
    {
        printf("-1");
        exit(0);

    }

    else if(x%y==0 && (x/y)%2==1)
    {
        printf("%I64d",y);
        exit(0);
    }

    else{

        n=(x-y)/y;
        n=n+10;
        if(n%2==0)
            n--;

     }

    while(1)
    {

        p=(x+y)/(float)(n+1);

        if(p<y)
            n=n-2;
        else
            break;



    }

    printf("%.10lf",p);

















}