#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;
double a[1000000];
double b[1000000];
ll i,j,n;
double k,p,t,m,r,u,z,x,y,l,g,w,q;
double check()
{
    ll i;
    double sum,ans;
    ans=-10;
    sum=0;
    for(i=1;i<=n;i++)
    {
        sum+=a[i];
        if(sum<0)
            sum=0;
        if(sum>ans)
            ans=sum;

    }
    return ans;
}



double check1()
{
    ll i;
    double sum,ans;
    ans=-10;
    sum=0;
    for(i=1;i<=n;i++)
    {
        sum+=b[i];
        if(sum<0)
            sum=0;
        if(sum>ans)
            ans=sum;

    }
    return ans;
}
main()
{
    cin>>n;
//cout<"paa";
    for(i=1;i<=n;i++)
        cin>>a[i];
//cout<<"paa";

 //x is pos max
 //y is min
 //cout<"paa";
 x=check();
//cout<<"paa";

 for(i=1;i<=n;i++)
    a[i]*=-1;
 y=check();
 if(x==y)
 {
     cout<<x;
     exit(0);
 }
 if(x<y)
 {
     swap(x,y);

 }
 else
 {
     for(i=1;i<=n;i++)
    a[i]*=-1;

 }
 l=0;
 r=10001;
//cout<<"paa";
//cout<<x<<" "<<y<<endl;
 for(j=1;j<=100;j++)
 {
     m=(l+r)/2;
     //cout<<l<<" "<<m<<" "<<r<<endl;
     for(i=1;i<=n;i++)
     {
         b[i]=a[i]-m;
         
     }
     p=check1();
     for(i=1;i<=n;i++)
     {
         b[i]=b[i]*-1;
        
     }
      q=check1();
     //cout<<p<<" "<<q<<endl;

    if(p<q)
     r=m;
    else
        l=m;



 }


  std::cout << std::fixed;
    std::cout << std::setprecision(10);
    std::cout << p;



}
