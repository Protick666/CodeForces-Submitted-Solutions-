#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000007];
ll n,s;

ll ck(ll t)
{
    if(t==0)
        return 0;
    ll x,y,i,j,sum;
    sum=0;
    //cout<<t<<endl;
    if(t>n)
        return maxx;
    std::multiset<ll> my;
    std::multiset<ll>::iterator it;
    for(i=1; i<=n; i++)
    {
        y=a[i]+t*i;
        //cout<<i<<endl;
        if(my.size()<t)
        {
            //cout<<"c1"<<endl;
            my.insert(y);
            sum+=y;
        }
        else
        {

            it = my.end();
             --it;
            if(y<(*it))
            {
                //cout<<"c2"<<endl;

                sum-=(*it);
                my.erase (it);
                my.insert(y);
                sum+=y;

            }


        }
        //cout<<"sum "<<sum<<endl;
    }
      my.clear();

    //cout<<endl<<endl;

    return sum;

}

main()
{
    ll x,y,i,j,k,sum,ans,l,r,mid;
    cin>>n>>s;
    fr(i,1,n)
    cin>>a[i];

    l=0;
    r=n;

    while(1)
    {

        mid=(l+r)/2;
        //cout<<mid<<endl;
        x=ck(mid);
        y=ck(mid+1);

        if(x<=s)
        {
            if(y<=s)
            {
                l=mid+1;
                cont;
            }
            else
            {
                cout<<mid<<" "<<x;
                ex;
            }
        }
        else
            r=mid-1;

    }


}
