#include<stdio.h>
main()
{
int s,n,i,j,l,k;
scanf("%d",&n);
int a[n][3];
for(i=0;i<n;i++)
{scanf("%d",&a[i][0]);
a[i][1]=0;
}
for(i=0;i<n;i++)
{s=1;
if(a[i][1]==0)
{
  for(j=0;j<n;j++)
  {
    if(a[j][0]>a[i][0])
       s++;


  }
a[i][2]=s;
a[i][1]=1;

for(j=i+1;j<n;j++)
  {
    if(a[j][0]==a[i][0])
      {a[j][2]=s;
      a[j][1]=1;

      }


  }



}



}


for(j=0;j<n;j++)
    printf("%d ",a[j][2]);










}