#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll a[101][2];
ll b[101][2];

ll (*x)[2];


int main() {
    // your code goes here
   ll i,j,k,l,sum,n,m,y,r,ans,p;
   cin>>n>>m;
   j=1;
   x=a;
   for(i=1;i<=m;i++)
   {
       x[j][0]=i;
       if(i%2==0)
         j++;
       if(x==a)
        x=b;
       else
        x=a;
       if(i==2*n)
        break;
    }
    x=a;
    j=1;
    for(i=2*n+1;i<=m;i++)
    {
        x[j][1]=i;
        if(i%2==0)
         j++;

       if(x==a)
        x=b;
       else
        x=a;




    }








    j=1;
    p=1;
   x=a;
   for(i=1;i<=4*n;i++)
   {
       if(x[j][p]!=0)
         cout<<x[j][p]<<" ";
       p=(p+1)%2;
       if(i%4==0)
         j++;

       if(i%2==0)
       {


       if(x==a)
        x=b;
       else
        x=a;}

    }



}
