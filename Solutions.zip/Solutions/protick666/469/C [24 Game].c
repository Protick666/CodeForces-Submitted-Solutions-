#include<stdio.h>

void print4()
{
  printf("4 * 3 = 12\n");
  printf("12 * 2 = 24\n");
  printf("24 * 1 = 24\n");


}


void print5()
{
  printf("5 - 2 = 3\n");
  printf("3 - 1 = 2\n");
  //printf("24*1=24\n");
  printf("4 * 3 = 12\n");
  printf("12 * 2 = 24\n");


}




main()
{

long long int n,i,j;
scanf("%I64d",&n);
if(n<4)
printf("NO");


else if(((n-4)%2)==0)
{printf("YES\n");
for(i=n;i>4;i=i-2)
   printf("%I64d - %I64d = 1\n",i,i-1);

for(i=1;i<=(n-4)/2;i++)
{
printf("1 * 1 = 1\n");

}
print4();

}


else
{printf("YES\n");
for(i=n;i>5;i=i-2)
   printf("%I64d - %I64d = 1\n",i,i-1);

for(i=1;i<=(n-5)/2;i++)
{
printf("1 * 1 = 1\n");

}
print5();

}












}