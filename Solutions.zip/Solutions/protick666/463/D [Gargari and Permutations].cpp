#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int


ll a[1001][1001];
ll pos[7][1001];
ll arr[7][1001];
ll dp[1001];


int main() {
    // your code goes here
   ll i,j,l,sum,n,k,ans,p,q,bal,store;
   ans=0;
   ll *x;
   x=arr[1];
   cin>>n>>k;

   for(i=1;i<=k;i++)
   {
       for(j=1;j<=n;j++)
       {
           scanf("%I64d",&p);
           pos[i][p]=j;
           arr[i][j]=p;

       }
    }

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(a[j][i]==1)
                continue;
            if(i==j)
                continue;
            bal=1;
            for(l=1;l<=k;l++)
            {
                if(pos[l][j]<pos[l][i])
                    {
                        bal=2;
                        break;
                    }

            }
         if(bal==1)
            a[i][j]=1;

        }

    }

    for(i=1;i<=n;i++)
    {    sum=0;

        if(i==1)
            {dp[x[1]]=1;
             //cout<<x[1]<<endl;
            continue;
            }
        q=x[i];
        for(j=1;j<i;j++)
        {
            p=x[j];
            if(a[p][q]==1)
            {
                store=1+dp[p];
                if(store>sum)
                    sum=store;
            }

        }
        if(sum==0)
            sum=1;
        dp[q]=sum;

        if(sum>ans)
            ans=sum;

    }




if(ans==0)
    ans=1;

cout<<ans;


//cin>>p;
}
