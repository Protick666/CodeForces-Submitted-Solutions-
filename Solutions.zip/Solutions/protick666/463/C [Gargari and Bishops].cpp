#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>





using namespace std;


long long int a[2001][2001];

long long int l[2001][2001];
long long int r[2001][2001];


main()
{
    long long int p,n,x,i,j,pre,prepo,store,sum,power,k,s1,s2,v,od,ev,io,jo,ie,je;
    od=-1;
    ev=-1;

    scanf("%I64d",&n);

    for(i=1;i<=n;i++)
        {for(j=1;j<=n;j++)
            {
                scanf("%I64d",&a[i][j]);

            if(i-1<=0 || j-1<=0)
                    l[i][j]=a[i][j];
                else
                    l[i][j]=a[i][j]+l[i-1][j-1];

                if(i-1<=0 || j+1>n)
                    r[i][j]=a[i][j];
                else
                    r[i][j]=a[i][j]+r[i-1][j+1];}
        }






     for(i=1;i<=n;i++)
        {for(j=1;j<=n;j++)
            {   s1=l[i+n-max(i,j)][j+n-max(i,j)];
                v=j-1;
                s2=r[i+min(n-i,v)][j-min(n-i,v)];
                if((i+j)%2==0)
                {
                    if(s1+s2-a[i][j]>ev)
                    {
                        ev=s1+s2-a[i][j];
                        ie=i;
                        je=j;
                    }


                }
                 else
                {
                    if(s1+s2-a[i][j]>od)
                    {
                        od=s1+s2-a[i][j];
                        io=i;
                        jo=j;
                    }


                }

            }


        }



        printf("%I64d\n",od+ev);
        printf("%I64d %I64d %I64d %I64d",io,jo,ie,je);




    /*cout<<endl<<endl;

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            cout<<fin[i][j]<<" ";
        cout<<endl;
    }*/









}