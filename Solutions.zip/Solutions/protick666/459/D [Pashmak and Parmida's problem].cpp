#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
#define LSOne(S) (S & (-S))

ll a[1000002];
ll ft[1000002];
ll dp[1000001];
map <ll,ll> vis1;
map <ll,ll> vis2;


int n;

// Point query: Returns the value at position b in the array
ll query(int b)	{
	ll sum = 0;
	for (; b; b -= LSOne(b)) sum += ft[b];
	return sum;
}

// Point update: Adds v to the value at position k in the array
void update(int k, int v) {
	for (; k <= n; k += LSOne(k)) ft[k] += v;
}

// Range update: Adds v to each element in [i...j] in the array
void range_update(int i, int j, int v)	{
	update(i, v);
	update(j + 1, -v);
}





int main()
{
   ll i,j,k,l,ans,sum,p,e,x,y,q,z;
   cin>>n;

   for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);

    for(i=n;i>=1;i--)
    {
        p=a[i];

        vis2[p]++;

        range_update(vis2[p],1000000,1);
    }
ans=0;
    for(i=1;i<=n;i++)
    {
        p=a[i];

        vis1[p]++;
        range_update(vis2[p],1000000,-1);
        vis2[p]--;
        q=vis1[p];
        ans+=query(q-1);

    }

    cout<<ans;

}
