#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll vis[100000];
ll a[1000000];
ll b[1000000];
vector< ll > v[100000];

int main()
{
   ll n,i,j,k,l,sum,ans,z,y,w1,w2,d1,d2,e,d,r,f,p;
   f=1;
   l=0;
   r=0;
   p=0;
   ll *x;

   cin>>n;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d",&d);
       vis[d]++;
       v[d].push_back(i);
   }

   //cout<<v[1][0]<<" "<<v[1][1]<<endl;

   for(i=0;i<=10000;i++)
   {
       while(vis[i]!=0)
       {

           if((f%2)==1)
           {
               a[l]=v[i].back();
               //cout<<v[i].back()<<endl;
               l++;
               v[i].pop_back();
               f++;
           }
           else
           {
               b[r]=v[i].back();
               r++;
               //cout<<v[i].back()<<endl;
                v[i].pop_back();
               f++;
           }


           vis[i]--;




       }
   //if(i==1)
       //cout<<l<<" "<<r<<endl;

   }




cout<<l<<endl;

for(i=0;i<l;i++)
    printf("%I64d ",a[i]);
cout<<endl;
cout<<r<<endl;

for(i=0;i<r;i++)
    printf("%I64d ",b[i]);






}
