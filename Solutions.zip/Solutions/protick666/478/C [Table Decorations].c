#include<stdio.h>
main()
{
long long int store1,flag,store2,a,b,c,sum;
sum=0;
long long int num[3];
scanf("%I64d%I64d%I64d",&num[0],&num[1],&num[2]);
flag=1;
while(flag!=0)
{
    flag=0;
    for(a=0;a<2;a++)
    {
        if(num[a]>num[a+1]){
            store1=num[a];
          num[a]=num[a+1];
          num[a+1]=store1;
          flag++;}
    }






}

//sum+=num[0];
//num[1]=num[1]-num[0];
//num[2]=num[2]-num[0];

if(num[2]>=2*(num[1]+num[0]))
    sum=sum+num[1]+num[0];
else if((num[1]+num[0])!=0)
    sum=sum+(num[2]+num[1]+num[0])/3;

printf("%I64d",sum);

}








