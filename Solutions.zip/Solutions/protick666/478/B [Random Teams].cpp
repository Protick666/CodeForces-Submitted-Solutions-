#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;




main()
{

long long int ans,s,n,i,j,l,p,q,k,z,d,r,a,b,w,x,flag,m,sum,e;

cin>>n>>m;

p=n%m;
q=m-p;
s=n/m;
z=n-m+1;
a=q*(s*(s-1)/2)+p*(s*(s+1)/2);
b=(z*(z-1)/2);

cout<<a<<" "<<b;










}
















