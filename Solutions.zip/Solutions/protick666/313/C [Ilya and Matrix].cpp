#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007




ll a[2000000];
ll dp[2000000];
bool cmp(ll a,ll b)
{
    return b<a;
}



int main()
{
   ll i,j,k,l,n,ans,sum,p,e,x,y,q;

   cin>>n;
   p=2;
   q=2;

   while(1)
   {
       if(n==1)
       {
           p=1;
           q=1;
           break;

       }
       if(p*p==n)
        break;
       p=p*2;
       q++;
   }


   for(i=0;i<n;i++)
   {

        scanf("%I64d",&a[i]);
   }

   sort(a,a+n,cmp);
   for(i=0;i<n;i++)
    dp[i+1]=a[i];

   for(i=1;i<=n;i++)
    dp[i]=dp[i-1]+dp[i];

   sum=0;
   p=1;


   while(p<=n)
   {
       sum+=dp[p];
       p=p*4;
   }
//cout<<dp[4]<<endl;
   cout<<sum;

}
