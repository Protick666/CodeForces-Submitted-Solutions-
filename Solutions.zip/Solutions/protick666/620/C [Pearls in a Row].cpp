#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

map<int,int> last;
vector<int> out;
int seg=0;

main()
{
    int n,i,j,k,s,sum;
    sum=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        scanf("%d",&s);
        if(i==1)
            last[s]=1;

        else if(last[s]>seg)
        {
            sum++;
            out.push_back(seg+1);
            out.push_back(i);
            seg=i;

        }
        else{

            last[s]=i;
        }





    }
    if(sum>0)
        printf("%d\n",sum);
    else
        printf("-1");

    for(i=1;i<2*sum;i++)
    {


        printf("%d ",out[i-1]);
        if(i%2==0)
            printf("\n");
    }
    if(sum>0)
    printf("%d",n);




}
