#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<math.h>



using namespace std;

main()
{

    long long int h,n,i,j,k,leaf,sum,pre,pro,flag1,flag2,dep;
    cin>>h>>n;
    leaf=n+pow(2,h)-1;
    //cout<<leaf<<endl;
    sum=0;
    dep=0;

    while(1)
    {


        pre=leaf/2;
        pro=pre/2;
        if(pro==0)
        {   //cout<<sum<<endl;
            if(leaf==pre*2){
                 sum++;
                 break;
            }
            else{
                sum=sum+pow(2,dep+1);
               break;

            }


        }
        if(leaf==pre*2)
            flag1=-1;
        else
            flag1=1;
        if(pre==pro*2)
            flag2=-1;
        else
            flag2=1;
        if(flag1!=flag2){
            sum++;
            dep++;
            leaf=pre;

        }
        else
        {
            sum=sum+pow(2,dep+1);
            dep++;
            leaf=pre;
        }



    }



cout<<sum;

}




