
 #include<stdio.h>
#include <stdlib.h>
int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}
main()
{
    long long int n,i,j,p,sum;
    p=2;
    sum=0;
    scanf("%I64d",&n);
    long long int ap[n];
    for(i=0;i<n;i++)
        scanf("%I64d",&ap[i]);
    qsort(ap,n,sizeof(long long int),cmpfunc);

  

    for(i=0;i<n-1;i++)
    {
       sum=sum+p*ap[i];
        p++;

    }
    sum=sum+(p-1)*ap[i];
    printf("%I64d",sum);
}