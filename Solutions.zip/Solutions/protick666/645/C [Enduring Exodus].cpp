#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int
ll f[1000000];
ll b[1000000];
ll a[1000000];
int main() {

ll i,j,k,l,n,x,y,ans,p,e,sum;
e=0;
cin>>n>>k;
k++;

string s;
char ch[100001];
char c;
scanf("%s",ch);
s=ch;
l=s.length();
for(i=0;i<l;i++)
{
    c=s[i];
    if(c=='0')
    {
        a[e+1]=i+1;
        f[i+1]=i+1;
        b[i+1]=i+1;
        e++;
    }

}
for(i=1;i<=l;i++)
{
    if(f[i]==0)
        f[i]=f[i-1];
}

for(i=l;i>=1;i--)
{
    if(b[i]==0)
        b[i]=b[i+1];
}
//cout<<e<<" ee"<<endl;
//for(i=1;i<=e;i++)
    //cout<<a[i]<<" ";
//cout<<endl;
ans=100000000;

for(i=1;;i++)
{
    j=i+k-1;
    if(j>e)
        break;


        p=(a[i]+a[j])/2;
        l=f[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
               }

        p=(a[i]+a[j])/2;
        l=b[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
               }



   p=(a[i]+a[j])/2;
    p++;
        l=f[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
              }

    p=(a[i]+a[j])/2;
    p++;
        l=b[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
              }
              
              
              
              
              p=(a[i]+a[j])/2;
    p--;
        l=f[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
              }

    p=(a[i]+a[j])/2;
    p--;
        l=b[p];
        x=abs(a[i]-l);
        y=abs(a[j]-l);
      sum=max(x,y);
      if(sum<ans)
              {
                   //cout<<i<<" "<<j<<endl;
                   ans=sum;
              }







}





cout<<ans;




}
