#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector <string > v[100];
int main()
{
    /*string s="stoi";
    char c[2];
    c[1]='\0';    //string y=c;
    c[0]=s[0];
    s.append(c);
    cout<<s;*/

    ll n,m,i,j,sum,ans,k;
    cin>>n;
    fr(i,1,n)
    {
        string s;
        cin>>s;
        fr(j,1,s.length())
        {
            v[i].pb(s);
            char c[2];
            c[1]='\0';    //string y=c;
            c[0]=s[0];
            s.erase(0,1);
            s.append(c);

        }
    }
    if(n==1)
    {
        cout<<0;
        ex;
    }
    ans=maxx;

    for(i=0; i<v[1].size(); i++)
    {
        sum=0;
        string s=v[1][i];
        sum+=i;
        for(j=2; j<=n; j++)
        {
            for(k=0; k<v[j].size(); k++)
            {
                string p=v[j][k];
                if(p==s)
                {
                    sum+=k;
                    break;
                }
            }
            if(k==v[j].size())
                break;

        }
        if(j!=n+1)
            continue;


        if(sum<ans)
            ans=sum;
    }

    if(ans==maxx)
        cout<<"-1";
    else
        cout<<ans;

}


