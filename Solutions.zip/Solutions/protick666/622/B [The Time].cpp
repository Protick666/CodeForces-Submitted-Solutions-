#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000




int main()
{
   ll n,i,j,k,l,sum,ans,p,f,t,h,m;
   string s;
   cin>>s;
   cin>>t;
   h=(s[0]-'0')*10 +(s[1]-'0');
    m=(s[3]-'0')*10 +(s[4]-'0');

    //cout<<h<<":"<<m;

    m=m+t;

    p=m/60;
    m=m%60;

    h=(h+p)%24;

    if(h<=9)
    {
        cout<<"0";
        cout<<h;
    }
    else
         {

        cout<<h;
    }

    cout<<":";

      if(m<=9)
    {
        cout<<"0";
        cout<<m;
    }
    else
         {

        cout<<m;
    }





}
