#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll a[2000000];


int main() {
ll i,j,n,sum,ans,store,p,k,f,l,w,x,y,b,q;
cin>>n;
if(n==1)
{
    cout<<"1 1";
    exit(0);
}
i=1;
j=n;
ans=1;
while(1)
{
    a[i]=ans;
    a[j]=ans;
    i++;j--;
    if(i>=j)
        break;
    ans+=2;

}

i=n+1;
j=n-2+i;
ans=2;
while(1)
{
    a[i]=ans;
    a[j]=ans;
    i++;j--;
    if(i>=j)
        break;
    ans+=2;

}

for(i=1;i<=2*n;i++)
{
    if(a[i]==0)
        a[i]=n;
}

for(i=1;i<=2*n;i++)
{
   printf("%I64d ",a[i]);
}



}
