#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>

using namespace std;

long long int a[100001][3];
main()
{    int i,n,j,k,b,x,y,store,maxy,mini;
     cin>>n;
     store=0;
     maxy=0;
     for(i=0;i<n;i++)
     {
         cin>>a[i][0];
         if(maxy<a[i][0])
         {
             maxy=a[i][0];
         }
         a[i][1]=maxy;
     }
     mini=a[n-1][0];
     for(i=n-1;i>0;i--)
     {
         if(mini>a[i][0])
            mini=a[i][0];
         if(mini>=a[i-1][1])
            store++;


     }
     cout<<store+1;







}
