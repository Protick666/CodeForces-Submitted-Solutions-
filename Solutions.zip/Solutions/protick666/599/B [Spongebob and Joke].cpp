#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
ll real[1000000];
ll vis[1000000];
ll pos[1000000];
//ll f[1000000];
ll b[1000000];
ll ans[1000000];
main()
{
     //cout<<"bal";

    ll u,v,n,i,j,k,l,sum,t,d,p,store,f,m;
    f=0;
    cin>>n>>m;

    for(i=1;i<=n;i++)
    {
        scanf("%I64d",&sum);

        vis[sum]++;
        real[sum]++;
        pos[sum]=i;
    }

    for(i=1;i<=m;i++)
    {
        scanf("%I64d",&sum);

        if(vis[sum]==0)
        {
            cout<<"Impossible";
            exit(0);
        }

        //vis[sum]--;
        if(real[sum]>1)
          f=1;

        ans[i]=pos[sum];



    }

    if(f==1)
        cout<<"Ambiguity";

    else
    {
        cout<<"Possible"<<endl;
        for(i=1;i<=m;i++)
            printf("%I64d ",ans[i]);
    }




}
