#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;

#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define MOD 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define ex exit(0)
#include <iostream>   // std::cout
#include <string>
vector<ll> v;

ll ck(ll n,ll p)
{

    stringstream ss;
    ss << n;
    string x = ss.str();

    stringstream sp;
    sp << p;
    string y = sp.str();

   // if(p==4)
        //cout<<x<<" "<<y<<endl;


    if(y.length()>x.length())
    {
        return 10000;
    }
    ll i,j;
    i=0;
    j=0;

    for(i=0; i<x.length(); i++)
    {
        if(x[i]!=y[j])
            cont;
        else
        {
            j++;
            if(j==y.length())
            {
                return x.length()-y.length();
            }
        }
    }

    return 10000;
}

int main()
{

    ll i,j,k,n,p,q,a,b;
    cin>>n;

    for(i=1; i*i<=n; i++)
    {
        v.pb(i*i);
    }

    ll sum=1000;

    for(i=0; i<v.size(); i++)
    {
        sum=min(sum,ck(n,v[i]));
    }
    if(sum==1000)
        sum=-1;

    cout<<sum;



}