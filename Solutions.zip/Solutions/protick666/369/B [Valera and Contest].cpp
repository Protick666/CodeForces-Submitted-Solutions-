#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
ll a[1000000];
int main()
{
    int i,j,k,l,m,r,n,ans,sum,x,y,z,p,f;

    cin>>n>>k>>l>>r>>sum>>f;
    sum=sum-f;
    x=f/k;

    y=f%k;

    for(i=1;i<=k;i++)
    {
        a[i]=x;
        if(i<=y)
            a[i]++;

    }
    p=n-k;
    if(p!=0)
    {x=sum/p;
    y=sum%p;}

    for(i=1;i<=p;i++)
    {
        a[i+k]=x;
        if(i<=y)
            a[i+k]++;
    }


    for(i=1;i<=n;i++)
        cout<<a[i]<<" ";


}
