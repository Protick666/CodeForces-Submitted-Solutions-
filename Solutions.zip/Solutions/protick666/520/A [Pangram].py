
c=int(input())
b=input()
for i in range(65,91):
	a=0
	for j in b:
		
		if(j==chr(i) or j==chr(i+32)):
			a=a+1
			break
	if(a==0):
		break
if(a==0):
	print("NO")
else:
   print("YES")
   