#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

#define m 1000000007


long long int a;
long long int ci;
long long int g;
long long int t;



main()
{
   long long int n,i,j,k,p,sum,f;
  cin>>n;
   char s[n+1];
   char c;
   p=0;

   scanf("%s",s);
   sum=1;
   f=0;


   for(i=0;i<n;i++)
   {
       c=s[i];

       if(c=='A')
         a++;
       if(c=='C')
         ci++;
        if(c=='G')
         g++;
        if(c=='T')
         t++;



   }

   if(a>f)
    f=a;
   if(ci>f)
    f=ci;
   if(g>f)
    f=g;
   if(t>f)
    f=t;

   if(a==f)
    p++;
   if(ci==f)
    p++;
   if(g==f)
    p++;
   if(t==f)
    p++;

   for(i=1;i<=n;i++)
   {
       sum=(sum*p)%m;


   }




cout<<sum;


}
