#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


ll a[100][100];
ll vis[100];
ll ans[100];


int main() {
ll i,j,n,m,store,sum,v,f;
f=0;
cin>>n;
for(i=1;i<=n;i++)
{
    for(j=1;j<=n;j++)
        cin>>a[i][j];
}

for(i=1;i<=n;i++)
{
    for(j=1;j<=n;j++)
        vis[j]=0;
    for(j=1;j<=n;j++)
        vis[a[i][j]]++;
    sum=-1;
    for(j=1;j<=n;j++)
    {
        if(vis[j]>sum)
        {
            sum=vis[j];
            v=j;
        }
    }
    if(sum>1)
        ans[i]=v;
    else if(sum==1)
    {
        if(f==0)
           {
              f++;
            ans[i]=n-1;
           }
        else
        {
            ans[i]=n;
        }

    }

}


for(i=1;i<=n;i++)
    cout<<ans[i]<<" ";


}
