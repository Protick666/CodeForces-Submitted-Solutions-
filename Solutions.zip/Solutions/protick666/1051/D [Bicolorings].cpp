#include <bits/stdc++.h>

#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265

ll dp[1002][4][2002];
ll conv[5][5];

int main()
{
    ll mx = 998244353;

    conv[1][2]=0;conv[1][3]=0;conv[1][4]=2;
    conv[2][1]=1;conv[2][3]=1;conv[2][4]=1;
    conv[3][1]=1;conv[3][2]=1;conv[3][4]=1;
    conv[4][1]=2;conv[4][2]=0;conv[4][3]=0;
    for(int i=1;i<=4;i++)
        conv[i][i]=0;

    ll n,k,m,p,q;

    cin>>n>>k;

    dp[1][1][2] = 1;
    dp[1][2][1] = 1;
    dp[1][3][1] = 1;
    dp[1][4][2] = 1;

    for(int i=2; i<=n ;i ++)
    {
        for(int pre =1; pre<=4; pre++)
        {
            for(int t=1; t<=k;t++)
            {
                if(dp[i-1][pre][t] == 0)
                    cont;
                 for(int curr =1 ; curr<=4; curr++)
                 {
                     p = pre;     q = curr;

                     dp[i][curr][t+conv[p][q]] = (dp[i][curr][t+conv[p][q]]  + dp[i-1][pre][t]) % mx;
                 }
            }
        }
    }

    ll ans = 0;

    for(int i=1;i<=4; i++)
        ans=  (ans + dp[n][i][k]) % mx;

    cout<<ans;


}
