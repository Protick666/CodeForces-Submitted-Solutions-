#include<stdio.h>
#include<string.h>
int found=0;
main()
{

long long int n,i,j,k,l;
scanf("%I64d",&n);
char a[n][33];
char st[33];
long long int prt[n][2];
long long int num[n];
for(i=0;i<n;i++)
    {num[i]=0;
     prt[n][0]=100;
     prt[n][1]=100;

    }
i=0;
for(k=0;k<n;k++)
{
    if(k==0)
    {
        scanf("%s",a[i]);
        prt[k][0]=-1;
        //printf("OK\n");
        i++;
        continue;


    }


    scanf("%s",st);
    for(j=0;j<i;j++)
    {
        if(strcmp(a[j],st)==0)
        {//printf("%s%d",st,num[j]);
         prt[k][0]=j;
         prt[k][1]=num[j]+1;
         num[j]++;
         found=1;
         break;
        }

    }
 if(found==0)
 {
     strcpy(a[i],st);
     prt[k][0]=-1;
     //printf("OK\n");
     i++;



 }

   found=0;

}

for(i=0;i<n;i++)
{
   if(prt[i][0]==-1)
        printf("OK\n");
   else
   {
       printf("%s%I64d\n",a[prt[i][0]],prt[i][1]);

   }




}







}
