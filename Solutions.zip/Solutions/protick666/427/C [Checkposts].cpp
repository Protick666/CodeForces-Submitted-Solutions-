#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007
//#define LSOne(S) (S & (-S))

ll val[1000000];

vector <ll> v1[1000000];
vector <ll> v2[1000000];
ll vis1[1000000];
ll vis2[1000000];
vector <ll> finish;
ll vis[1000000];
ll man[1000000];
ll num[1000000];
ll q;

vector<ll> v[1000000];

ll dfs1(ll a)
{
    ll i,j,p;
    for(i=0;i<vis1[a];i++)
    {
        p=v1[a][i];
        if(vis[p]==0)
        {
            vis[p]=1;
            dfs1(p);
        }

    }

    finish.push_back(a);

}

ll dfs2(ll a)
{
    ll i,j,p;
    for(i=0;i<vis2[a];i++)
    {
        p=v2[a][i];
        if(vis[p]==0)
        {
            vis[p]=1;
            dfs2(p);
        }

    }

    v[q].push_back(val[a]);

}


int main()
{

    ll n,i,j,k,sum,ans,store,x,y,m,p;
    q=0;

    cin>>n;

    for(i=1;i<=n;i++)
        scanf("%I64d",&val[i]);

    cin>>m;

    for(i=1;i<=m;i++)
    {
        scanf("%I64d%I64d",&x,&y);

        v1[x].push_back(y);
        vis1[x]++;
        v2[y].push_back(x);
        vis2[y]++;}

    for(i=1;i<=n;i++)
    {
        if(vis[i]==0)
        {
            vis[i]=1;
            dfs1(i);
        }

    }


    for(i=1;i<=n;i++)
        vis[i]=0;

    for(i=n-1;i>=0;i--)
    {
        p=finish[i];
        if(vis[p]==0)
        {
            vis[p]=1;
            dfs2(p);

            q++;

        }

    }


    for(i=0;i<q;i++)
        sort(v[i].begin(),v[i].end());

    //for(i=0;i<v[1].size();i++)
       // cout<<v[1][i]<<" ";


    sum=0;
    //cout<<q<<endl;
    for(i=0;i<q;i++)
    {
        man[i]=v[i][0];
        sum+=man[i];

    }

     //cout<<sum;


    for(i=0;i<q;i++)
    {
        p=0;
        j=0;

        while(v[i][j]==man[i])
        {
            p++;
            j++;
            if(j==v[i].size())
                break;
        }
        num[i]=p;

    }

    ans=1;

    for(i=0;i<q;i++)
    {
        ans= (ans*num[i])%mod;
    }


    cout<<sum<<" "<<ans;




}
