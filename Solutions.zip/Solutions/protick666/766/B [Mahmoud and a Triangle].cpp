#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define  ll  long long int
#define ex exit(0)

    ll a[1000001];


main()
{
    ll n,i,j;
    cin>>n;
    for(i=0; i<n; i++)
        cin>>a[i];
    sort(a,a+n);

    for(i=2; i<n; i++)
    {
        if(a[i]<a[i-1]+a[i-2])
        {
            cout<<"YES";
            ex;
        }

    }
    cout<<"NO";

}
