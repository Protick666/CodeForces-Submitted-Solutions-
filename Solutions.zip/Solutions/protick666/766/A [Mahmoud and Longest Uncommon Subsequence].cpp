#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define  ll  long long int



main()
{

    ll u,v,n,i,j,k,l,sum,t,d,f,p;
    string a,b;
    cin>>a>>b;
    if(a==b)
        cout<<"-1";
    else
        cout<<max(a.length(),b.length());


}
