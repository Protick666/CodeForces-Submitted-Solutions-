#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};

map<string,ll> mm;
ll enemy[1000002];
int main()
{
    ll i,j,k,n,m,q,sum,p,a,b,u,v;



    cin>>n>>m>>q;
    UF f(2*n);
    for(i=1;i<=n;i++)
        {enemy[i]=i+n;
         enemy[i+n]=i;
        }

    UF r(n);
    string s,x,y;
    loop(i,n)
    {
        cin>>s;
        mm[s]=i+1;
    }

    fr(i,1,m)
    {
        cin>>p>>x>>y;
        if(p==1)
        {
            a=mm[x];
            b=mm[y];
            u=enemy[a];
            v=enemy[b];

            if(f.find(u)==f.find(b))
                {
                    cout<<"NO"<<endl;
                    cont;
                }
            f.merge(a,b);
            f.merge(u,v);
                        r.merge(a,b);

            cout<<"YES"<<endl;

        }

        else
        {
            a=mm[x];
            b=mm[y];
             u=enemy[a];
            v=enemy[b];
            if(f.find(a)==f.find(b))
                {
                    cout<<"NO"<<endl;
                    cont;
                }
            else
            {
                f.merge(u,b);
                f.merge(v,a);
            }

            r.merge(a,b);
            cout<<"YES"<<endl;

        }
    }

    fr(i,1,q)
    {
        cin>>x>>y;
        a=mm[x];
        b=mm[y];
        if(f.find(a)==f.find(b))
            cout<<1<<endl;
        else if(r.find(a)==r.find(b))
            cout<<2<<endl;
        else
            cout<<3<<endl;

    }


}
