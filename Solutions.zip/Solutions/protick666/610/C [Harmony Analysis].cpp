#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[1000][1000];


int main()
{
   ll n,i,j,k,l,sum,ans,z,y,w1,w2,d1,d2,e,d,r,f,p,x;

   a[1][1]=1;


   cin>>n;
   if(n==0)
   {
       cout<<"+";
       exit(0);
   }
   p=1;

   for(k=1;k<=n;k++)
   {

       i=1;j=p+1;

       x=1;
       y=1;

       for(l=1;l<=p;l++)
       {

           for(z=1;z<=p;z++)
           {a[i][j]=a[x][y];
            j++;
            y++;

           }
           j=p+1;
           y=1;
           i++;
           x++;

       }



       i=p+1;j=1;

       x=1;
       y=1;

       for(l=1;l<=p;l++)
       {

           for(z=1;z<=p;z++)
           {a[i][j]=a[x][y];
            j++;
            y++;

           }
           j=1;
           y=1;
           i++;
           x++;

       }



       i=p+1;j=p+1;

       x=1;
       y=1;

       for(l=1;l<=p;l++)
       {

           for(z=1;z<=p;z++)
           {a[i][j]=(-1)*a[x][y];
            j++;
            y++;

           }
           j=p+1;
           y=1;
           i++;
           x++;

       }


       p=p*2;
   }





for(i=1;i<=p;i++)
{
    for(j=1;j<=p;j++)
    {
        if(a[i][j]==1)
            printf("+");
        else
            printf("*");
    }

    printf("\n");
}



}
