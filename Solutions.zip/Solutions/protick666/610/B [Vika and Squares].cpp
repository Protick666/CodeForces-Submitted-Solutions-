
#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include <map>
#include<algorithm>

using namespace std;
#define max 100004


int a[200001];


main()

{
   long long int n,i,j,small,pos,start,mid,maxi,store;
   small=10000000009;
   maxi=-10;
   cin>>n;
   int a[n];
   for(i=0;i<n;i++){
    cin>>a[i];
    store=a[i];
    if(store<=small){
        small=store;
        pos=i;
    }
   }
 start=0;
for(i=0;i<n;i++)
{
    if(a[i]==small)
      break;
    start++;


}
mid=0;
for(;i<pos;i++)
{
    if(a[i]==small)
    {
        mid=0;
        continue;
    }
    mid++;
    if(mid>maxi)
        maxi=mid;
}
maxi=maxi>(start+n-1-pos)?maxi:(start+n-1-pos);

cout<<n*small+maxi;



}