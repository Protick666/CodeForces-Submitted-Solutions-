
#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include <map>
#include<algorithm>

using namespace std;
#define max 100004

int weight[max];
int ori[max];
pair<int,int> poop[max];
map<int,vector<pair<int,int> > > mymap;

main()

{
   long long int n,i,j;
   cin>>n;
   if(n%2==1 || n<4)
   cout<<"0";
   else

   cout<<((n-4)/2)/2+((n-4)/2)%2;
}