#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<pair<ll,ll> > row[300000];
vector<pair<ll,ll> > col[300000];

vector<pair<ll,ll> > d1[300000];
vector<pair<ll,ll> > d2[300000];
vector<pair<ll,ll> > ans;
map<ll,map<ll,ll> > vis;
ll a[100];



int main()
{
    ll i,j,k,r,l,v1,v2,t,x,y,n,m,cost;
    pair<ll,ll> p;
    cin>>n>>m;
    fr(i,1,m)
    {
        cin>>x>>y;
        p=mp(x,y);
        row[x].pb(p);
        col[y].pb(p);
        d1[x-y+n].pb(p);
        d2[x+y].pb(p);
        ans.pb(p);
    }
    for(i=1; i<=n; i++)
        sort(all(row[i]));

    for(i=1; i<=n; i++)
    {
        for(j=0; j<row[i].size(); j++)
        {
            p=row[i][j];
            //0 start j pos row[i].size() -1 last
            x=j;
            y=row[i].size()-j-1;
            if(x>0)
                vis[p.first][p.second]++;
            if(y>0)
                vis[p.first][p.second]++;


        }
    }

    for(i=1; i<=n; i++)
        sort(all(col[i]));
    for(i=1; i<=n; i++)
    {
        for(j=0; j<col[i].size(); j++)
        {
            p=col[i][j];
            //0 start j pos row[i].size() -1 last
            x=j;
            y=col[i].size()-j-1;
            if(x>0)
                vis[p.first][p.second]++;
            if(y>0)
                vis[p.first][p.second]++;


        }
    }

    for(i=1; i<=2*n-1; i++)
        sort(all(d1[i]));


    for(i=1; i<=2*n-1; i++)
    {
        for(j=0; j<d1[i].size(); j++)
        {
            p=d1[i][j];
            //0 start j pos row[i].size() -1 last
            x=j;
            y=d1[i].size()-j-1;
            if(x>0)
                vis[p.first][p.second]++;
            if(y>0)
                vis[p.first][p.second]++;


        }
    }
    for(i=1; i<=2*n; i++)
        sort(all(d2[i]));


    for(i=1; i<=2*n; i++)
    {
        for(j=0; j<d2[i].size(); j++)
        {
            p=d2[i][j];
            //0 start j pos row[i].size() -1 last
            x=j;
            y=d2[i].size()-j-1;
            if(x>0)
                vis[p.first][p.second]++;
            if(y>0)
                vis[p.first][p.second]++;


        }
    }

    for(i=0;i<ans.size();i++)
    {
        p=ans[i];
        t=vis[p.first][p.second];
        a[t]++;
    }

    for(i=0;i<=8;i++)
        cout<<a[i]<<" ";


}
