#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;



main()
{

long long int b,n,i,j,aa,bb,fa,f,fb,l,p,q,k,z,d,r,w,x,y,flag,m,sum,e;
cin>>n;
long long int a[n];
for(i=0;i<n;i++)
    scanf("%I64d",&a[i]);
sort(a,a+n);
sum=0;
for(i=1;i<n;i++)
{
    if(a[i]<=a[i-1])
    {
        sum=sum+(1+a[i-1]-a[i]);
        a[i]=1+a[i-1];
    }

}

cout<<sum;






}
