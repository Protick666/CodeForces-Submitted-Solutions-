
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define max 5000000
 int prime[2238];
 long long int check[max+1];
 long long int pro[max+1];

int mol=0;
long long int perch(long long int n)
{

    long long int i,sum=0;
    //printf("%I64d ",n);
    for(i=0;i<mol;i++)
    {
        if(n==1)
            break;
        while(n%prime[i]==0)
            {
                n=n/prime[i];
                sum++;

            }



    }

    if(n!=1)
        sum++;

    return sum;

}



main()
{

    long long int n,i,j,t,a,b,sum;
    scanf("%I64d",&t);
    for(i=2;i<=max;i++)
    {
        if(check[i]!=0)
            continue;


        for(j=2;j*i<=max;j++)
        {
            check[j*i]=i;

        }



    }
     for(i=2;i<=max;i++)
    {
        if(check[i]==0)
            check[i]++;


        else{

            check[i]=check[i/(check[i])]+1;

        }



    }

         for(i=2;i<=max;i++)
    {
        if(i==2)
            pro[i]=1;


        else{

            pro[i]=check[i]+pro[i-1];

        }



    }
  for(i=1;i<=t;i++)
   {
       scanf("%I64d%I64d",&b,&a);
       if(a==b)
       {
           printf("0\n");
       }

       else{

          sum=pro[b]-pro[a];


          printf("%I64d\n",sum);
       }


   }


}
