#include<math.h>
#include<stdio.h>
int flag=0;

main()
{

int len,sum,i,j,k,l,s,sum1,len1;
long long int max,min;
max=0;
min=0;
scanf("%d%d",&len,&sum);
if((sum==0 && len>1)||(sum>(9*len)))
printf("%d %d",-1,-1);
else if(sum==0 && len==0)
printf("%d %d",0,0);
else
{




sum1=sum;
if(sum1%9>0)
    len1=sum1%9;
else
    len1=0;
l=sum1/9;


//for(j=1;j<len;j++)
   // l=l*10;
//min=l;
//sum1=sum1-1;
for(i=len;i>=1;i--)
{  // if(sum1==0)
    //  break;
   // l=1;
  if(i<=l)
    {if(flag==0)
        printf("9");
    else
       {

        printf("8");
        flag=0;}


    }
  else if(i==l+1)
    printf("%d",len1);
  else if(i==len)
    {
        if(len1==0)
            {flag=1;

              printf("1");
              }
  else {printf("1");
  len1--;




  }

}
else
    printf("0");
}
printf(" ");

sum1=sum;
len1=len;
for(i=len;i>=1;i--)
{
    l=1;
    s=(sum1>=9)?9:sum1;
//for(j=1;j<i;j++)
   // l=l*10;
//max=max+s*l;
sum1=sum1-s;
printf("%d",s);
}


}










}



