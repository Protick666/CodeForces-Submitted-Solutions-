#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))



long long int v[3001][3001];
long long int m[3001][3001];
long long int vis[3001];
main()
{

long long int a,b,p,n,i,j,pf,af,aa,bb,fa,f,fb,t,l,q,k,z,r,w,x,y,flag,sum,e,val;
cin>>n>>t;

for(i=1;i<=t;i++)
{
    scanf("%I64d%I64d",&a,&b);
    vis[a]++;
    v[a][b]=1;
    m[a][vis[a]-1]=b;

}
sum=0;
for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        if(i==j)
            continue;
        r=0;
        for(p=0;p<vis[i];p++)
        {
            q=m[i][p];
            if(v[q][j]==1)
                r++;
        }
        sum=sum+r*(r-1)/2;


    }


cout<<sum;


}

