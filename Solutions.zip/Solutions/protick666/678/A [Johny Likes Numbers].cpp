#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007




int main()
{
   ll n,i,j,k,x,y,ans,sum,q,l,r,p,f,c;
   cin>>n>>k;

   n=n+1;

   p=n/k;

   if((n%k)==0)
     cout<<n;

   else
   {
       p++;
       cout<<k*p;
   }



}
