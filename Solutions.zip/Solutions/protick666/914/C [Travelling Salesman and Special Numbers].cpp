#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;

#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define MOD 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
 string s;
 map<ll,ll> val;
  map<ll,ll> tc;


ll fac[20000];
ll xGCD(ll a, ll b, ll &x, ll &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }

    ll x1, y1, gcd = xGCD(b, a % b, x1, y1);
    x = y1;
    y = x1 - (ll)(a / b) * y1;
    return gcd;
}

// factorial of n modulo MOD

// multiply a and b modulo MOD
ll modmult(ll a, ll b) {
    return (ll)a * b % MOD;
}

// inverse of a modulo MOD
ll inverse(ll a) {
    ll x, y;
    xGCD(a, MOD, x, y);
    return x;
}

// binomial coefficient nCk modulo MOD
int bc(int n, int k)
{
    return modmult(modmult(fac[n], inverse(fac[k])), inverse(fac[n - k]));
}
ll cal(ll i)
{
    if(i==1)
        return 0;
    ll sum=0;

    while(i!=0)
    {
        sum+=1 & i;
        i=i>>1;

    }
    return 1+cal(sum);
}
ll calu(string s)
{
     ll sum=0;
    for(int i=0;i<s.length();i++)
    {
        if(s[i]=='1')
         sum++;

    }

    return sum;
}

int main()
{
    ll i,j,k,l,m,n,a,b,c,t,x,y,tit,z;

      //vector<long long> f(n + 1,1);
      fac[0]=1;
      fac[1]=1;
      for(i=2;i<=2000;i++)
      {
          fac[i]=(fac[i-1]*i)%MOD;
      }

    cin>>s;
    z=calu(s);
    cin>>k;
    if(z==1 && s[s.length()-1]=='1' && k==1)
    {
        cout<<"0";
        ex;
    }
    /*for(i=0;i<s.length();i++)
    {
        if(s[i]=='1')
        {
            tit=s.length()-i;
            break;
        }
    }*/
    if(k==0)
    {

            cout<<1;
            ex;

    }
    //handle k=0;
  ll sum=0;
    for(i=1;i<=1024;i++)
    {
        ll p=cal(i);//
        if(p==k-1)
        {
            if(i==z)
              sum=(sum+1)%MOD;

            //cout<<i<<" hello"<<endl;

            ll b=0;
            for(j=0;j<s.length();j++)
            {
                ll ext=s.length()-j-1;
                if(s[j]=='1')
                {
                    ll lft=i-b;
                    if(ext>=lft && ext>=0 && lft>=0)
                    {
                        //cout<<b<<" "<<ext<<" "<<lft<<" "<<bc(ext,lft)<<endl;
                       ll g=bc(ext,lft);
                       if(g<0)
                        g+=MOD;
                        sum=(sum+g)%MOD;
                       if(sum<0)
                         sum+=MOD;
                    }
                    b++;
                }

            }
        }
    }
    if(k==1)
        sum--;

    cout<<sum;






}