#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;

map <char,int> f;
int ans[26][26];

map <char,vector<int> > v;


main()
{ int n,i,j,l,a,b,h;
h=0;
a=-1;
b=-1;
cin>>n;
char c,d;
char s[n+1];
char t[n+1];
scanf("%s",s);
scanf("%s",t);

for(i=0;i<n;i++)
{
    if(s[i]!=t[i])
    {   h++;
        c=s[i];
        d=t[i];
        ans[c-'a'][d-'a']=1;

        f[c]++;
        v[c].push_back(i);


    }
}

//cout<<endl;
//cout<<f['e'];


for(i=0;i<n;i++)
{
    if(s[i]!=t[i])
    {   d=t[i];

        c=s[i];
        if(f[d]>=1)
        {

            if(ans[d-'a'][c-'a']==1)

            {
                for(j=0;j<n;j++)
                {
                    if(s[j]==d && t[j]==c)
                    {
                        a=i;
                        b=j;
                        cout<<h-2<<endl;
                        cout<<a+1<<" "<<b+1;
                        exit(0);

                    }
                }
            }

            a=i;
            b=v[d][f[d]-1];


        }



    }
}




if(a==-1)
{
    cout<<h<<endl;
    cout<<"-1"<<" "<<"-1";
    exit(0);
}

cout<<h-1<<endl;

cout<<a+1<<" "<<b+1;








}