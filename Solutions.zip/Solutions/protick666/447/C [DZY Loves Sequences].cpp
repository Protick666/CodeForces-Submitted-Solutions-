#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;
ll a[1000000];
priority_queue<ll> row;
priority_queue<ll> col;
ll i,j,k,n,p,t,m,sum,r,u,ans,z,x,y,l,g,w;
string s;
 ll lleft[10000000];
ll rright[10000000];

main()
{

    cin>>n;

    for(i=1;i<=n;i++)
        cin>>a[i];

        x=1;
        y=1;
        lleft[1]=1;
        rright[n]=1;
        a[0]=-19000000000;
        a[n+1]=100000000000000000;
        for(i=2;i<=n;i++)
        {
            if(a[i-1]<a[i])
            {
                lleft[i]=lleft[i-1]+1;
            }
            else
                lleft[i]=1;

        }


         for(i=n-1;i>=1;i--)
        {
            if(a[i+1]>a[i])
            {
                rright[i]=rright[i+1]+1;
            }
            else
                rright[i]=1;

        }
        ans=1;

        for(i=1;i<=n;i++)
        {
            if(a[i+1]-a[i-1]>=2)

                ans=max(ans,lleft[i-1]+rright[i+1]+1);

                else
                ans=max3(ans,lleft[i-1]+1,rright[i+1]+1);


        }



cout<<ans;

}
