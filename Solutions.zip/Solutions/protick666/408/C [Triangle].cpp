#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007


ll l1[1001];
ll r1[1001];
ll l2[1001];
ll r2[1001];

void check(ll a, ll b,ll c,ll d)
{
    //cout<<a<<" "<<b<<" "<<c<<" "<<d<<endl;
    if(a==b && a==c && c==d)
        return;
    if(a==b && c!=d)
        return;
    if(c==d && a!=b)
        return;
    ll p;
    p=c;
    c=d;
    d=p;
    if(a*c!=b*d)
        return;
    if(c!=a)
    {



    cout<<"YES"<<endl;

    cout<<"0 0"<<endl;
    cout<<a<<" "<<b<<endl;
    cout<<c<<" "<<(-d);
    exit(0);}

     if(d!=b)
    {



    cout<<"YES"<<endl;

    cout<<"0 0"<<endl;
    cout<<a<<" "<<b<<endl;
    cout<<-c<<" "<<(d);
    exit(0);}
}


int main()
{
   ll n,i,j,x,y,sum,p,q,m,ans,l,r,a,b;
   cin>>a>>b;
   l=0;r=0;

   for(i=1;i<=a;i++)
   {
       for(j=i;j<=a;j++)
       {

           if(i*i+j*j==a*a)
           {
               l1[l]=i;
               r1[l]=j;
               //cout<<i<<" "<<j<<endl;
               l++;

           }
       }
   }

   for(i=1;i<=b;i++)
   {
       for(j=i;j<=b;j++)
       {

           if(i*i+j*j==b*b)
           {
               l2[r]=i;
               r2[r]=j;
               r++;

           }
       }
   }



for(i=0;i<l;i++)
{
    for(j=0;j<r;j++)
    {
        check(l1[i],r1[i],l2[j],r2[j]);
    }
}


cout<<"NO";


}
