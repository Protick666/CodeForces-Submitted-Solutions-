#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define mama 1000000007
ll a[1000000];
ll prev[1000000];
ll dp[1000000];
ll val[1000000];



main()
{


    ll i,j,k,n,sum,p,q,r,store,cur,x,y,l;

    cin>>n;

    for(i=1;i<=n;i++)
        cin>>prev[i];

    for(i=1;i<=n;i++)
    {
        if(i==1)
        {
            val[i]=2;
            dp[i]=2;

        }
        else
        {
            val[i]=(2+dp[i-1]-dp[prev[i]-1])%mama;
            if(val[i]<0)
                val[i]=val[i]+mama;
            dp[i]=(dp[i-1]+val[i])%mama;
        }



    }

    cout<<dp[n];

    //cin>>n;




}
