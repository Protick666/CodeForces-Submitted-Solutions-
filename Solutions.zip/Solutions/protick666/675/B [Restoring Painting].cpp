#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


int main() {
ll i,j,a,b,c,d,x,y,z,p,q,sum,n;

cin>>n>>a>>b>>c>>d;
sum=0;
for(i=1;i<=n;i++)
{
    q=i;
    p=q+c-b;
    z=q+d-a;
    x=p+d-a;



    if(x<=0 || z<=0 || p<=0 || q<=0)
        continue;
    if(x>n || z>n || p>n || q>n)
        continue;
    sum=sum+n;


}

cout<<sum;




}
