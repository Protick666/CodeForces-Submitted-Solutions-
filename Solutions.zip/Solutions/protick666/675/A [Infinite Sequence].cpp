#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


int main() {
ll i,j,a,b,c,p,sum;

cin>>a>>b>>c;

if(b>a)
{
    if(c<=0)
    {
        cout<<"NO";
        exit(0);
    }
    if(((b-a)%c)==0)
        {
        cout<<"YES";
        exit(0);
    }
    else
         {
        cout<<"NO";
        exit(0);
    }

}
else if(b<a)
{
    if(c>=0)
    {
        cout<<"NO";
        exit(0);
    }
    p=b-a;
    p=p*-1;
    c=c*-1;

    if((p%c)==0)
        {
        cout<<"YES";
        exit(0);
    }
    else
         {
        cout<<"NO";
        exit(0);
    }


}

if(a==b)
{
    
        cout<<"YES";
        exit(0);
    
   

}



}
