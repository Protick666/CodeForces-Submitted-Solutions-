#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int



int main() {
ll i,j,n,m,store,sum,v,f,k,ans,a,b,c,d;
cin>>n>>k;
cin>>a>>b>>c>>d;
if(n<=4 || k<n+1)
    cout<<"-1";
else
{
    cout<<a<<" "<<c<<" ";
    for(i=1;i<=n;i++)
    {
        if(i==a || i==b || i==c || i==d)
            continue;
        else
            cout<<i<<" ";
    }
    cout<<d<<" "<<b<<" ";
    cout<<endl;







     cout<<c<<" "<<a<<" ";
    for(i=1;i<=n;i++)
    {
        if(i==a || i==b || i==c || i==d)
            continue;
        else
            cout<<i<<" ";
    }
    cout<<b<<" "<<d<<" ";



}




}
