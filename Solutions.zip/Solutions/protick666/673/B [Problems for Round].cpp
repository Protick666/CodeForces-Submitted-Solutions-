#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


ll pos[1000000];
ll l[1000000];
ll r[1000000];


int main() {
ll i,j,n,m,sum,store,k,x,y,z,ans,a,b,u,v,f;
f=1;
u=0;
v=0;
z=-1;
sum=10000000000;
cin>>n>>m;
for(i=1;i<=m;i++)
{
    scanf("%I64d%I64d",&x,&y);
    a=min(x,y);
    b=max(x,y);
    if(pos[a]==2 || pos[b]==1 || b<z || a>sum)
    {
        f=-1;
    }
    if(pos[a]==0)
    {



    if(a>z)
        z=a;
    pos[a]=1;

    }
    if(pos[b]==0){
            if(b<sum)
               sum=b;
      pos[b]=2;

    }

}

ans=0;
if(m==0)
{
    cout<<n-1;
    exit(0);
}

for(i=z+1;i<=sum-1;i++)
{
    if(pos[i]==0)
        ans++;
}
if(f==-1)
    cout<<"0";
else
cout<<ans+1;



}
