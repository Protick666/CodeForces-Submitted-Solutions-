#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
map<ll,ll> m;
ll a[1000000];

ll i,j,k,n,p,t,q,sum,r,u,ans,z,x,y,l,g,w;
string s;


main()
{
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>a[i];

    for(i=1;i<=n;i++)
    {
        cin>>p;
        m[p]=i;
    }

    for(i=1;i<=n;i++)
    {
        a[i]=m[a[i]];
    }

    q=1;
    while(1)
    {
        if(q==n)
            break;
        if(a[q+1]>a[q])
            q++;
        else
            break;

    }

    cout<<n-q;



}
