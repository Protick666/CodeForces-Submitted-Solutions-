#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 100000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<ll> v[1000002];
ll dp[1000009];
ll vis[1000009];

void dfs(ll a,ll t)
{
     //cout<<a<<endl;
    vis[a]=1;
    ll i,j,sum,x,y;
    x=maxx;
    y=0;
    for(i=0;i<v[a].size();i++)
    {
        ll p=v[a][i];
        if(vis[p]==1)
            cont;
        dfs(p,(t+1)%2);
        y+=dp[p];
        x=min(x,dp[p]);

    }
    if(y==0)
        y=1;
    if(x==maxx)
        x=1;

    if(t==0)
        dp[a]=x;
    else
       dp[a]=y;

       //cout<<a<<" "<<dp[a]<<endl;



}
main()
{
    ll sum,j,k,l,i,x,y,t,p,z,n;
    cin>>n;
    fr(i,1,n-1)
    {
        cin>>x>>y;
        v[x].pb(y);
         v[y].pb(x);
    }
    if(n==1)
    {
        cout<<1<<" "<<1;
        ex;
    }
    z=0;

    for(i=1;i<=n;i++)
    {
        if(v[i].size()==1)
            z++;
    }
    if(v[1].size()==1)
        z--;


    dfs(1,0);

    cout<<z-dp[1]+1<<" ";
    fr(i,0,1000002)
      vis[i]=0;
    dfs(1,1);
    cout<<dp[1];


}
