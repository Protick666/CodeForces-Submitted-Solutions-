#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll dp2[100003];
ll fdp2[1000003];
ll vis2[100003];
ll cvis2[1000003];
ll dp1[100003];
ll fdp1[1000003];
ll vis1[100003];
ll cvis1[1000003];
vector<pair<ll,ll> > vv1[1000002];
vector<pair<ll,ll> > vv2[1000002];



int main() {

   ll n,i,j,k,l,m,x,y,c,d,a,b;
   cin>>n>>m>>k;
   pair<ll,ll> p;
   fr(i,1,m)
   {
       in2(d,x);
       in2(y,c);
       if(y==0)
       {
           p=mp(x,c);
           vv1[d].pb(p);
       }
       else
       {
           p=mp(y,c);
           vv2[d].pb(p);
       }
    }
    //flag(1);

    for(i=1000001;i>=1;i--)
    {
        ll sum=0;
        ll dd=0;
        cvis2[i]=cvis2[i+1];
        for(j=0;j<vv2[i].size();j++)
        {
            p=vv2[i][j];
            x=p.first;
            y=p.second;
            if(vis2[x]==0)
            {
                vis2[x]=1;
                cvis2[i]++;
                dp2[x]=y;
                sum+=y;
            }
            else
            {
                a=dp2[x];
                if(y>=a)
                    cont;
                else
                {
                    dd+=a-y;
                    dp2[x]=y;

                }
            }

        }
        fdp2[i]=sum+fdp2[i+1]-dd;

    }
    //flag(2);


     for(i=1;i<=1000001;i++)
    {
        ll sum=0;
        ll dd=0;
         cvis1[i]=cvis1[i-1];
         //cout<<i<<" "<<cvis1[i]<<endl;
        for(j=0;j<vv1[i].size();j++)
        {
            p=vv1[i][j];
            x=p.first;
            y=p.second;
            if(vis1[x]==0)
            {
                //cout<<i<<endl;
                vis1[x]=1;
                cvis1[i]++;
                dp1[x]=y;
                sum+=y;
            }
            else
            {
                a=dp1[x];
                if(y>=a)
                    cont;
                else
                {
                    dd+=a-y;
                    dp1[x]=y;

                }
            }

        }
        fdp1[i]=sum+fdp1[i-1]-dd;

    }
    ll tit=10000000000000000;
    ll ans=tit;
    //cin>>tit;
    //cout<<" he"<<cvis1[3]<<"lol "<<endl;

    for(i=1;;i++)
    {
        x=i;
        y=i+k-1;
        if(y>1000000)
            break;
        if(cvis1[x-1]<n)
            cont;
        if(cvis2[y+1]<n)
            break;
        ans=min(ans,fdp1[x-1]+fdp2[y+1]);
    }
    if(ans==tit)
        cout<<"-1";
    else
        cout<<ans;
}
