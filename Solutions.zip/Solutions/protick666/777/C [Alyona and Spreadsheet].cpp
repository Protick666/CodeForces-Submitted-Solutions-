#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl

map<ll, map<ll,ll> >  p;

map<ll,ll> ans;
int main()
{

    ll n,m,sum,i,j,z,x,y,r,t,k;
    cin>>n>>m;
    ll a[n+1][m+1];

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
            cin>>a[i][j];
    }

    for(i=1;i<=m;i++)
    {
        x=1;y=1;
        while(y<=n)
        {
            r=a[y-1][i];
            if(x==y)
                r=a[y][i];
            t=a[y][i];
            if(t<r)
            {
                x++;
                if(y<x)
                    y=x;
                cont;
            }
            p[i][x]=y-x;
            y++;

        }

        for(j=1;j<=n;j++)
            p[i][j]=max(p[i][j],p[i][j-1]-1);

    }

    //for(i=1;i<=n;i++)
    //{
       // for(j=1;j<=m;j++)
           // cout<<p[j][i]<<" ";
        //nl;
    //}

    cin>>k;

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
          ans[i]=max(ans[i],p[j][i]);

    }

    loop(i,k)
    {
        cin>>x>>y;
        if(ans[x]>=y-x)
            cout<<"Yes"<<endl;
        else
            cout<<"No"<<endl;
    }

}
