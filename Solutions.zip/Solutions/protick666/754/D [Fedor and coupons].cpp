#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000002];
int main()
{
    ll n,m,q,i,j,k,l,sum,ans,x,y,b,t,r;

        std::multiset<ll> myset;
        std::multiset<ll>::iterator it;
        vector<pair<ll,ll> > v;
                vector<pair<ll,ll> > z;
                pair<ll,ll> p;

        cin>>n>>k;
        sum=0;

        fr(i,1,n)
        {
            cin>>x>>y;
            p=mp(x,y);
            v.pb(p);
            z.pb(p);


        }

        sort(all(v));



        for(i=0;i<v.size();i++)
        {
            if(myset.size()<k-1)
            {
                myset.insert(v[i].second);
                cont;
            }
            it=myset.begin();
            y=*it;
            x=v[i].first;
            y=min(y,v[i].second);
            //cout<<i<<" "<<y<<" "<<x<<" "<<v[i].second<<endl;
            if(y-x+1>sum)
            {
                sum=y-x+1;
                l=x;
                r=y;

            }
            myset.insert(v[i].second);
            if(myset.size()>k-1)
            {
                it=myset.begin();
                //cout<<i<<" wa"<<*it<<endl;
                myset.erase(it);
            }

        }

        cout<<sum<<endl;
        t=0;
        if(sum==0)
        {
            fr(i,1,k)
              cout<<i<<" ";
        }

        else
        {
            for(i=0;i<z.size();i++)
            {
                x=z[i].first;
                y=z[i].second;
                if(x<=l && y>=r)
                    {cout<<i+1<<" ";
                      t++;
                    }
                if(t==k)
                    break;
            }

        }



}


