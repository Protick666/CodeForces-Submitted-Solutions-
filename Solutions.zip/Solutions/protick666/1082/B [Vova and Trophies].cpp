#include <bits/stdc++.h>

#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 100000007
#define PI 3.14159265

vector<pair<ll,ll> > v[2];
int main()
{
    //n, x, y, d
    ll n,t,p,k,l,m,x,y,d;

    cin>>n;

    char ch[1000002];

    scanf("%s", ch);

    string s = ch;

    ll ans = 0;

    for(int i=0; i<s.length(); )
    {
        int j;
        for(j = i; s[j] == s[i]; j++)
        {
            if(j == s.length())
                break;
        }

        ll ind = (s[i] =='G') ? 0 : 1;

        //cout<<ind<< " "<<i<<" "<<j<<endl;

        v[ind].push_back(make_pair(i,j-1));

        i = j;
    }

    for(int i=0; i<1; i++)
    {
        if(v[i].size() == 0)
            cont;
        for(int j=0; j < v[i].size(); j++)
        {
            //cout<<"yo";
            ans = max(ans, v[i][j].second - v[i][j].first + 1);

            if(v[i].size() != 1)
                ans = max(ans, v[i][j].second - v[i][j].first + 2);
        }
    }

    for(int i=0; i<1; i++)
    {
         if(v[i].size() == 0)
            cont;
        for(int j=0; j<v[i].size() - 1; j++)
        {
            //cout<<"yo";
            if(v[i][j].second == v[i][j+1].first - 2)
                {
                     if(v[i].size() > 2)
                        ans = max(ans, v[i][j].second - v[i][j].first + 3 +  v[i][j + 1].second - v[i][j + 1].first );
                     else
                        ans = max(ans, v[i][j].second - v[i][j].first + 2 +  v[i][j + 1].second - v[i][j + 1].first );

                        
                  
                }
        }
    }


    cout<<ans;

}