#include<stdio.h>
main()
{

int num,x,y,r,c,i,j,k,flag,point,vag;
scanf("%d%d%d",&r,&c,&num);
vag=(r*c)/num;
flag=1;
x=1,
y=1;
for(i=1;i<=num;i=i+1)
    {
        if(i==num)

        {   printf("%d ",vag+((r*c)%num));
            for(j=1;j<=vag+((r*c)%num);j=j+1)
             {
                if(y==1 && flag==-1)
                   {  printf("%d %d ",x,y);
                       x=x+1;
                    flag=flag*(-1);

                   }


                 else if(y==c && flag==1)
                 {
                     printf("%d %d ",x,y);

                     x=x+1;
                     flag=flag*(-1);

                 }

              else
              {
                  printf("%d %d ",x,y);
                  y=y+flag;





              }


        }
        printf("\n");
       }



































   else
       {

       printf("%d ",vag);
       for(j=1;j<=vag;j=j+1)
             {
                if(y==1 && flag==-1)
                   {printf("%d %d ",x,y);
                       x=x+1;
                    flag=flag*(-1);

                   }


                 else if(y==c && flag==1)
                 {
                     printf("%d %d ",x,y);

                     x=x+1;
                     flag=flag*(-1);

                 }

              else
              {
                  printf("%d %d ",x,y);
                  y=y+flag;





              }


        }
        printf("\n");
       }
    }

































}
