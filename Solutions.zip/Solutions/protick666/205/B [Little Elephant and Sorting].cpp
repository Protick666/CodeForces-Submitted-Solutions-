#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007

ll a[1000000];

int main()
{
   ll n,i,j,x,y,sum,p,r;

   cin>>n;
   sum=0;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d",&a[i]);
   }

   for(i=2;i<=n;i++)
   {
       p=a[i-1]-a[i];
       if(p>0)
        sum+=p;



   }

   cout<<sum;


}
