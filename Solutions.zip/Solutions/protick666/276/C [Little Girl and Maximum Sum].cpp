#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
#define LSOne(S) (S & (-S))

ll ft[1000000];
 vector<ll> vv;
 pair<ll,ll> p;

 ll ans[1000000];
 ll fin[1000000];

// Array size
ll N;

// Point query: Returns the value at position b in the array
ll query(ll b)	{
	ll sum = 0;
	for (; b; b -= LSOne(b)) sum += ft[b];
	return sum;
}

// Point update: Adds v to the value at position k in the array
void update(ll k, ll v) {

	for (; k <= N; k += LSOne(k))

    {ft[k] += v;
    //cout<<"pore";

    }
}

// Range update: Adds v to each element in [i...j] in the array
void range_update(ll i, ll j, ll v)	{
     //cout<<i<<" "<<j<<" "<<v<<endl;
	update(i, v);
	update(j + 1, -v);
}

int main()  {
	ll T, U, q, i,j, l, r, val,x,y,sum;
	sum=0;


cin>>N>>q;

for(i=0;i<N;i++)
    scanf("%I64d",&ans[i]);
sort(ans,ans+N);
		//scanf("%d %d", &N, &U);
		//memset(ft, 0, (N+1) * sizeof(ll));

//array is indexed from 1 to n
// update or query takes Olog(n) time

for(i=1;i<=q;i++)
{
    scanf("%I64d%I64d",&x,&y);
//cout<<"age";
    range_update(x,y,1);
    //cout<<"pore";

}

for(i=1;i<=N;i++)
{
    x=query(i);

    vv.push_back(x);

}

sort(vv.begin(),vv.end());

for(i=0;i<N;i++)
{
    x=vv[i];
    y=ans[i];
    sum+=x*y;


}

cout<<sum;



}
