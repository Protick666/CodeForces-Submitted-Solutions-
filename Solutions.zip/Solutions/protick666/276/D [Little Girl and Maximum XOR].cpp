#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007

ll a[65];
ll b[65];


int main()
{
   ll n,i,j,k,x,y,ans,sum,q,l,r,p,f,c;

   cin>>l>>r;

   p=1;

   for(i=1;i<=64;i++)
   {
       q=l&p;
       if(q==0)
         a[i]=0;
       else
        a[i]=1;

        q=r&p;
       if(q==0)
         b[i]=0;
       else
        b[i]=1;

        p=p<<1;

   }

   ans=0;

f=0;
c=0;

for(i=64;i>=1;i--)
   {
       if(a[i]==1 && b[i]==1)
       {
           if(f==1)
           {
               ans=ans*2+1;
               c=1;

           }
           else
           ans=ans*2;

       }

       else if(a[i]==1)
       {

           ans=ans*2+1;

       }
        else if(b[i]==1)
       {

           ans=ans*2+1;
            f=1;

       }

        else if(c==1 || f==1)
       {

           ans=ans*2+1;
       }

        else
       {

           ans=ans*2;
       }



   }

   cout<<ans;

}
