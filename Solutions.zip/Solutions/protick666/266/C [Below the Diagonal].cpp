#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll oldr[10000];
ll oldc[10000];
ll newr[10000];
ll newc[10000];
ll t=1;
vector<pair<ll,ll> > vv;
ll g=0;
vector<ll> v[10000];
vector<pair<ll,ll> > ans;
void sp(ll p,ll a,ll b)
{
    ll x,y,i;
    if(p==1)
    {
        x=oldr[a];
        y=oldr[b];
        swap(oldr[a],oldr[b]);
        newr[x]=b;
        newr[y]=a;
        if(a!=b)
        {
            ans.pb(mp(a,b));
            g++;
        }
    }
    else
    {
        x=oldc[a];
        y=oldc[b];
        swap(oldc[a],oldc[b]);
        newc[x]=b;
        newc[y]=a;
        t++;
        if(a!=b)
            ans.pb(mp(a,b));
    }
}
main()
{
    ll i,j,k,l,n,a,b,x,y;
    cin>>n;
    fr(i,1,n)
    {
        oldc[i]=i;
        newc[i]=i;
        oldr[i]=i;
        newr[i]=i;
    }
    fr(i,1,n-1)
    {
        cin>>x>>y;
        v[x].pb(y);
    }
    pair<ll,ll> p;
    fr(i,1,n)
    vv.pb(mp(v[i].size(),i));

    sort(all(vv));
    for(i=0; i<vv.size(); i++)
    {
        p=vv[i];
        x=p.first;
        y=p.second;
        sp(1,i+1,newr[y]);
    }
    fr(i,1,n)
    {
        x=oldr[i];
        ll lim=i-1;
        vector<ll> tit;
        for(j=0; j<v[x].size(); j++)
            tit.pb(newc[v[x][j]]);
        sort(all(tit));
        for(j=0; j<tit.size(); j++)
        {
            a=tit[j];
            if(a<t)
                cont;
            sp(2,t,a);
        }
    }
    cout<<ans.size()<<endl;
    fr(i,1,ans.size())
    {
        j=i-1;
        if(i<=g)
            cout<<"1 "<<ans[j].first<<" "<<ans[j].second<<endl;
        else
            cout<<"2 "<<ans[j].first<<" "<<ans[j].second<<endl;
    }
}
