#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll n;
ll xx[10000];
ll yy[10000];

ll lul(ll a,ll b,ll c,ll d)
{
    ll x,y,x1,y1,x2,x3,y2,y3;
    x=xx[a];
    y=yy[a];
    x1=xx[b];
    y1=yy[b];
    x2=xx[c];
    y2=yy[c];
    x3=xx[d];
    y3=yy[d];
    ll r=(x1-x)*(y2-y3)-(x2-x3)*(y1-y);
    if(r==0)
        return 1;
    else return 0;

}
ll ck(ll p,ll q)
{
    vector<ll> ok;
    vector<ll> nok;
    ll i;
    ll x,y,x1,y1,x2,y2;
    x=xx[p];
    y=yy[p];
    x1=xx[q];
    y1=yy[q];
    ok.pb(p);
    ok.pb(q);
    //cout<<p<<" "<<q<<endl;
    fr(i,1,n)
    {
        //cout<<"yo "<<i<<endl;
        if(i==p || i==q)
            cont;
        y2=yy[i];
        x2=xx[i];
        //cout<<x<<" "<<y<<"   "<<x1<<" "<<y1<<"   "<<x2<<" "<<y2<<"   "<<endl;
    ll s = (y2 - y1) * x + (x1 - x2) * y + (x2 * y1 - x1 * y2);

        if (s < 0)
            nok.pb(i);
        else if (s > 0)
            nok.pb(i);
        else
            ok.pb(i);

    }
    //cout<<"nok "<<nok.size()<<" "<<"ok "<<ok.size()<<endl;
    if(nok.size()==0)
        return 0;
    if(nok.size()==1)
        return 1;

    x=xx[nok[0]];
    y=yy[nok[0]];
    x1=xx[nok[1]];
    y1=yy[nok[1]];
    for(i=2;i<nok.size();i++)
    {
        y2=yy[nok[i]];
        x2=xx[nok[i]];
        ll s = (y2 - y1) * x + (x1 - x2) * y + (x2 * y1 - x1 * y2);

        if (s < 0)
            return 0;
        else if (s > 0)
            return 0;
    }

    ll temp=lul(ok[0],ok[1],nok[0],nok[1]);
    //cout<<p<<" "<<q<<" "<<temp<<" temp"<<endl;
    if(temp==1)
        return 1;
    else return 0;


}
void yyy()
{
    cout<<"Yes";
    ex;
}
int main()
{
    ll i,j,k,l,m,q,t;
    cin>>n;
    fr(i,1,n)
    {
        xx[i]=i;
        in(k);
        yy[i]=k;
    }

//q=0;
    q=ck(1,2);
    //cout<<"bo1";
    if(q==1)
        yyy();
    q=ck(1,3);
    //cout<<"boi2";
    if(q==1)
        yyy();
    q=ck(2,3);
    if(q==1)
        yyy();

  cout<<"No";

}

