#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int



main()
{

    ll n,i,j,k,sum,ans,store,x,y,z,q,t,p,f;

    cin>>t;

    for(k=1;k<=t;k++)
    {
        cin>>n>>p;


        for(i=1;i<=n;i++)
        {
            x=i+1;
            y=i+2;
            if(x>n)
                x=x%n;
            if(y>n)
                y=y%n;

            printf("%I64d %I64d\n",i,x);


            printf("%I64d %I64d\n",i,y);

        }

        sum=0;
f=0;
        for(i=1;i<=n;i++)
        {
            if(p==0)
                break;
            for(j=i+3;j<=n;j++)
            {
                if(abs(n-j)+i<=2)
                    break;

                printf("%I64d %I64d\n",i,j);

                sum++;
                if(sum==p)
                {f=1;
                    break;

                }
            }
            if(f==1)
                break;


        }



    }


}

