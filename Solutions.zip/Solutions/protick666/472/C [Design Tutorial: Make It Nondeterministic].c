#include<stdio.h>
#include <string.h>
#include <stdlib.h>
char a[100001][2][50];
long long int order[100000];
main()
{


    long long int n,i;

    scanf("%I64d",&n);
    char store1[52];
    char store2[52];
    char *store;
    for(i=1; i<=n; i++)
    {


        scanf("%s%s",store1,store2);
        if(strcmp(store1,store2)<0)
        {
            strcpy(a[i][0],store1);
            strcpy(a[i][1],store2);
        }

        else
        {
            strcpy(a[i][0],store2);
            strcpy(a[i][1],store1);
        }
    //printf("%s %s\n",a[i][0],a[i][1]);


    }
    
    for(i=1; i<=n; i++)
        scanf("%I64d",&order[i]);

store=a[order[1]][0];

for(i=2;i<=n;i++)
{
 if(strcmp(store,a[order[i]][0])<0)
 {
     store=a[order[i]][0];
     
     //printf("1\n");
     continue;

 }
   else if(strcmp(store,a[order[i]][1])<0)
 {
     store=a[order[i]][1];
     
     //printf("2\n");
     continue;

 }

 break;


}

if(i==n+1)
    printf("YES");
else
    printf("NO");




}