#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

long long int a[42][42];
long long int f[42][42];
long long int ans[42][42][42][42];





main()
{
long long int n,m,i,j,p,q,x,y,b,k,l,w,u,v,flag,z;
cin>>n>>m>>q;
char s[43];
char c;



for(i=1;i<=n;i++)
{
    scanf("%s",s);
    for(j=1;j<=m;j++)
    {
        c=s[j-1];
        if(c=='1')
            z=1;
        else
            z=0;
        //scanf("%I64d",&b);
        a[i][j]=z;
        f[i][j]=f[i][j-1]+z;

    }
}



for(j=1;j<=m;j++)
{
    for(i=1;i<=n;i++)
    {
        //scanf("%I64d",&b);
        //a[i][j]=b;
        f[i][j]=f[i][j]+f[i-1][j];

    }
}
/*
for(i=1;i<=n;i++)
{
    for(j=1;j<=m;j++)
        cout<<f[i][j]<<" ";
    cout<<endl;


}*/

for(l=0;l<=n-1;l++)
{
    for(w=0;w<=m-1;w++)
    {

        for(u=1;u<=n;u++)
        {
            v=u+l;
          if(v>n)
            break;




            for(x=1;x<=m;x++)
            {
                y=x+w;
                  if(y>m)
                    break;


                if(x==y && u==v)
                {
                    z=a[u][x];
                    if(z==1)
                        z=0;
                    else
                        z=1;

                    ans[u][v][x][y]=z;



                }
                else if(u==v)
                {

                    flag=f[v][y]-f[v][x-1]-f[u-1][y]+f[u-1][x-1];
                    if(flag==0)
                        flag=1;
                    else
                        flag=0;

                ans[u][v][x][y]=flag+ans[u][v][x+1][y]+ans[u][v][x][y-1]-ans[u][v][x+1][y-1];



                }



                else if(x==y)
                {

                    flag=f[v][y]-f[v][x-1]-f[u-1][y]+f[u-1][x-1];
                    if(flag==0)
                        flag=1;
                    else
                        flag=0;


                  ans[u][v][x][y]=flag+ans[u+1][v][x][y]+ans[u][v-1][x][y]-ans[u+1][v-1][x][y];



                }
                else
                {
                    flag=f[v][y]-f[v][x-1]-f[u-1][y]+f[u-1][x-1];
                    if(flag==0)
                        flag=1;
                    else
                        flag=0;
                    ans[u][v][x][y]=flag+ans[u+1][v][x][y]+ans[u][v-1][x][y]+ans[u][v][x+1][y]+ans[u][v][x][y-1];
                    ans[u][v][x][y]=ans[u][v][x][y]-ans[u][v][x+1][y-1]-ans[u][v-1][x][y-1]-ans[u][v-1][x+1][y]-ans[u+1][v-1][x][y]-ans[u+1][v][x+1][y]-ans[u+1][v][x][y-1];
                  ans[u][v][x][y]=ans[u][v][x][y]+ans[u][v-1][x+1][y-1]+ans[u+1][v][x+1][y-1]+ans[u+1][v-1][x][y-1]+ans[u+1][v-1][x+1][y];
                   ans[u][v][x][y]=ans[u][v][x][y]-ans[u+1][v-1][x+1][y-1];


                }






            }


        }
    }



}



for(i=1;i<=q;i++)
{
    scanf("%I64d%I64d%I64d%I64d",&u,&v,&x,&y);
    printf("%I64d\n",ans[u][x][v][y]);


}


}
