#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int



int main() {

    ll i,j,k,l,sum,ans,n,p,a,b,m,s,w;
    cin>>w>>s>>p;
    w=w/p;
    sum=0;
    n=s;
    l=0;
    while(n!=0)
    {
        l++;
        n=n/10;
    }



  m=1;
  for(i=1;i<=l;i++)
  {
      m*=10;
  }
//m=m*1000;
   //cout<<m<<" ";

  while(1)
  {
      n=m-s;
      //cout<<n<<endl;
      if((l*n)<=w)
      {

          w=w-l*n;
          l++;
          sum=sum+n;
          s=m;
          m=m*10;


      }

      else
      {
           //cout<<"dhukechi"<<endl;
          k=w/(l);
           //cout<<k<<endl;
          sum=sum+k;
          break;
      }


  }

cout<<sum;

}
