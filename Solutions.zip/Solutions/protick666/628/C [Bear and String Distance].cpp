#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;


#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

     #define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _b : _a; })







main()
{
    long long int sum,n,k,i,j,a,b,p,q,r,g,aa,bb,flag;
    char s;


    cin>>n>>k;


    char c[n+1];
    scanf("%s",c);
    sum=0;
    for(i=0;i<n;i++)
    {

        s=c[i];
        a=abs(s-'a');
        b=abs(s-'z');
        sum=sum+max(a,b);
        if(sum>=k)
            break;


    }

    if(sum<k)
    {
        printf("-1");
        exit(0);
    }

    sum=k;
    flag=1;
    for(i=0;i<n;i++)
    {
        s=c[i];
        a=abs(s-'a');
        b=abs(s-'z');


        if(b<a)
            flag=-1;
        else
            flag=1;
        a=max(a,b);

        g=min(sum,a);
        s=s+(flag)*(g);
        printf("%c",s);
        sum=sum-g;
        if(sum<=0)
        {
            i++;
            break;
        }






    }

    for(;i<n;i++)
        printf("%c",c[i]);

}
