#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;











main()
{
  string s,p;
  char c[300001];
  long long int i,j,k,l,store,sum,len;
  sum=0;

  scanf("%s",c);
  s=c;
  len=s.length();
  for(i=0;i<len;i++)
  {

      if(i==0)
      {
          if(s[0]=='4' || s[0]=='8' || s[i]=='0')
            sum++;


      }

      else
      {

          if(s[i]=='4' || s[i]=='8' || s[i]=='0')
            sum++;
          p=s.substr(i-1,2);
          //cout<<p<<endl;
          store=10*(p[0]-'0')+(p[1]-'0');
          if(store%4==0)
            sum=sum+i;




      }





  }




printf("%I64d",sum);


}
