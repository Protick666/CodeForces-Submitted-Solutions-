#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int

vector <ll> v[1000001];
ll len[1000001];
ll a[1000001];
ll vis[1000001];

int main() {
ll i,j,n,sum,ans,store,p,k,f,l,w,x,y;
cin>>n;
j=1;
for(i=1;i<=n;i++)
{
    scanf("%I64d",&sum);
    v[sum].push_back(i);
    len[sum]++;
    if(vis[sum]==0)
    {
        a[j]=sum;
        j++;
        vis[sum]=1;
    }

}
ans=1;
for(k=1;k<j;k++)
{

    for(l=1;l<j;l++)
    {
        if(l==k)
        {
            sum=len[a[l]];
            if(sum>ans)
                ans=sum;

        }
        else
        {
            x=a[k];
            y=a[l];
            i=0;
            p=0;
             f=0;
              sum=1;
            while(1){

            //cout<<j<<" "<<l<<" "<<p<<" "<<k<<endl;


                while(v[y][p]<v[x][i])
                {
                    p++;
                    if(p==len[y])
                    {
                        f=1;
                        break;
                    }
                }
                if(f==1)
                   break;

                sum++;
                while(v[x][i]<v[y][p])
                {
                    i++;
                    if(i==len[x])
                    {
                        f=1;
                        break;
                    }
                }
                 if(f==1)
                   break;

                sum++;
            }
            if(sum>ans)
                ans=sum;

        }
    }
}



cout<<ans;

}
