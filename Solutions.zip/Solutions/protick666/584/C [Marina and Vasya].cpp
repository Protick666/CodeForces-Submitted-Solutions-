#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

char s1[1000000];
char s2[1000000];
char t[1000000];
vector <ll > eq;
vector <ll > dif;
ll vis[1000000];

char check ( char a, char b)
{
    char c='a';

    while(1)
    {
        if(c!=a && c!=b)
            return c;
        c++;


    }


}
int main()
{
   ll n,i,j,k,l,sum,ans,z,x,y,w1,w2,d1,d2,e,d;
   cin>>n>>k;
   e=0;
   d=0;

   scanf("%s",s1);
   scanf("%s",s2);

   for(i=0;i<n;i++)
   {
       if(s1[i]==s2[i])
       {
           e++;
           eq.push_back(i);

       }

       else
       {
           d++;
           dif.push_back(i);

       }


   }
   z=d%2;

   if(k>n || k<d/2+z )
   {
       cout<<"-1";
       exit(0);
   }

   z=n-k;

   for(i=0;i<e;i++)
   {
       if(z==0)
        break;
      t[eq[i]] =s1[eq[i]];
      vis[eq[i]]=1;
      z--;
      if(z==0)
        break;

   }

   if(z!=0)
   {
       i=0;
       j=d-1;

       while(z!=0)
       {
           t[dif[i]]=s1[dif[i]];
           t[dif[j]]=s2[dif[j]];
           vis[dif[j]]=1;
           vis[dif[i]]=1;
           i++;
           j--;
           z--;



       }


   }

   for(i=0;i<n;i++)
   {
       if(vis[i]==0)
       {
           t[i]=check(s1[i],s2[i]);
       }


   }

  printf("%s",t);




}
