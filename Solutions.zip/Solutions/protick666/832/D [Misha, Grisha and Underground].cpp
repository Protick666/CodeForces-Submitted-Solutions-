#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007

list<ll> li[100002];
vector<ll> v[100002];
ll dp[100002][50];
ll lev[100002];
ll dfs(ll start,ll par,ll le)
{

    lev[start]=le;
    list<ll>:: iterator it;
    for(it=li[start].begin(); it!=li[start].end(); it++)
    {
        if(*it!=par)
        {
            dp[*it][0]=start;
            lev[*it]=le+1;
            dfs(*it,start,le+1);
        }
    }
}


ll binary_rais(ll a,ll b)// return lca of a,b
{

    //  always we conseider that lev a> lev b so swap else
    if(lev[a]<lev[b]) swap(a,b);

    ll lg;

    // maximum jump that can be alloweable to make both a and
    // b at same level  will be the depth of the node a
    for(lg=1; (1<<lg)<=lev[a]; lg++);

    //
    lg--;

    // this will make both at same level
    //  we can write any number as the power of 2
    //  so by binary raise we can reach to any node
    for(ll i=lg; i>=0; i--)
    {
        if(lev[a]-(1<<i)>=lev[b])
        {
            a=dp[a][i];//   moving a upward
        }
    }

    //  now a and b are at same level


    //now we always try to  to shift a and be at a poll just below the lca
    //  but if both a and b are in the same line than while shifing leven we reach
    //  both a and become same

    if(a==b) return a;

    else
    {
        for(ll i=lg; i>=0; i--)
        {
            if(dp[a][i]!=-1 && dp[a][i]!=dp[b][i])//  moving botha and b up
            {
                a=dp[a][i];
                b=dp[b][i];
            }
        }
        //  since we atmax shift a and b
        //  just below there lca
        //  lca will be the parent of a or parent of b

        return dp[a][0];
    }
}

ll dist(ll a,ll b)
{
    ll x=binary_rais(a,b);
    return abs(lev[x]-lev[b])+abs(lev[x]-lev[a])+1;
}



ll ck(ll s1,ll s2,ll d)
{
    //cout<<"ck"<<endl;
    ll p=(dist(s1,d)+dist(s2,d)-dist(s2,s1)+1)/2;
    return p;

}


int main()
{

    ll m,n;
    ll q;
    cin>>n>>q;
    m=n-1;

    for(ll i=2; i<=n; i++)
    {
        ll x;
        in(x);
        ll a,b;
        a=i;
        b=x;
        li[a].push_back(b);
        li[b].push_back(a);
        v[a].pb(b);
        v[b].pb(a);
    }

    memset(dp,-1,sizeof dp);
    //cout<<dp[1][200];
// we are consedering 1 as the root of all nodes
// so its parent is non so its pow(2,0) the parent is 0;

    dp[1][0]=0;
    dfs(1,-1,1);

    ll max_h=30;//  or lon(n)
    //  maximum height
    for(ll i=1; i<=max_h; i++)
    {
        for(ll j=1; j<=n; j++)
        {
            if(dp[j][i-1]!=-1)
                dp[j][i]=dp[dp[j][i-1]][i-1];//
        }
    }


    //cin>>q;
    while(q--)
    {
        ll a,b,c,x;
        in2(a,b);
        in(c);
        //cout<<"yo"<<endl;
        ll y,u,i;
        y=ck(a,b,c);
        u=ck(a,c,b);
        i=ck(b,c,a);
        x=max3(y,u,i);
        //cout<<"yo"<<endl;
        printf("%I64d\n",x);

    }
}

