#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

vector<string> v;
map<string,ll> m;
int main() {

ll i,j,k,l,n,f,e,store,sum,b,r,c,d,h;
cin>>n;
string s;
char ch[100];
for(i=1;i<=n;i++)
{
    scanf("%s",ch);
    s=ch;
    v.push_back(s);


}
for(i=n-1;i>=0;i--)
{
    s=v[i];
    if(m[s]==1)
        continue;
    cout<<s<<endl;
    m[s]=1;

}


}
