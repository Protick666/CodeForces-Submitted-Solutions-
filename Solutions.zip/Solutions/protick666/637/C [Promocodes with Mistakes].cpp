#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

#define ll long long int

string s[1001];
ll check(ll a, ll b)
{
    ll i,j,sum;
    sum=0;

    for(i=0;i<6;i++)
    {
        if(s[a][i]!=s[b][i])
            sum++;
    }
   return sum;
}


main()
{
    ll i,j,k,l,n,r,t,q,b,x,y,c,p,ans,sum,z;
    cin>>n;

    ans=6;

    for(i=1;i<=n;i++)
        cin>>s[i];

    for(i=1;i<=n;i++)
    {
        for(j=i+1;j<=n;j++)
        {
            if(i==j)
                continue;

            l=check(i,j);
            l=l/2+(l%2);
            l--;
            if(l<ans)
                ans=l;
        }
    }
cout<<ans;
}
