#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

ll a[1000000];
int main() {







    ll i,j,k,l,n,m,f,e,store,sum,p,b,r,c,q,d,h,ans;
   cin>>n;
   for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);
   sum=0;
   for(i=1;i<=n;i++)
    sum+=a[i];
   ans=0;
   for(i=1;i<=n;i++)
   {
       p=sum-a[i];
       if(p<=a[i])
       {
           r=a[i]-p+1;
           if(r>ans)
            ans=r;
       }

   }
   cout<<ans;

}
