#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int
map <string,ll> m;
ll a[1000000];
ll ok[100000];
ll ok2[100000];
ll ok3[100000];
vector <string> v;
int main() {

ll i,j,k,l,n,f,e,store,sum,b,r,c,d,h,ans;
string s,t,q;
sum=0;
char ch[1000000];
char *z;
scanf("%s",ch);
s=ch;
l=s.length();


for(i=l-1;;i--)
   {
       if(i<=4)
        break;

    for(k=2;k<=3;k++)
    {
        if(i+k-1>=l)
            break;
        else if(i+k==l)
        {
            sum++;
                t=s.substr(i,k);
                v.push_back(t);
                ok[i]=1;
                if(k==2)
                    ok2[i]=1;
                else
                    ok3[i]=1;

        }
        else if(l-1-(i+k-1)<k)
        {
            if(ok[i+k]==1)
            {
                sum++;
                t=s.substr(i,k);
                v.push_back(t);
                ok[i]=1;
                if(k==2)
                    ok2[i]=1;
                else
                    ok3[i]=1;
            }

        }
        else
        {
            t=s.substr(i,k);
            q=s.substr(i+k,k);
            if(t!=q)
            {
                if(ok[i+k]==1)
                {
                    sum++;
                  t=s.substr(i,k);
                   v.push_back(t);
                  ok[i]=1;
                   if(k==2)
                    ok2[i]=1;
                else
                    ok3[i]=1;

                }

            }
            else
            {
                if(k==2)
                {
                    if(ok3[i+2]==1)
                    {
                        sum++;
                  t=s.substr(i,k);
                   v.push_back(t);
                  ok[i]=1;
                   if(k==2)
                    ok2[i]=1;
                  else
                    ok3[i]=1;

                    }

                }


                else
                {
                    if(ok2[i+3]==1)
                    {
                        sum++;
                  t=s.substr(i,k);
                   v.push_back(t);
                  ok[i]=1;
                   if(k==2)
                    ok2[i]=1;
                else
                    ok3[i]=1;

                    }

                }


            }


        }


    }

    }



ans=0;
sort(v.begin(),v.end());
for(i=0;i<sum;i++)
{
    if((i!=(sum-1)) && (v[i]==v[i+1]))
        continue;
   ans++;


}
cout<<ans<<endl;
for(i=0;i<sum;i++)
{
    if((i!=(sum-1)) && (v[i]==v[i+1]))
        continue;
   cout<<v[i]<<endl;


}

}
