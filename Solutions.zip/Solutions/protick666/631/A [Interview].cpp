#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;











main()
{

long long int i,j,k,l,n,s,store,sum,h,a,b;

cin>>n;
a=0;
for(i=1;i<=n;i++)
{
    scanf("%I64d",&store);
    a=a | store;


}
b=0;

for(i=1;i<=n;i++)
{
    scanf("%I64d",&store);
    b=b | store;


}

cout<<a+b;

}