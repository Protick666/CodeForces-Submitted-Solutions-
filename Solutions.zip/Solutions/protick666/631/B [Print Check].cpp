#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;


map <long long int,long long int> row,col,rown,coln;








main()
{

 long long int i,j,l,n,s,r,c,k,store,sum,h,f,a,b;
cin>>r>>c>>k;

for(i=1;i<=k;i++)
{
    cin>>f>>n>>s;

    if(f==1)
    {
        row[n]=s;
        rown[n]=i;


    }

    else if(f==2)
    {
        col[n]=s;
        coln[n]=i;


    }


}

for(i=1;i<=r;i++)
{
    for(j=1;j<=c;j++)
    {
        if(row[i]==col[j])
            printf("%I64d ",col[j]);
        else
        {
            if(rown[i]>coln[j])
                printf("%I64d ",row[i]);
            else
                printf("%I64d ",col[j]);


        }



    }

    printf("\n");


}



}
