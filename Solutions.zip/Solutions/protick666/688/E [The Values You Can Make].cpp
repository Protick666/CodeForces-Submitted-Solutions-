#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define co continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity


ll dp[2][501][501];

//vector <ll> v[5004];
ll cost[501];

int main()
{
    ll n,m,i,j,k,l,x,sum,ans,t,s;

    cin>>n>>k;

    for(i=1; i<=n; i++)
        cin>>cost[i];
    s=0;
    t=1;

    for(i=1; i<=n; i++)
    {
        if(s==1)
        {
            t=1;
            s=0;
        }
        else
        {
            t=0;
            s=1;
        }
        for(j=0;j<=k;j++)
          for(l=0;l<=k;l++)
            dp[t][j][l]=0;

        for(j=1;j<=k;j++)
        {

            if(cost[i]==j)
            {
                dp[t][j][j]=1;
            }
            else if(cost[i]<j)
            {
                for(l=1; l<=k; l++)
                {
                    if(dp[s][j-cost[i]][l]==1)
                    {
                        dp[t][j][cost[i]]=1;
                         dp[t][j][l]=1;
                        if(l+cost[i]<=k)
                             dp[t][j][l+cost[i]]=1;


                    }
                }
            }

            for(l=1; l<=k; l++)
            {
                if(dp[s][j][l]==1)
                    dp[t][j][l]=1;
            }

        }
    }

    ans=0;
   for(l=1; l<=k; l++)
    {
        if(dp[t][k][l]==1)
            ans++;

    }
    cout<<ans+1<<endl;
    cout<<0<<" ";
    for(l=1; l<=k; l++)
    {
        if(dp[t][k][l]==1)
            cout<<l<<" ";

    }



}
