#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll dp[26];
vector <char > v;


int main() {
ll i,j,n,sum,ans,store,p,k,f,l,w,x,y,a,b,q;
k=0;
char ch[1000000];
char c,zz;
scanf("%s",ch);
string s;
s=ch;
l=s.length();
for(i=0;i<l;i++)
{
    p=s[i]-'a';
    dp[p]++;

}
p=0;
for(i=0;i<26;i++)
{
    if((dp[i]%2)==1)
        p++;
}
f=1;

if((l%2)==0)
{
    p=p/2;
    for(i=0;i<26;i++)
    {
        q=dp[i]/2;
        c=i+'a';
        for(j=1;j<=q;j++)
        {
            printf("%c",c);
            v.push_back(c);

        }
        if((dp[i]%2)==1 && f<=p)
        {
            printf("%c",c);
            v.push_back(c);
            f++;

        }
    }
}

else
{
    p=p/2+1;
    for(i=0;i<26;i++)
    {
        q=dp[i]/2;
        c=i+'a';
        for(j=1;j<=q;j++)
        {
            printf("%c",c);
            v.push_back(c);

        }
        if((dp[i]%2)==1 && f<p)
        {
            printf("%c",c);
            v.push_back(c);
            f++;

        }
         else if((dp[i]%2)==1 && f==p)
        {
            zz=c;

            f++;

        }
    }
}
if((l%2)==1)
    cout<<zz;

for(i=l/2-1;i>=0;i--)
{
    c=v[i];
    printf("%c",c);
}

}
