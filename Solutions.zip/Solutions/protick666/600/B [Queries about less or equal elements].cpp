#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

map <long long int,long long int> mama;


main()
{

long long int s,n,i,j,l,p,q,k,z,d,r,w,x,flag,m,sum,e;

cin>>n>>m;
long long int a[n];
long long int b[m];
long long int ans[m];
for(i=0;i<n;i++)
    scanf("%I64d",&a[i]);

for(i=0;i<m;i++)
    {scanf("%I64d",&b[i]);
    ans[i]=b[i];

    }
sort(a,a+n);
sort(b,b+m);
i=0;
j=0;

for(j=0;j<m;j++)
{
    if(i>=n)
    {mama[b[j]]=n;
    continue;

    }

    while(a[i]<=b[j])
    {i++;
    if(i>=n)
    {
        mama[b[j]]=n;
        break;
    }
    }
     mama[b[j]]=i;

    }

for(i=0;i<m;i++)
    printf("%I64d ",mama[ans[i]]);



}