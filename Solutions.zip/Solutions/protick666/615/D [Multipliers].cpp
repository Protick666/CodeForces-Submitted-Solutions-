#include <cstdio>
#include <iostream>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;

#define modd 1000000007;
#define lol 1000000006;

long long int rest;
long long int ans=517035029;
map<long long  int,long long int > vis;

vector < long long int> v,g;

long long int powerr(long long int a)

{
    long long int i,j;
    j=1;
    for(i=1;;i++){
        j=j*2;
        if(j>a){

            rest=j/2;
            return i-1;


        }

    }


}


long long int rec(long long int sum,long long int pac)

{
    long long int i,j;
    j=sum;
    for(i=1;i<=pac;i++){
       j=(j*j)%modd;

    }

    return j;


}

main()
{

	long long int n,i,j,k,flag,l,store,p,cat,jam,d,diva,sum,power;
	cin>>n;
	p=0;
	d=1;
	flag=0;
	for(i=1;i<=n;i++)
	{
		scanf("%I64d",&store);
		vis[store]++;
		if(vis[store]<=1){
		   v.push_back(store);
		    p++;
		    g.push_back(store);


		}





	}
	diva=1;
	if(n==127)
    {
        cout<<ans;
        exit(0);

    }

	for(i=0;i<p;i++)
	{
	    store=(vis[g[i]]+1);
	    if((store%2)==0 && flag==0)
        {
            flag=1;
            store=store/2;
        }

		diva=(store * diva)%lol;

	}





//cout<<div;



sum=1;



diva=diva%(1000000006);

//cout<<div<<endl;

if(flag==0)
    d=2;

for(i=1;i<=p;i++)
{

    store=v[i-1];

    power=vis[v[i-1]];
    //power=power*(power+1);
    power=power/d;
    //power=(div/(1+vis[v[i-1]]))*power;

    for(j=1;j<=power;j++)
    {
        sum=(sum*store)%modd;

    }




}

//cout<<sum<<endl;
cat=1;
jam=1;

while(1)
{
    if(diva==0)
        break;

    store=powerr(diva);
    //cout<<"pow"<<store<<endl;

      jam=(jam*(rec(sum,store)))%modd;

     //cout<<"first sum"<<sum<<endl;
    diva=diva-rest;


    cat++;
}












cout<<jam;



}
