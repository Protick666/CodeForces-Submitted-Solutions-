#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
vector <ll> vf[30];
vector <ll> vr[30];
queue <ll> q;
queue <ll> level;
ll vot[10000];
ll len=1;
int main() {
ll i,j,n,m,store,sum,v,k,ans,l,a,b,c,d,p,z;
string s,t,sr;
cin>>s>>t;

char ch;
sr=s;
reverse(sr.begin(),sr.end());

l=s.length();
for(i=0;i<l;i++)
{
    ch=s[i];
    a=ch-'a';
    vf[a].push_back(i);

       ch=sr[i];
    a=ch-'a';
    vr[a].push_back(i);

}
p=t.length();
i=0;
sum=0;
while(1){
a=t[i]-'a';
if(vf[a].size()==0)
{
    cout<<"-1";
    exit(0);
}
ans=0;
for(k=0;k<vf[a].size();k++)
{q.push(vf[a][k]);


 level.push(1);

 }

 while(!q.empty())
 {
     a=q.front();
     b=level.front();
     if(b>ans)
     {
         ans=b;
         j=a;
     }



     q.pop();
     level.pop();
     if(a!=(l-1))
     {
         if((s[a+1]==t[i+b]) && ((i+b)!=p))
         {
             q.push(a+1);
             level.push(b+1);

         }
     }


 }







 a=t[i]-'a';
z=0;

for(k=0;k<vr[a].size();k++)
{q.push(vr[a][k]);


 level.push(1);

 }

 while(!q.empty())
 {
     a=q.front();
     b=level.front();
     if(b>ans)
     {
         ans=b;
         j=a;
         z=1;
     }



     q.pop();
     level.pop();
     if(a!=l-1)
     {
         if(sr[a+1]==t[i+b] && (i+b)!=p)
         {
             q.push(a+1);
             level.push(b+1);

         }
     }


 }

 if(z==0)
 {
     b=j;
     a=b-ans+1;
     b++;
     a++;
     vot[len]=a;
     vot[len+1]=b;
     len=len+2;

 }

  else
 {
     b=j;
     a=b-ans+1;
     b++;
     a++;

     a=l-a+1;
     b=l-b+1;
     vot[len]=a;
     vot[len+1]=b;
     len=len+2;

 }
 i=i+ans;
 if(i>=p)
    break;







}
cout<<len/2<<endl;

for(i=1;i<len;i=i+2)
{
    cout<<vot[i]<<" "<<vot[i+1]<<endl;

}









}
