#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity

map <ll, map<ll,vector <ll > > > m;
map <ll, map<ll,vector <ll > > > ind;

ll a[1000001];
ll b[1000001];
ll c[1000001];

int main()
{
    ll n,i,j,sum,ans,gu,u,r,q,e,x,y,z,t,f,p,k,l,val,se,w,g,s;
    cin>>n;

    s=-1;
    e=-1;
    gu=-1;
    for(i=1; i<=n; i++)
    {
        scanf("%I64d%I64d%I64d",&x,&y,&z);
        a[i]=x;
        b[i]=y;
        c[i]=z;
            //cout<<"po :"<<m[8][10].size()<<endl;
            //if(i==n)
                //cout<<m[8][10][0]<<" "<<m[8][10][1]<<endl;

            //if(i==n)
                //cout<<ind[8][10][0]<<" "<<ind[8][10][1]<<endl;

        for(w=1; w<=3; w++)
        {
            if(w==1)
            {
                p=min(x,y);
               q=max(x,y);
               se=z;

            }
            else if(w==2)
            {
                p=min(x,z);
               q=max(x,z);
               se=y;

            }
            else
                {
                p=min(y,z);
               q=max(y,z);
               se=x;

               }



            if(m[p][q].size()==0)
            {
                //cout<<1<<endl;
                m[p][q].pb(se);
                ind[p][q].pb(i);
                               // cout<<1<<endl;

            }
            else if(m[p][q].size()==1)
            {
                            //cout<<2<<endl;

                u=ind[p][q][0];
                if(u==i)
                    continue;
                //cout<<21<<endl;

                m[p][q].pb(se);
                ind[p][q].pb(i);
                //cout<<22<<endl;

                u=m[p][q][0]+m[p][q][1];
                r=min3(u,p,q);

                if(r>gu)
                {

                    gu=r;
                    s=ind[p][q][0];
                    e=ind[p][q][1];

                }

                                            //cout<<2<<endl;

            }
            else
            {
                            //cout<<3<<endl;


                g=ind[p][q][0];
                l=ind[p][q][1];
                if(g==i || l==i)
                    continue;


                g=m[p][q][0];
                l=m[p][q][1];
                if(g<l)
                {
                    val=g;
                    k=0;

                }
                else
                {
                    val=l;
                    k=1;
                }
                //cout<<val<<" "<<k;

               if(val<se)
                {

                    m[p][q][k]=se;
                    ind[p][q][k]=i;
                    u=m[p][q][0]+m[p][q][1];
                    r=min3(u,p,q);

                    if(r>gu)
                    {

                        gu=r;
                        s=ind[p][q][0];
                        e=ind[p][q][1];

                    }
                }

                                            //cout<<3<<endl;


            }




        }

    }
            //cout<<"po "<<m[8][10].size()<<endl;

    //cout<<"alright";

    ans=-1;
    for(i=1; i<=n; i++)
    {
        sum=min3(a[i],b[i],c[i]);
        if(sum>ans)
        {
            ans=sum;
            t=i;
        }
    }

    if(ans>gu)
    {
        cout<<1<<endl;
        cout<<t;
    }
    else
    {
        cout<<2<<endl;
        cout<<s<<" "<<e;
    }





}
