#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity

ll x[1000002];
ll y[1000002];
int main()
{
    ll n,i,j,m,g,ans,z,p,q,c,sum,a,b;
    cin>>n;
    for(i=1;i<=n;i++)
      cin>>x[i]>>y[i];

    a=0;
    b=0;
    for(i=1;i<=n;i++)
    {
        a+=x[i];
        b+=y[i];

    }
    ans=abs(a-b);
    z=0;
    for(i=1;i<=n;i++)
    {
        p=a-x[i];
        q=b-y[i];
        m=p+y[i];
        c=q+x[i];
        sum=abs(m-c);
        if(sum>ans)
        {
            z=i;
            ans=sum;
        }
    }

    cout<<z;





}
