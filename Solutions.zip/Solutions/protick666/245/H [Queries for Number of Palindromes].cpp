#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

pair <int,int> p;

int fin[5001][5001];
int pal[5001][5001];

string s;







main()
{

    int i,j,k,l,m,n,o,sum,q,a,b,store;
    sum=0;

    cin>>s;
    cin>>q;
    n=s.length();
    //cout<<n<<endl;
    for(i=0;i<n;i++)
    {
        pal[i][i]=1;
        fin[i][i]=1;

    }



for(i=2;i<=n;i++)
{

    for(j=0;j<=n-i;j++)
    {
        a=j;
        b=j+i-1;
        if(s[a]==s[b])
        {
            if(i==2)
                pal[a][b]=1;
            else
                pal[a][b]=pal[a+1][b-1];

        }
        fin[a][b]=pal[a][b]+fin[a+1][b]+fin[a][b-1]-fin[a+1][b-1];
    }


}

for(i=1;i<=q;i++)
{


    scanf("%d%d",&a,&b);
    printf("%d\n",fin[a-1][b-1]);
}


}
