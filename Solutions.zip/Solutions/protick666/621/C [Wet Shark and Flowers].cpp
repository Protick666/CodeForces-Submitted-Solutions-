#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;


long long int l[100001];
long long int s[100001];
long long int un[100001];
long long int r[100001];
long long int u[100001];


main()
{
  long long int i,j,k,n,p,x,y,a,b;
  double sum;
  sum=0;
  cin>>n>>p;
  for(i=1;i<=n;i++)
  {
      scanf("%I64d%I64d",&x,&y);
      //l[i]=x;
      //r[i]=y;
      u[i]=y/p-x/p;
      if(x%p==0)
        u[i]++;
      un[i]=y-x+1-u[i];
      s[i]=y-x+1;


  }
  for(i=1;i<=n;i++)
  {
      b=i-1;
      a=i+1;
      if(i==1)
        b=n;
      if(i==n)
        a=1;

          sum=sum+2*u[i]/(float)s[i];

          sum=sum+(u[b]/(float)s[b])*(un[i]/(float)s[i]);
          sum=sum+(u[a]/(float)s[a])*(un[i]/(float)s[i])*(un[b]/(float)s[b]);
           sum=sum+(u[b]/(float)s[b])*(un[i]/(float)s[i])*(u[a]/(float)s[a]);





  }


  //for(i=1;i<=n;i++)
    //cout<<u[i]<<" "<<un[i]<<" "<<s[i]<<endl;
printf("%0.7lf",sum*1000);



}
