#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector< pair<ll,ll> > ans;
list<ll> li[100002];
vector<ll> v[100002];
ll dp[100002][50];
ll lev[100002];
ll dest[100002];
ll source[100002];
map<ll, map<ll,ll> > mom;
ll vis[100002];
ll dfs2(ll a)
{
    vis[a]=1;
    ll i,j,t,sum;
    sum=0;
    for(i=0;i<v[a].size();i++)
    {
        t=v[a][i];
        if(vis[t]==0)
        {
            j=dfs2(t);
            sum+=j;
            mom[t][a]+=j;
            mom[a][t]+=j;
        }
    }

    sum+=source[a]-dest[a];
    return sum;
}




ll dfs(ll start,ll par,ll le)
{

    lev[start]=le;
    list<ll>:: iterator it;
    for(it=li[start].begin(); it!=li[start].end(); it++)
    {
        if(*it!=par)
        {
            dp[*it][0]=start;
            lev[*it]=le+1;
            dfs(*it,start,le+1);
        }
    }
}


ll binary_rais(ll a,ll b)// return lca of a,b
{

    //  always we conseider that lev a> lev b so swap else
    if(lev[a]<lev[b]) swap(a,b);

    ll lg;

    /// maximum jump that can be alloweable to make both a and
    // b at same level  will be the depth of the node a
    for(lg=1; (1<<lg)<=lev[a]; lg++);

    //
    lg--;

    // this will make both at same level
    //  we can write any number as the power of 2
    //  so by binary raise we can reach to any node
    for(ll i=lg; i>=0; i--)
    {
        if(lev[a]-(1<<i)>=lev[b])
        {
            a=dp[a][i];//   moving a upward
        }
    }

    //  now a and b are at same level


    //now we always try to  to shift a and be at a poll just below the lca
    //  but if both a and b are in the same line than while shifing leven we reach
    //  both a and become same

    if(a==b) return a;

    else
    {
        for(ll i=lg; i>=0; i--)
        {
            if(dp[a][i]!=-1 && dp[a][i]!=dp[b][i])//  moving botha and b up
            {
                a=dp[a][i];
                b=dp[b][i];
            }
        }
        //  since we atmax shift a and b
        //  just below there lca
        //  lca will be the parent of a or parent of b

        return dp[a][0];
    }
}


int main()
{

ll m,n,i,j;
    cin>>n;
    m=n-1;

    for(i=1; i<=m; i++)
    {
        ll a,b;
        cin>>a>>b;
        li[a].push_back(b);
        li[b].push_back(a);
        ans.pb(mp(a,b));
        v[a].pb(b);
        v[b].pb(a);
    }

    memset(dp,-1,sizeof dp);
    //cout<<dp[1][200];
// we are consedering 1 as the root of all nodes
// so its parent is non so its pow(2,0) the parent is 0;

    dp[1][0]=0;
    dfs(1,-1,1);

    ll max_h=30;//  or lon(n)
    //  maximum height
    for(i=1; i<=max_h; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(dp[j][i-1]!=-1)
                dp[j][i]=dp[dp[j][i-1]][i-1];//
        }
    }

    ll q,t;
    cin>>q;
    while(q--)
    {
        ll a,b;
        cin>>a>>b;
        if(lev[a]>lev[b])
          swap(a,b);
        t=binary_rais(a,b);
        if(t==a)
        {
            dest[a]++;
            source[b]++;
        }
        else
        {
            dest[t]+=2;
            source[a]++;
            source[b]++;
        }
    }

    dfs2(1);

    for(i=0;i<ans.size();i++)
    {
        ll a,b;
        a=ans[i].first;
        b=ans[i].second;
        cout<<mom[a][b]<<endl;
    }
}

