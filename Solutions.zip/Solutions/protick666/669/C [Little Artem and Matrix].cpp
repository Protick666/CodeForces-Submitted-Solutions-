#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int
ll flag[100000];
ll row[100000];
ll col[100000];
ll x[100000];
ll y[100000];
ll a[101][101];
ll val[100000];

int main() {

    ll i,j,k,l,n,m,f,store,sum,p,b,r,c,q;
    cin>>r>>c>>q;
    for(i=1;i<=q;i++)
    {
        scanf("%I64d",&f);
        flag[i]=f;
        if(f==1)
        {
            scanf("%I64d",&m);
            row[i]=m;
        }
         else if(f==2)
        {
            scanf("%I64d",&m);
            col[i]=m;
        }
        else
        {
            scanf("%I64d%I64d%I64d",&m,&n,&sum);
            x[i]=m;
            y[i]=n;
            val[i]=sum;
        }
    }

    for(i=q;i>=1;i--)
    {
        f=flag[i];
        if(f==1)
        {
            m=row[i];
            store=a[m][c];
            for(j=c;j>1;j--)
                a[m][j]=a[m][j-1];
            a[m][1]=store;

        }

         else if(f==2)
        {
            n=col[i];
            store=a[r][n];
            for(j=r;j>1;j--)
                a[j][n]=a[j-1][n];
            a[1][n]=store;

        }
        else
        {
            m=x[i];
            n=y[i];
            a[m][n]=val[i];

        }



    }

    for(i=1;i<=r;i++)
    {
        for(j=1;j<=c;j++)
            printf("%I64d ",a[i][j]);
        printf("\n");
    }




}
