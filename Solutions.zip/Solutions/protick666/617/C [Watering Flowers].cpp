#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
vector < pair<ll,ll> > v;
ll x[10000];
ll y[10000];
ll vis[10000];
main()
{
   ll x1,y1,x2,y2,i,sum,j,a,b,ans,n,t;
    cin>>n>>x1>>y1>>x2>>y2;
   pair<ll,ll> p;
   t=0;

   for(i=1;i<=n;i++)
   {
       cin>>a>>b;
       x[i]=(abs(a-x1))*(abs(a-x1))+(abs(b-y1))*(abs(b-y1));
      y[i]=(abs(a-x2))*(abs(a-x2))+(abs(b-y2))*(abs(b-y2));
      t=max(t,y[i]);
   }


   for(i=1;i<=n;i++)
   {
       p=mp(x[i],i);
       v.pb(p);
   }

   sort(v.begin(),v.end());
   sum=maxx;
   for(i=0;i<v.size();i++)
   {
       a=v[i].se;
       b=v[i].fi;
       vis[a]=1;
       ans=0;
       for(j=1;j<=n;j++)
       {
           if(vis[j]==1)
             continue;
           ans=max(ans,y[j]);
       }

       sum=min(sum,ans+b);
   }

sum=min(sum,t);
cout<<sum;

}
