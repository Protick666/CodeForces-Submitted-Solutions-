#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 1000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll x[101];
ll y[101];
ll dp[101][5];
ll n,m;
void ck()
{
    //cout<<n<<" "<<m<<endl;

    for(ll i=1;i<=n;i++)
    {
        char c;
        if(x[i]==1)
            c='A';
        else if(x[i]==2)
            c='C';
        else
            c='D';
        cout<<c;
    }
    cout<<endl;

    for(ll i=1;i<=m;i++)
    {
        //cout<<"tuit";
        char c;
        if(y[i]==1)
            c='A';
        else if(y[i]==2)
            c='C';
        else
            c='D';
        cout<<c;
    }
    ex;

}
int main()
{
    //cout<<abs(-3.1);

    ll i,j,k,sum,ans,h,t,x1,x2,y1,y2,xn,yn,l;
    cin>>k>>t>>n>>m;
    //cout<<n<<endl;
    //i occurences in s1
    //1 a 2 c 3 other
    fr(i,0,n/2+1)
    {
        fr(j,0,m/2+1)
        {
            fr(x1,1,3)
            {
                fr(x2,1,3)
                {
                    fr(y1,1,3)
                    {
                        fr(y2,1,3)
                        {
                            //cout<<n<<endl;
                            x[1]=x1;
                            x[n]=x2;
                            sum=0;
                            fr(l,2,n-1)
                            {
                               if(sum>=i)
                                    x[l]=3;
                               else if(x[l-1]==1)
                               {
                                   x[l]=2;
                                   sum++;
                               }
                               else
                                x[l]=1;
                            }

                            y[1]=y1;
                            y[m]=y2;
                            sum=0;
                            fr(l,2,m-1)
                            {
                               if(sum>=j)
                                    y[l]=3;
                               else if(y[l-1]==1)
                               {
                                   y[l]=2;
                                   sum++;
                               }
                               else
                                y[l]=1;
                            }
                             //i occurences in s1
                             //1 a 2 c 3 other
                             //n len of s1
                             xn=0;
                             fr(l,2,n)
                             {
                                 if(x[l]==2 && x[l-1]==1)
                                    xn++;
                             }

                             yn=0;
                             fr(l,2,m)
                             {
                                 if(y[l]==2 && y[l-1]==1)
                                    yn++;
                             }
                             dp[1][0]=xn;
                             dp[1][1]=x1;
                             dp[1][2]=x2;
                             if(n==1)
                                dp[1][1]=x2;

                             dp[2][0]=yn;
                             dp[2][1]=y1;
                             dp[2][2]=y2;
                             if(m==1)
                                dp[2][1]=y2;
                            fr(l,3,k)
                            {
                                dp[l][0]=dp[l-1][0]+dp[l-2][0]+((dp[l-2][2]==1 && dp[l-1][1]==2)?1:0);
                                dp[l][1]=dp[l-2][1];
                                dp[l][2]=dp[l-1][2];
                            }
                            //cout<<n<<endl;
                            if(dp[k][0]==t)
                                ck();


                        }
                    }
                }
            }
        }
    }

    cout<<"Happy new year!";




}
