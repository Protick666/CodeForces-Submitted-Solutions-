#include <bits/stdc++.h>

#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%lld",&x);
#define in2(x,y) scanf("%lld%lld",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 100000007
#define PI 3.14159265

ll fits(double fp,double p)
{
    double thresh = .0000001;

    if(abs(fp * (p-fp) - p) <= thresh)
        return 0;
    if(fp * (p-fp)  < p)
        return -1;
    else return 1;

}
pair<double,double>  ck(double p)
{
    if(p == 0) return make_pair(0,0);

    double m = p/2;

    double i = 0; double j = m; ll t = 0;

    while(true)
    {
       // cout<<i<< " "<<j<<endl;
        double fp = (i+j)/2;  ll flag = fits(fp,p) ;
        if(flag == 0) return make_pair(fp, p-fp);
        else if(flag == -1) i = fp;
        else j = fp;
        t++;
        if(t==1000) return make_pair(-1,-1);

    }
}

int main()
{
    ll n,t,p;

   cin>>t;

   while(t--)
   {
       cin>>p; pair<double,double> par = ck(p);

       std::cout << std::fixed;
    std::cout << std::setprecision(10);
   // std::cout << d;
       if(par.first == -1)
        cout<<"N"<<endl;
       else
        cout<<"Y"<<" "<<par.first<<" "<<par.second<<endl;
   }
}
