#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>


using namespace std;
main()
{
    long long int i,j,k,mot,d,x,y,t,s,l,flag;
    cin>>t;
    for(i=1;i<=t;i++)

    {cin>>mot>>d>>x>>y;
    flag=0;
    l=x>y?x:y;
    s=l==x?y:x;

    //cout<<l<<" "<<s<<endl;

    if(s==0 && l==0)
    {
        if(d%3==0 && (mot-d)%3==0)
        {
            printf("yes\n");
            flag=1;
            //exit(0);
        }

        else {
            printf("no\n");
            flag=1;
            //exit(0);
        }


    }


    if(d>=x+y && (d-x-y)%3==0 && flag==0)
    {
        //cout<<"ok1";
        if((mot-d>=s+(l-s)*2) && ((((mot-d)-(s+(l-s)*2))%3)==0))
        {
            printf("yes\n");
            flag=1;
            //exit(0);
        }
    }
    //cout<<"alright";

     if(d>=2*s+l &&(d-2*s-l)%3==0 && flag==0)
    {
        //cout<<"in";
        //cout<<"ok2";
        if(mot-d>=s+(l)*2 && ((mot-d)-(s+(l)*2))%3==0)
        {
            printf("yes\n");
            flag=1;
            //exit(0);
        }
    }

     if(d>=2*l+s && (d-2*l-s)%3==0 && flag==0)
    {
        //cout<<"ok3";
        if(mot-d>=l+(s)*2 && ((mot-d)-(l+(s)*2))%3==0)
        {
            printf("yes\n");
            flag=1;
            //exit(0);
        }
    }

    if(d>=2*l-s && (d-2*l+s)%3==0 && flag==0)
    {
        //cout<<"ok3";
        if(mot-d>=l+s && ((mot-d)-(l+s))%3==0)
        {
            printf("yes\n");
            flag=1;
            //exit(0);
        }
    }
if(flag==0)
    printf("no\n");

    }

}
