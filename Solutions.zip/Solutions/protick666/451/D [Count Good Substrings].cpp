#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int

int main() {
    // your code goes here
   ll ea,oa,eb,ob,i,j,k,l,e,o,p;
   e=0;
   o=0;
   ea=0;
   oa=0;
   eb=0;
   ob=0;
   char ch[100001];

   char c;
   string s;

   scanf("%s",ch);
   s=ch;
   l=s.length();
   for(i=0;i<l;i++)
   {
       o++;
       p=i+1;


       if(s[i]=='a')
       {
           if(p%2==0)
           {
               o+=ea;
               e+=oa;
               ea++;

           }
           else
           {
               o+=oa;
               e+=ea;
               oa++;

           }



       }

       if(s[i]=='b')
       {

            if(p%2==0)
           {
               o+=eb;
               e+=ob;
               eb++;

           }
           else
           {
               o+=ob;
               e+=eb;
               ob++;

           }


       }



   }






 cout<<e<<" "<<o;



}
