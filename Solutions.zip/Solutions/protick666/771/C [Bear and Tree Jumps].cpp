#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<ll> v[1000000];
ll dp[1000000][6];
ll ans[1000000][6];
ll sum=0;
ll n,k;
ll ext=0;
ll vis[1000000];

ll dfs(ll a)
{
    vis[a]=1;
    ll i,j,s;
    s=0;
    fr(i,0,v[a].size()-1)
    {
        ll p=v[a][i];
        if(vis[p]==1)
            cont;
        s+=dfs(p);

    }
    s++;
    sum+=s*(n-s);
    return s;
}

void mk(ll a)
{
    vis[a]=1;
    ll i,j,s;

    fr(i,0,v[a].size()-1)
    {
        ll p=v[a][i];
        if(vis[p]==1)
            cont;
        mk(p);
        for(j=0; j<k; j++)
        {

            ans[a][j]+= dp[p][j];

        }
    }

}

void ck(ll a)
{
    vis[a]=1;
    ll i,j,s;
    //s=0;
    fr(i,0,v[a].size()-1)
    {

        ll p=v[a][i];

        if(vis[p]==1)
            {

                cont;
            }


        ck(p);

        for(j=0; j<k; j++)
        {

            ll t=dp[p][j];
            ll u=j+1;
            u=u%k;
            dp[a][u]+=t;

        }
        ll u=1%k;
        dp[a][u]++;


    }

    return;

}

void tk(ll a)
{
    vis[a]=1;
    ll i,j,s,x,y;

    fr(i,0,v[a].size()-1)
    {

        ll p=v[a][i];
        if(vis[p]==1)
            cont;
        tk(p);
        for(j=0; j<k; j++)
        {
            for(s=0; s<k; s++)
            {
                x=dp[p][s];
                y=ans[a][j]-dp[p][j];
                ll q=(s+j+2)%k;
                //cout<<a<<" "<<p<<endl;
                //cout<<j<<" "<<s<<endl;
                //cout<<y<<" "<<x<<" "<<q<<endl;
                //cout<<endl;

                if(q!=0)
                    q=k-q;
                ext+=q*x*y;

            }
        }
        for(j=0; j<k; j++)
            ans[a][j]-=dp[p][j];
    }

}


int main()
{
    ll i,j,p,x,y;
    cin>>n>>k;
    fr(i,1,n-1)
    {
        cin>>x>>y;
        v[x].pb(y);
        v[y].pb(x);

    }
    x=dfs(1);

    fr(i,0,n)
       vis[i]=0;

    ck(1);


    for(i=1;i<=n;i++)
    {

        for(j=0;j<k;j++)
        {
            if(j==0)
                  ext+=dp[i][j]*j;
            else
                ext+=dp[i][j]*(k-j);


        }
    }

    for(i=1;i<=n;i++)
    {

        dp[i][0]++;
    }

    fr(i,1,n)
      vis[i]=0;

    mk(1);


    fr(i,1,n)
    vis[i]=0;
    tk(1);




    cout<<(sum+ext)/k;

}


