#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define maxx 10000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
ll dp[2][501][501];
ll vis[1000];

int main()
{
    ll n,i,j,m,k,p,ans,l;
    cin>>n>>m>>k>>p;//k max fault,p mod
    for(i=1; i<=n; i++)
        cin>>vis[i];

    for(i=0; i<=k; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(vis[j]==i)
                dp[0][i][j]=1;

        }

    }


    for(i=0; i<=k; i++)
    {
        for(j=1; j<=n; j++)
        {

            dp[0][i][j]=(dp[0][i][j-1]+dp[0][i][j])%p;

        }

    }


    for(i=2; i<=m; i++)
    {
        for(j=0; j<=k; j++)
        {
            for(l=1; l<=n; l++)
            {
                if(vis[l]>j)
                    continue;
                else
                    dp[1][j][l]=dp[0][j-vis[l]][l];


            }
        }




       for(j=0; j<=k; j++)
        {
            for(l=1; l<=n; l++)
            {


                    dp[1][j][l]=(dp[1][j][l-1]+dp[1][j][l])%p;


            }
        }


         for(j=0; j<=k; j++)
        {
            for(l=1; l<=n; l++)
            {


                    dp[0][j][l]= dp[1][j][l];


            }
        }

          for(j=0; j<=k; j++)
        {
            for(l=1; l<=n; l++)
            {


                    dp[1][j][l]= 0;


            }
        }

    }


    ans=0;

    for(i=0;i<=k;i++)
        ans=(ans+dp[0][i][n])%p;

    cout<<ans;

}
