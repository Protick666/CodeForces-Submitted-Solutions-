#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007


ll a[1000000];


int main()
{
   ll n,i,j,x,y,sum,p,r,q,m,ans;
   cin>>n;

   for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);

   for(i=1;i<=n;i++)
    a[i]=a[i]+a[i-1];



   ans=0;

   for(i=1;i<=n-1;i++)
   {
       x=a[i];
       y=a[n]-a[i];
       if(x==y)
        ans++;

   }

cout<<ans;

}
