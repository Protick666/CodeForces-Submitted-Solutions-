#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//map <ll,map<ll,ll> >  m;
//map <ll,map<ll,ll> >  done;
//vector <ll>   yi[1000000002];
//vector <ll> v;
//map <ll,ll> xx;
//map<ll,ll> m;

ll i,j,k,l,sum,ans,x,y,p,n,q,m,t;

ll a[10000000];
void pro(ll i, ll j)
{
    ll k;
    for(k=1;k<=j;k++)
    {
        if(a[k]==-1)
            printf(".");
        else
            printf("%I64d",a[k]);
    }
}

void def(ll p)
{
    ll i,j,sum,ans;
    i=p;
    while(a[i]==9)
    {i--;
    if(i==0)
        break;
    }
    if(i==0)
    {
        cout<<"1";
        for(j=1;j<=p;j++)
        printf("0");


    }
    else{

        a[i]++;
        pro(1,i);
        for(j=1;j<=p-i;j++)
         printf("0");

    }

    exit(0);


}
main()
{



    cin>>n>>t;
char ch[1000000];
scanf("%s",ch);
//cout<<"aa";
string s;
s=ch;
l=s.length();

for(i=0;i<l;i++)
{
    if(s[i]=='.')
        {a[i+1]=-1;
        j=i+1;

        }
    else
        a[i+1]=s[i]-'0';
}

for(i=j+1;i<=l;i++)
{
    if(a[i]>=5)
        break;

}

if(i==l+1)
{
    cout<<s;
    exit(0);
}
k=i;
while(a[k]>=4)
{
    k--;
    if(k==j)
        break;
}
p=i-k;

//cout<<i<<" "<<k<<endl;
if(k==j)
{
    if(p<=t)
    {


    if(j==1)
        cout<<"1";
    else
    {
        if(a[j-1]==9)
            def(j-1);
        a[j-1]++;
        pro(1,j-1);

    }


        exit(0);
    }




}
 if(p>t)
    k=i-t;


    a[k]++;
    pro(1,k);







}



