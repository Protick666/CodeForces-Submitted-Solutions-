#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <list>
#include <stack>
#include <utility>
#include <ctime>
#include <string>
#include <map>
#include <queue>

#define num(c) (c-'a')
#define ok(c) ('a'+c)

using namespace std;

string nam;
double co[100002];
int vis[101];

main()
{
    map<double,double> mymapmin,mymapmax,visit;
    double x,y;
    long long int i,j,k,n,one,two,c,len,flag,m;
    flag=0;
    len=0;

    cin>>n;
    cin>>one>>two;
    for(m=1;m<=n;m++)
    {

        cin>>k>>c;
        x=k*one+c;
        y=k*two+c;
        co[len]=x;
        len++;
        if(visit[x]==0)
            {
                mymapmax[x]=y;
                mymapmin[x]=y;
                visit[x]=1;
            }
        else if(y>mymapmax[x])
            mymapmax[x]=y;
        else if(y<mymapmin[x])
            mymapmin[x]=y;



    }

    sort(co,co+len);

    for(i=1;i<len;i++)
    {
        if(co[i]==co[i-1])
            continue;
        if(mymapmin[co[i]]>=mymapmax[co[i-1]])
            continue;
        else{
            flag=1;
            break;
        }


    }

if(flag==0)
    cout<<"NO";
else
    cout<<"YES";



}