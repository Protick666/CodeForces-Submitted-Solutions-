#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <list>
#include <stack>
#include <utility>
#include <ctime>
#include <string>
#include <map>
#include <queue>

#define num(c) (c-'a')
#define ok(c) ('a'+c)

using namespace std;
vector<int> bap[26];
int alp[120][26];
string nam;
int len[101];
int vis[101];

main()
{


    long long int lent,t,i,j,k,m,h,tr,n,flag,sum,store;

   cin>>n;


    for(m=1;m<=n;m++)
    {   flag=0;
        cin>>nam;

        for(i=0;i<nam.length();i++)
        {
            if(alp[m][num(nam[i])]==0)
                flag++;
            alp[m][num(nam[i])]++;
            len[m]++;
            if(flag>2){
                vis[m]=1;
                break;
            }


        }

    }
     sum=0;
     store=0;
     for(i=0;i<26;i++)
     {
         for(j=i;j<26;j++)
         {  store=0;
             if(i==j)
             {
                 for(k=1;k<=n;k++)
                 {
                     if(vis[k]==1)
                        continue;
                     if(alp[k][i]==len[k])
                        store=store+len[k];


                 }
              if(store>sum)
                sum=store;


             }
             else
             {
                 for(k=1;k<=n;k++)
                 {
                     if(vis[k]==1)
                        continue;
                     if(alp[k][i]+alp[k][j]==len[k])
                        store=store+len[k];


                 }
              if(store>sum)
                sum=store;


             }




         }


     }



cout<<sum;

}
