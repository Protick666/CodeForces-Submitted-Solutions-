#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
double a[1000001];
ll f[1000001];
double dp[1000001];

int main()
{

    ll i,j,k,n;
    string s;
    double p;
    a[1]=1;
    for(i=2;i<=1000000;i++)
        a[i]=1/((double)(i));
    for(i=2;i<=1000000;i++)
        a[i]=a[i]+a[i-1];

    //for(i=2;i<=10;i++)
        //cout<<a[i]<<" ";
    cin>>s;
    n=s.length();
    for(i=0;i<n;i++)
    {
        if(s[i]=='A' || s[i]=='E' || s[i]=='I' || s[i]=='O' || s[i]=='U' || s[i]=='Y')
           f[i+1]=1;
        else
            f[i+1]=0;
    }



    dp[1]=a[n];
    for(i=2;i<=n;i++)
    {
        dp[i]=dp[i-1]-a[i-1]+ a[n-i+1];
    }

    double t=0;
    for(i=1;i<=n;i++)
    {
        if(f[i]==1)
            t+=dp[i];
    }

     std::cout << std::fixed;
    std::cout << std::setprecision(10);



      cout<<t;


}
