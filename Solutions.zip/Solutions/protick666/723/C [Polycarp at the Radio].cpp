#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 1000000007






ll a[10000];
ll vis[10000];

main()

{
ll i,j,k,l,n,h,x,y,r,p,ans,sum,m,t;

  cin>>n>>m;

  for(i=1;i<=n;i++)
  {
      cin>>x;
      a[i]=x;
      if(x<=m)
        vis[x]++;
  }

  t=0;
  p=n/m;
  for(i=1;i<=m;i++)

  {

      if(vis[i]<p)
      {
          j=1;
          while(vis[i]!=p)
          {
                //cout<<"gu";

              if(a[j]==i)
                {j++;
                    continue;}
              else if(a[j]<=m)
              {
                  if(vis[a[j]]>p)
                  {
                      t++;
                      vis[a[j]]--;
                      vis[i]++;
                      a[j]=i;

                  }
              }
              else
              {
                  t++;
                  vis[i]++;
                  a[j]=i;

              }
              j++;

          }

      }
  }

  cout<<p<<" "<<t<<endl;

  for(i=1;i<=n;i++)
    cout<<a[i]<<" ";


}
