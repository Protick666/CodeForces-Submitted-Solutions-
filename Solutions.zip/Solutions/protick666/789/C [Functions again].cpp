#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000009];

int main()
{

    ll i,j,k,n,sum,p,q,z,x,y,b,t;
    cin>>n;
    cin>>x;
    sum=-10000000000000000;
    //cout<<sum<<endl;
    fr(i,1,n-1)
    {
        cin>>y;

        a[i]=abs(y-x);
        //cout<<a[i]<<endl;
        sum=max(sum,a[i]);
        //cout<<sum<<endl;
        x=y;
    }


    n--;
    x=1;
    y=1;
    t=a[1];
    p=-1;


//cin>>i;
    while(1)
    {
        sum=max(sum,t);
        //cout<<x<<" "<<y<<" "<<t<<endl;
        //cout<<x<<" "<<y<<" new"<<endl;
        if(y<n && t>0)
        {
            while(t+a[y+1]*p>0)
            {

                //cout<<x<<" "<<y<<endl;
                t=t+a[y+1]*p;

                sum=max(sum,t);
                y++;
                //cout<<x<<" "<<y<<" "<<t<<endl;
                //cout<<y<<" "<<t<<endl;
                p*=-1;
                if(y>=n)
                {

                    break;
                }
            }
        }





        if(x+2>=y)
        {
          x+=2;
            y=x;
            t=a[x];
        }
        else
        {t=(t-a[x]+a[x+1]);

          x+=2;
        }

        if(x>n)
            break;

   }


if(n==1){
    cout<<sum<<endl;
    ex;}

    //cout<<sum<<endl;





    x=2;
    y=2;
    t=a[2];
    p=-1;


 while(1)
    {
        sum=max(sum,t);
        //cout<<x<<" "<<y<<" "<<t<<endl;
        //cout<<x<<" "<<y<<" new"<<endl;
        if(y<n && t>0)
        {
            while(t+a[y+1]*p>0)
            {

                //cout<<x<<" "<<y<<endl;
                t=t+a[y+1]*p;

                sum=max(sum,t);
                y++;
                //cout<<x<<" "<<y<<" "<<t<<endl;
                //cout<<y<<" "<<t<<endl;
                p*=-1;
                if(y>=n)
                {

                    break;
                }
            }
        }





        if(x+2>=y)
        {
          x+=2;
            y=x;
            t=a[x];
        }
        else
        {t=(t-a[x]+a[x+1]);

          x+=2;
        }

        if(x>n)
            break;

   }

    cout<<sum;



}
