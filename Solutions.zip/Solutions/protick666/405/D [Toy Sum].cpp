#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define maxx 10000000000000000
#define in1(x) scanf("%I64d",&x)
#define out(x) printf("%I64d\n",x)

#define in2(x,y) scanf("%I64d%I64d",&x,&y)

#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity

ll  vis[1000001];
vector <ll> v;
vector <ll> ans;





//x pos,y neg,temp pos a, temp neg b
int main()
{
  ll i,j,l,m,n,sum,z,k,x,y,t;
  t=1000000;
  cin>>n;
  //cout<<n<<endl;

  for(i=1;i<=n;i++)
  {
      //cout<<"i :"<<i<<endl;
      scanf("%I64d",&z);
      vis[z]=1;
  }
  //cout<<"eye"<<i<<endl;

  for(i=1;i<=500000;i++)
  {
      if(vis[i]==0 && vis[t-i+1]==0)
        v.pb(i);
  }
  j=0;

  for(i=1;i<=500000;i++)
  {
      x=i;
      y=t-i+1;

      if(vis[x]==1 && vis[y]==1)
      {
          z=v[j];
          j++;
          ans.pb(z);
          ans.pb(t-z+1);
          //cout<<i<<endl;
      }
      else if(vis[x]==1)
      {
          ans.pb(y);
        //cout<<i<<" 1"<<endl;

      }
      else if(vis[y]==1)
          {ans.pb(x);
        //cout<<i<<" 2"<<endl;
        }



  }
  cout<<ans.size()<<endl;

  for(i=0;i<ans.size();i++)
    printf("%I64d ",ans[i]);



}
