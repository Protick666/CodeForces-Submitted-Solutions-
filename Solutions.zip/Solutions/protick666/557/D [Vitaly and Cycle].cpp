#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 1000000007
#define ex  exit(0)

vector<ll> v[10000000];
ll vis[10000000];
ll len[1000000];
ll f1,f2;
void checkk(ll a)
{
    //cout<<a<<"in "<<endl;
    if((a%2)==1)
       {

        cout<<0<<" "<<1;
        ex;}

}

void dfs(ll a,ll p)
{
   // cout<<a<<endl;
    vis[a]=p;
    ll i,j,sum,q;
    for(i=0;i<len[a];i++)
    {
        q=v[a][i];
//cout<<a<<" "<<q<<endl;
        if(vis[q]!=0)
        {
            j=abs(vis[q]-vis[a])+1;
            //cout<<j<<"jay"<<endl;
            checkk(j);
        }
        else
            dfs(q,p+1);
    }
}
ll run(ll n)
{
        ll p,i;

    if(n==2)
        return 1;
    if(n<2)
        return 0;
    p=1;
        for(i=n-2+1;i<=n;i++)
          p*=i;
        p=p/2;

        return p;


}

void dfs1(ll a,ll p)
{

    ll i,j,sum,q;
    q=p%2;
    vis[a]=1;
    if(q==0)
        f1++;
    else
        f2++;
    for(i=0;i<len[a];i++)
    {
        q=v[a][i];

        if(vis[q]==0)
        {
            dfs1(q,p+1);
        }


    }
}

main()
{

    ll i,j,k,l,n,h,x,y,r,p,ans,sum,m,q;
    cin>>n>>m;

    for(i=1;i<=m;i++)
    {
        cin>>x>>y;

       len[x]++;
       len[y]++;
       v[y].pb(x);
       v[x].pb(y);
    }

    sum=-1;

    for(i=1;i<=n;i++)
        sum=max(sum,len[i]);
    if(sum==0)
    {
        p=1;
        for(i=n-3+1;i<=n;i++)
          p*=i;
        p=p/6;

        cout<<3<<" "<<p;
        ex;
    }

    if(sum==1)
    {
        cout<<2<<" "<<m*(n-2);
        ex;

    }

    for(i=1;i<=n;i++)
    {
        if(vis[i]!=0)
            continue;
        dfs(i,1);
    }

//cout<<sum;

    for(i=1;i<=n;i++)
        vis[i]=0;
    ans=0;
     for(i=1;i<=n;i++)
    {
        f1=0;
        f2=0;
        if(vis[i]!=0)
            continue;
        dfs1(i,1);
        if(f1+f2<=2)
            continue;

            //cout<<f1<<" "<<f2<<endl;
      ans+=run(f1)+run(f2);



    }

    cout<<1<<" "<<ans;







}












