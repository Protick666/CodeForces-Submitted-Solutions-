#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;


#define ll long long int


ll dp[100001];
ll z[1000001];
 char ch[100001];
vector< ll >  v;

int main() {
  //cout<<"apd";

  ll l,r,i,j,k,n,ans,sum,store,f,p;
  f=0;

  string s;


  scanf("%s",ch);


  s=ch;

  n=s.length();

  l=0;
  r=0;
for ( i = 1; i < n; i++) {
  if (i > r) {
    l = r = i;
    while (r < n && s[r-l] == s[r]) r++;
    z[i] = r-l; r--;
  } else {
    int k = i-l;
    if (z[k] < r-i+1) z[i] = z[k];
    else {
      l = i;
      while (r < n && s[r-l] == s[r]) r++;
      z[i] = r-l; r--;
    }
  }
}

for(i=n-1;i>=0;i--)
{
    l=n-i;
    if(z[i]==l)
        {f++;
        v.push_back(l);
        }


}

for(i=0;i<n;i++)
{
    p=z[i];
    dp[p]++;
}

for(i=n;i>=1;i--)
{
    dp[i]=dp[i]+dp[i+1];
}
cout<<f+1<<endl;
for(i=0;i<f;i++)
{
    p=v[i];

    printf("%I64d %I64d\n",p,dp[p]+1);

}

cout<<n<<" "<<1;




}
