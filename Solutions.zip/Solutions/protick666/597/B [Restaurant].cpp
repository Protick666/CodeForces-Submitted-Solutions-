#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
vector < pair<ll,ll> > v;
pair< ll, ll> p;
main()
{

    ll n,i,j,k,sum,ans,store,x,y;
    cin>>n;

    for(i=1;i<=n;i++)
    {
        scanf("%I64d%I64d",&x,&y);

        p=make_pair(y,x);
        v.push_back(p);

    }

    sort(v.begin(),v.end());

    sum=-100;
    ans=0;
    for(i=0;i<n;i++)
    {
        p=v[i];
        x=p.first;
        y=p.second;

        if(y>sum)
        {
            ans++;
            sum=x;
        }


    }

 cout<<ans;

}

