#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
map <long long int,long long int> m;
vector <long long int> v;
pair <long long int,long long int> p;


main()
{

long long int a,b,n,i,j,aa,bb,fa,f,fb,l,q,k,z,d,r,w,x,y,flag,m,sum,e;

cin>>n>>a>>b;

if(b>=0)
   {

    b=b%n;
b=b+a;
if(b>n)
    b=b-n;}


else
{
    b=b*(-1);
    b=b%n;
    b=a-b;
    if(b<1)
        b=n+b;



}

cout<<b;


}
