#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

map <long long int,long long int> vis;
vector < long long int > v;
long long int p1[10001];
long long int q1[10001];
long long int p2[10001];
long long int q2[10001];

long long int dira (long long int a,long long int n)
{
    int f;
    if(q2[n]>q1[n])
    {
        if(p2[a]>p1[a])
            f=1;
        else
            f=-1;


    }

     if(q2[n]<q1[n])
    {
        if(p2[a]>p1[a])
            f=-1;
        else
            f=1;


    }

     if(p2[n]>p1[n])
    {
        if(q2[a]>q1[a])
            f=-1;
        else
            f=1;


    }

     if(p2[n]<p1[n])
    {
        if(q2[a]>q1[a])
            f=1;
        else
            f=-1;


    }



   return f;


}







main()
{

long long int a,b,c,n,i,j,pf,af,aa,bb,fa,f,fb,l,q,k,z,m,d,r,w,x,y,flag,sum,e;

cin>>n;
sum=0;

for(i=1;i<=n;i++)
{
    if(i==1)
    {scanf("%I64d%I64d%I64d%I64d",&a,&b,&c,&d);
    p1[i]=a;
    q1[i]=b;
    p2[i]=c;
    q2[i]=d;}

    else
    {

        scanf("%I64d%I64d",&c,&d);
    p1[i]=p2[i-1];
    q1[i]=q2[i-1];
    p2[i]=c;
    q2[i]=d;

    }
}


for(i=1;i<=n;i++)

{
    if(i==1)
        pf=1;
    if(i<n)
    af=dira(i+1,i);
    else
    af=dira(1,i);

    if(af!=pf)
    {
        sum++;
        //cout<<i<<" "<<pf<<" "<<af<<endl;
        pf=af*(-1);
    }
    else
    {

        if(pf==1 && af==1)
          pf=1;
   if(pf==-1 && af==-1)
        pf=-1;



    }










}


cout<<sum;


}