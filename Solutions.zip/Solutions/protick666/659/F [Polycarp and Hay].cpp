#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)

class UF    {
    ll *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(ll N)   {
        cnt = N;
	id = new ll[N+1];
	sz = new ll[N+1];
        for(ll i=1; i<=N; i++)	{
            id[i] = i;
	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    ll find(ll p)	{
       ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
           ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(ll x, ll y)	{
       ll i = find(x);
        ll j = find(y);
        if (i == j) return;

		// make smaller root point to larger one
        if   (sz[i] < sz[j])	{
		id[i] = j;
		sz[j] += sz[i];
	} else	{
		id[j] = i;
		sz[i] += sz[j];
	}
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(ll x, ll y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    ll count() {
        return cnt;
    }
};
ll n,m,k,mama;
UF pa(1000002);
ll a[1002][1002];
pair<ll,ll> temp;
vector < pair <ll, pair<ll,ll> > > v;
ll id[1002][1002];
ll siz[1000002];
ll vis[1000002];
ll vis1[1000002];

ll done[1000002];
ll u[4]={0,0,1,-1};
ll o[4]={1,-1,0,0};
ll ck(ll x,ll y)
{
    if(x<1 || x>n || y<1  || y>m)
        return 0;
    return 1;

}
ll totsize(ll x,ll y)
{
    ll i,j,a,b;
    //set<pair<ll,ll> > myset;
    ll myid=id[x][y];
    ll sum=0;
    vis[myid]=1;
    for(i=0;i<4;i++)
    {
        a=x+u[i];
        b=y+o[i];
        if(ck(a,b)==0)
            cont;

        ll p=id[a][b];
        if(vis[p]==0)
            cont;
        if(pa.find(p)==pa.find(myid))
            cont;

        sum+=siz[pa.find(p)];
        pa.merge(p,myid);

    }
    siz[pa.find(myid)]=sum+1;
    return sum+1;
}

ll isdiv(ll k,ll x)
{
    if((k%x)==0)
        return k/x;
    else
        return 100000000000000;
}
void endit(ll x,ll y)
{
    if(mama==0)
        return;
    mama--;

    ll i,j,a,b;
    //set<pair<ll,ll> > myset;
    ll myid=id[x][y];
    done[myid]=1;


    for(i=0;i<4;i++)
    {
        a=x+u[i];
        b=y+o[i];
        if(ck(a,b)==0)
            cont;

        ll p=id[a][b];
        if(vis[p]==0)
            cont;
        if(done[p]==1)
            cont;
        endit(a,b);

    }


}


main()
{
    ll i,p,j,l,tot,x,y,r,b,sum,ans;
    p=1;
    cin>>n>>m>>k;
    for(i=1;i<=n*m;i++)
    {
        siz[i]=1;
    }
    fr(i,1,n)
    {
        fr(j,1,m)
        {
            id[i][j]=p;
            p++;
            in(x);
            temp=mp(i,j);

            v.pb(mp(x,temp));
        }
    }
    sort(all(v));

    for(i=v.size()-1;i>=0;i--)
    {
        temp=v[i].second;
        x=v[i].first;
        sum=totsize(temp.first,temp.second);
        p=isdiv(k,x);
        if(sum>=p)
        {
            mama=p;
            ans=x;
            endit(temp.first,temp.second);
            break;
        }

    }
    if(i==-1)
    {
        cout<<"NO";
        ex;
    }
    cout<<"YES"<<endl;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
            ll myid=id[i][j];
            if(done[myid]==1)
                printf("%I64d ",ans);
            else
                printf("0 ");
        }
        cout<<endl;
    }






}
