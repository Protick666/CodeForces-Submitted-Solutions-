#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

map <long long int,long long int> vis;
vector < long long int > v;


main()
{

long long int a,b,n,i,j,aa,bb,fa,f,fb,l,q,k,z,m,d,r,w,x,y,flag,sum,e;
sum=0;
cin>>n>>m;

for(i=1;i<=n;i++)
{
    scanf("%I64d",&q);
    vis[q]=1;
}

for(i=1;;i++)
{
    if(vis[i]==0)
    {
        if(i>m)
            break;
        else
        {
            m=m-i;
            v.push_back(i);
            sum++;
        }

    }


}

cout<<sum<<endl;
for(i=0;i<sum;i++)
{
    printf("%I64d ",v[i]);
}


}