#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
map <long long int,vector <pair <long long int,string > > > m;

pair <long long int,string > p;
map <long long int,long long int> vis;


main()
{

long long int a,b,n,i,j,aa,bb,fa,f,fb,l,q,k,z,d,r,w,x,y,flag,sum,e;

cin>>n>>q;
string s;
char c[12];
for(i=1;i<=n;i++)
{
    scanf("%s",c);
     scanf("%I64d",&d);
     scanf("%I64d",&f);
     s=c;
     p=make_pair(f,s);
     m[d].push_back(p);
     vis[d]++;
}

for(i=1;i<=q;i++)
{

    sort (m[i].begin(), m[i].end());

}

for(i=1;i<=q;i++)
{
    r=vis[i];
    if(vis[i]==2)
        cout<<m[i][r-1].second<<" "<<m[i][r-2].second<<endl;

    else
    {
        if(m[i][r-3].first!=m[i][r-1].first && m[i][r-3].first!=m[i][r-2].first)
            cout<<m[i][r-1].second<<" "<<m[i][r-2].second<<endl;
        else
          cout<<"?"<<endl;





    }



}




}

