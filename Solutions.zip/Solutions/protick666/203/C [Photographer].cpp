#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

vector<pair<int,int> > v;
pair<int,int> p;




main()
{
   long long int i,j,k,l,n,d,a,b,x,y,sum;
   cin>>n>>d;
   cin>>a>>b;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d%I64d",&x,&y);
       p=make_pair(x*a+y*b,i);
       v.push_back(p);

   }

    std::sort (v.begin(), v.end());

sum=0;
    for(i=0;i<n;i++)
    {
        if(sum+v[i].first>d)
            break;
        sum=sum+v[i].first;
    }

    cout<<i<<endl;

    for(j=0;j<i;j++)
        cout<<v[j].second<<" ";





}
