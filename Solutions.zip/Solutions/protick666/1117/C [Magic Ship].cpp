#include <bits/stdc++.h>
#include <iostream>
#include <map>
//#include "helper.h"
#include <math.h>
using namespace std;
#define ll long long int
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define PI 3.14159265

ll val[1000003][3];
ll n;
ll xSource, ySource, xDest, yDest;
bool pos(ll mid) {
    ll tot = mid / n;
    ll ex = mid % n;
    ll neededX = xDest - xSource;   ll neededY = yDest - ySource;

    //cout<<neededX<<" "<<neededY<<endl;

    ll tillX = val[n][2]*tot + val[ex][2];
    ll tillY = val[n][1]*tot + val[ex][1];

    //cout<<tillX<<" "<<tillY<<endl;

    if(mid >= abs(neededX - tillX) + abs(neededY - tillY))
        return true;
    else
    {
        //cout<<mid<<endl;
        return false;
    }
}

int main()
{
    //cout<<1;
    cin>>xSource>>ySource>>xDest>>yDest;

    ll vDel = yDest - ySource;      ll hDel = xDest - xSource;

    cin>>n;

    char ch[1000002];
    scanf("%s", ch);
    string s = ch;

    for(int i = 0; i <= n; i++) {
        val[i][0] = 0;          val[i][1] = 0;          val[i][2] = 0;
    }

    for(int i = 0; i < s.length(); i++) {
        if(s[i] == 'U') {
            val[i + 1][1] = val[i][1] + 1;
            val[i + 1][2] = val[i][2];
        }
        if(s[i] == 'D') {
            val[i + 1][1] = val[i][1] - 1;
            val[i + 1][2] = val[i][2];
        }
        if(s[i] == 'L') {
            val[i + 1][2] = val[i][2] - 1;
            val[i + 1][1] = val[i][1];
        }
        if(s[i] == 'R') {
            val[i + 1][2] = val[i][2] + 1;
            val[i + 1][1] = val[i][1];
        }
    }

    ll lim =  2000000000000000;

    ll l = 0, r = lim;

    while (true) {
        ll mid = (l + r) / 2;
        if(l > r) {
            cout<<-1;
            break;
        }
        if(pos(mid)) {
            if(mid == l) {
                cout<<mid;
                break;
            }
            else if(pos(mid - 1))
                r = mid - 1;
            else{
                cout<<mid;
                break;
            }
        }
        else {
            l = mid + 1;
        }
    }


}
