#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define maxx 1000000007
 ll i,j,k,l,n,h,x,y,r,p,ans,sum;


ll v1[1000000];
vector<ll> v2[1000000];
ll len[1000000];
ll len2[1000000];
ll vis1[1000000];
ll vis2[1000000];
vector <ll> v;

void dfs2(ll a)

{
    ll i,j;
    //cout<<a<<"eta"<<endl;
    vis2[a]=1;
    //cout<<a<<endl;

    for(i=0;i<=len[a]-1;i++)
    {

        j=v2[a][i];
         //if(a==2)
            //cout<<j<<len[2]<<endl;
        //cout<<j<<"goo";
        if(vis2[j]==0)
            {dfs2(j);
            //cout<<"lool"<<endl;

            }
    }

    sum++;

}

void dfs1(ll a)

{
    vis1[a]=1;
    if(vis1[v1[a]]==0  && v1[a]!=0)
        dfs1(v1[a]);

    v.pb(a);

}

main()

{


  cin>>n;

  for(x=1;x<=n;x++)
  {
      cin>>y;
      //len1[x]++;
      v1[x]=y;
      //len2[y]++;
     v2[y].pb(x);
     len[y]++;

  }


  for(i=1;i<=n;i++)
  {
      if(vis1[i]==1)
        continue;

    dfs1(i);

  }


    //cout<<v2[2][1]<" ";
  ans=1;
  //cout<<len[2]<<endl;
   for(j=n-1;j>=0;j--)
  {
      i=v[j];
      //cout<<i<<endl;
      if(vis2[i]==1)
        continue;
      sum=0;
    dfs2(i);
    //cout<<sum<<endl;
    if(sum!=1)
    {
        y=1;
        for(k=1;k<=sum;k++)
          y=(2*y)%maxx;
        y=y-2;
        if(y<0)
            y+=maxx;
        ans=(ans*y)%maxx;


    }
    else
        ans=(ans*2)%maxx;


  }

  cout<<ans;


}
