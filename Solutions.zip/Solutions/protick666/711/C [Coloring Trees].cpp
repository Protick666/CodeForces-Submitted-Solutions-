
#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define bal 10000000000000
ll dp[102][102][102];
ll dp1[102][102][102];
ll dp2[102][102][102];
ll a[1000];
ll col[102][102];
main()
{
    //cout<<bal;
    ll i,j,k,l,m,r,n,c,ans,sum,x,y,z,p,f,v;
   cin>>n>>m>>p;//n array,p segments, color m

   for(i=1;i<=n;i++)
    cin>>a[i];

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
            cin>>col[i][j];
    }


    for(k=1;k<=p;k++)
        {
            for(j=0;j<=m+1;j++)
            {
                dp[0][k][j]=bal;
                dp1[0][k][j]=bal;
                dp2[0][k][j]=bal;

            }
        }


    for(i=1;i<=n;i++)
    {
        for(k=0;k<=p+1;k++)
        {

            for(j=0;j<=m+1;j++)
                {dp[i][k][j]=bal;
                  dp1[i][k][j]=bal;
                  dp2[i][k][j]=bal;


                }

        }

    }


    for(i=1;i<=n;i++)
    {
        for(k=1;k<=p;k++)
        {
            if(a[i]!=0)
            {
                //j=a[i];
                l=a[i];
                r=a[i];
            }

            else
            {
                l=1;
                r=m;
            }
            for(j=l;j<=r;j++)
            {
                if(a[i]!=0)
                    v=0;
               else
                v=col[i][j];

                x=dp[i-1][k][j];
                y=dp1[i-1][k-1][j-1];
                z=dp2[i-1][k-1][j+1];
                //if(i==2 && k==1)
                    //cout<<"here "<<x<<" "<<y<<" "<<z<<endl;

                x=min3(x,y,z);
                dp[i][k][j]=x+v;
            }
            dp1[i][k][0]=bal;
            dp2[i][k][m+1]=bal;
             for(j=1;j<=m;j++)
            {
                x=dp1[i][k][j-1];
                 y=dp[i][k][j];
                dp1[i][k][j]=min(x,y);
            }


             for(j=m;j>=1;j--)
            {
                x=dp2[i][k][j+1];
                 y=dp[i][k][j];
                dp2[i][k][j]=min(x,y);
            }
        }
    }


ans=bal;
for(i=1;i<=m;i++)
{
    ans=min(ans,dp[n][p][i]);
}

if(ans==bal)
    cout<<"-1";

else
    cout<<ans;



}