#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;
map <long long int,long long int> ans;


main()
{



    long long int b,c,d,i,s,v,t,j,n,k,sum,store,flag,f,x,y,p,q,r;
    cin>>n>>k;
    v=0;
    long long int a[k];
    std::multiset<long long int> myset;
  std::multiset<long long int>::iterator it;

    for(i=1;i<=n;i++)
    {
        scanf("%I64d%I64d",&s,&t);
        if(i==1)
        {
            myset.insert(s+t);
            ans[i]=s+t;
            v++;
        }
        else
        {
            p=s;
             it = myset.begin();

            r=*it;

            if(p>=r)
            {
                myset.erase (it);
                store=s+t;
                //a[q]=s+t;
                ans[i]=store;
                 myset.insert(store);
            }
            else
            {
                if(v<k)
                   {v++;
                   r=s;}
                else
                    myset.erase (it);

                store=r+t;
                //a[q]=r+t;
                ans[i]=store;
                myset.insert(store);

            }


        }



    }

    for(i=1;i<=n;i++)
        printf("%I64d\n",ans[i]);



}
