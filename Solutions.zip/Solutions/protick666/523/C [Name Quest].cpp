#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
using namespace std;

int main ()
{
    int a,b,s,e,i,j,k,l;
    s=-10;
    e=-10;
  std::string str ;
  std::string key;
  cin>>key>>str;
  a=str.size();
  b=key.size();
  j=0;
  for(i=0;i<a;i++)
  {
      if(key[j]==str[i])
      {
          j++;
          if(j==b)
          {
              s=i+1;
              break;
          }
      }




  }

  //cout<<s;
   j=b-1;
   for(i=a-1;i>=0;i--)
   {
       if(key[j]==str[i])
       {
           j--;
           if(j==-1)
           {
               e=i-1;
                break;
           }
       }

   }

   if(e<0 || s<0)
    cout<<"0";
   else if(e-s<-1)
    cout<<"0";
   else
    cout<<(e-s)+2;


}
