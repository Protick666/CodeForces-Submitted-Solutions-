#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%lld ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265

ll ss=0;
vector<ll> v[1000002];
ll vis[1000002];

ll ck(ll p)
{
    vis[p]=1;
    ll sum=1;

    for(int i=0;i<v[p].size();i++)
    {
        if(vis[v[p][i]]==1)
            cont;
        sum+=ck(v[p][i]);

    }

    if((sum%2)==0 )
    {
        if(p!=1)
            ss++;
        return 0;
    }
    else
        return sum;



}

int main()

{

    ll n,i,j,k,m,x,y;


    cin>>n;

    fr(i,1,n-1)
    {
        in2(x,y);
        v[x].pb(y);
        v[y].pb(x);
    }
    if((n%2)==1)
    {
        cout<<"-1";
        ex;
    }


    ck(1);

    cout<<ss;





}






