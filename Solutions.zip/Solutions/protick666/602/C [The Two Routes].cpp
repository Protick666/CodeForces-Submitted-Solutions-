#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<queue>
#include<math.h>



using namespace std;
queue<int> q;

int matrix[401][401];
int vis[401];
int dist[401];
int n,sum,rail,flag;

int dfs()
{   int store,i;
    q.push(1);
    vis[1]=1;
   dist[1]=0;
    while(!q.empty())
    {
        //sum++;
        store=q.front();
        q.pop();
        for(i=1;i<=n;i++)
        {
            if(i==store)
                continue;
            if(matrix[store][i]==flag && vis[i]==0)
            {
                q.push(i);
                dist[i]=dist[store]+1;
                //cout<<i<<" ";
                if(i==n)
                    return dist[n];
                vis[i]=1;
            }
        }
        //printf("\n");




    }
    return -1;


}




main()
{int i,j,k,x,y;
cin>>n>>rail;

for(i=1;i<=rail;i++)
{
    cin>>x>>y;
    matrix[x][y]=1;
    matrix[y][x]=1;

}
if(matrix[1][n]==1)
    flag=0;
else
  flag=1;

sum=dfs();

cout<<sum;






}
