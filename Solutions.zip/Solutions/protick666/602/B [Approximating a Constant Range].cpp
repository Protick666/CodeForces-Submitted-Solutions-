#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
ll a[1000001];
ll vis[1000000];
int main()
{
    int i,j,k,l,m,r,n,ans,sum,x,y,z,p;
    ans=0;
    cin>>n;

    for(i=1;i<=n;i++)
        scanf("%I64d",&a[i]);
    l=n;
   for(i=n;i>=1;i--)
   {
       r=a[i];
       vis[r]=i;
       x=r-2;
       y=r+2;
       if(x<0)
        x=0;
        x=vis[x];
        y=vis[y];
        if(x==0)
            x=n;
        else
            x--;
        if(y==0)
            y=n;
        else
            y--;

       x=min(x,y);
       x=min(x,l);
       l=x;
       p=x-i+1;
       if(p>ans)
        ans=p;


   }



cout<<ans;


}
