#include<stdio.h>

int main()
{
    int odd[101],indx=-1,i,n,m,min,sum=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&m);
        sum+=m;
        if(m%2==1)
            odd[++indx]=m;
    }
    if(sum%2==1)
    {
        printf("%d\n",sum);
        return 0;
    }
    if(indx==-1)
        printf("0\n");
    else
    {
        min=odd[0];
        for(i=1;i<=indx;i++)
        {
            if(min>odd[i])
                min=odd[i];
        }
        printf("%d\n",sum-min);
    }
    return 0;
}