#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000
void goon()
{


}

int main() {
    int i,j,k,sum,ans,n,p;
    p=0;
    int a[15]={2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37,41, 43, 47};
    int l = 1, r = 1000000;

    for(i=0;i<15;i++)
    {
        printf("%d\n", a[i]);
        fflush(stdout);

        char response[5];
        scanf("%s", response);
        if (response[0]=='y')
        {
            p++;
            if(p>1)
                break;
            if(a[i]*a[i]>100)
                continue;
            printf("%d\n", a[i]*a[i]);
            fflush(stdout);
            char response[5];
           scanf("%s", response);
           if (response[0]=='y')
               {
                   p++;
                   break;
               }

        }



    }
    if(p<=1)
    {


    printf("prime\n");
    fflush(stdout);

    }
    else
        {


    printf("composite\n");
    fflush(stdout);

    }
}
