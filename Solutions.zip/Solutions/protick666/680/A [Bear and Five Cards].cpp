#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[10000];
ll vis[10000];
int main()
{
    ll n,i,j,k,l,sum,ans,temp,h,p,q,r,c,x,y,f,f1,f2;
    p=1;
    ans=0;
    for(i=1;i<=5;i++)
    {
        cin>>q;
        ans+=q;
        if(vis[q]==0)
        {
            a[p]=q;
            //cout<<q<<endl;
            p++;
        }
        vis[q]++;


    }
    x=ans;
    //cout<<x<<endl;
    for(i=1;i<p;i++)
    {
        q=a[i];
        //cout<<q<<" ";
        if(vis[q]<2)
            continue;
        y=vis[q]>3?3:vis[q];
        //cout<<y<<" "<<q<<endl;
        sum=ans-y*q;
        if(sum<x)
            x=sum;

    }

    cout<<x;
}
