#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
#define inf 10000000

ll a[1000000];
int main()
{
    ll n,i,j,k,l,sum,ans,temp,h,p,q,r,c,x,y,f,f1,f2;
    cin>>n>>p;

    for(i=1;i<=n;i++)
        scanf("%I64d",&a[i]);

    ans=0;
    i=p;j=p;

    while(1)
    {
        if(i==0 || j==n+1)
            break;
        if(i==p)
        {
            if(a[i]==1)
                ans++;
        }
        else
        {
            if(a[i]==1 && a[j]==1)
                ans=ans+2;

        }
        i--;
        j++;


    }

    if(i==0)
    {
        for(;j<=n;j++)
        {
            if(a[j]==1)
                ans++;
        }

    }
    else if(j==n+1)
    {
        for(;i>=1;i--)
        {
            if(a[i]==1)
                ans++;
        }

    }


cout<<ans;
}
