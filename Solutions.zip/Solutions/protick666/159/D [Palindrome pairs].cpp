#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>

using namespace std;
#define ll long long int
ll pal[2003][2003];
ll vall[1000000];
ll valr[1000000];
ll dpl[1000000];
ll dpr[1000000];
main()
{


    ll i,j,k,n,sum,p,q,r,store,cur,x,y,l;
    string s;
    char ch[1000000];
    char c;
    scanf("%s",ch);
    s=ch;
    l=s.length();

    for(i=0;i<l;i++)
        {pal[i][i]=1;
          vall[i]=1;
          valr[i]=1;
        }

    for(k=2;k<=l;k++)
    {
        for(i=0;i+k-1<=l-1;i++)
        {
            x=i;
            y=i+k-1;
            if(s[x]==s[y] && k==2)
            {
                pal[x][y]=1;
                valr[y]++;
                vall[x]++;

            }
            else if(s[x]==s[y] && pal[x+1][y-1]==1)
            {
                pal[x][y]=1;
                valr[y]++;
                vall[x]++;

            }

        }

    }


    for(i=0;i<l;i++)
    {
        if(i==0)
            dpl[i]=valr[i];
        else
          dpl[i]=valr[i]+dpl[i-1];

    }

      for(i=l-1;i>=0;i--)
    {
        if(i==l-1)
            dpr[i]=vall[i];
        else
          dpr[i]=vall[i]+dpr[i+1];

    }
sum=0;


for(i=0;i<l-1;i++)
{
    //cout<<valr[i]<<" "<<dpr[i+1]<<endl;

    sum+=valr[i]*dpr[i+1];}
cout<<sum;


}
