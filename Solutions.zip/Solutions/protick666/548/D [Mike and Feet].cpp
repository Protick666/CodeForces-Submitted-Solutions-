#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll a[1000000];
ll b[1000000];
ll r[1000000];
ll l[1000000];
ll vis[1000000];
ll s[1000000];
ll dp[1000000];
ll len;
vector<ll> vv;
pair<ll,ll> p;
vector<pair<ll,ll> > v;
main()
{

    ll n,i,j,k,sum,ans,store,x,y,z,q;
    cin>>n;

    for(i=0;i<n;i++)
        {scanf("%I64d",&a[i]);
          p=make_pair(a[i],i);
          v.push_back(p);


        }
    if(n==1)
    {
        cout<<a[0];
        exit(0);
    }
    sort(v.begin(),v.end());



    for(i=n-1;i>=0;i--)
    {
        p=v[i];
        z=p.second;
        store=p.first;
        if(vis[z]==1)
            continue;
        vis[z]=1;
        len=0;
        if(z==0 && a[z+1]<store)
            {
            r[z]=z;
            l[z]=z;
            if(dp[1]<store)
                dp[1]=store;
            continue;

        }

         if(z==n-1 && a[z-1]<store)
            {
            r[z]=z;
            l[z]=z;
            if(dp[1]<store)
                dp[1]=store;
            continue;

        }

        if(a[z-1]<store && a[z+1]<store )
        {
            r[z]=z;
            l[z]=z;
            if(dp[1]<store)
                dp[1]=store;
            continue;

        }
        x=z;

        while(a[x]>=store && x>=0)
        {

            if(a[x]==store)
            {
                s[len]=x;
                len++;
                x--;
            }
            else
            {
                x=l[x];
                if(x==0)
                    break;
                if(a[x-1]<store)
                    break;
                x--;

            }
            if(x<0)
            {
                x=0;
                break;
            }

        }
          if(a[x]<store)
            {
                x++;

            }


            y=x;
            x=z;

        while(a[x]>=store && x<n)
        {

            if(a[x]==store)
            {
                s[len]=x;
                len++;
                x++;
            }
            else
            {
                x=r[x];
                if(x==n-1)
                    break;
                if(a[x+1]<store)
                    break;
                x++;

            }
            if(x==n-1)
            {
                x=n-1;
                break;
            }

        }
          if(a[x]<store)
            {
                x--;

            }

        l[z]=y;
        r[z]=x;

        q=x-y+1;
        if(dp[q]<store)
            dp[q]=store;

        for(j=0;j<len;j++)
        {
            l[s[j]]=y;
            r[s[j]]=x;
            vis[s[j]]=1;
        }


    }




for(i=n;i>=1;i--)
    {

        if(i==n)
        {
            sum=dp[i];
            vv.push_back(sum);
        }
        else
        {
            if(dp[i]>=sum)
            {
                sum=dp[i];
                vv.push_back(sum);
            }
            else
            {
                vv.push_back(sum);
            }

        }


    }

    for(i=n-1;i>=0;i--)
        printf("%I64d ",vv[i]);
}

