#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll dp[10000001];
ll vis[10000001];
ll num[10000001];


int main()
{
   ll n,i,j,k,x,y,ans,sum,q,a,b;
   cin>>n;

   for(i=1;i<=n;i++)
   {
       scanf("%I64d",&k);
       num[k]++;
   }
   cin>>q;

   for(i=2;i<=10000000;i++)
   {
       if(vis[i]==1)
         continue;


       for(j=1;;j++)
       {
           y=j*i;
           if(y>10000000)
            break;
           vis[y]=1;
           if(num[y]!=0)
           {
               dp[i]+=num[y];
           }


       }


   }

   for(i=1;i<=10000000;i++)
    dp[i]=dp[i-1]+dp[i];


    for(i=1;i<=q;i++)
    {


        scanf("%I64d%I64d",&a,&b);

        if(a>10000000)
        {
            printf("0\n");
            continue;
        }

        if(b>10000000)
            b=10000000;
        a--;

        printf("%I64d\n",dp[b]-dp[a]);
    }








}
