#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;



main()
{

long long int a,b,n,i,j,aa,bb,fa,f,fb,l,p,q,k,z,d,r,w,x,y,flag,m,sum,e;
string s,t;
cin>>s>>t;
l=s.length();
sum=0;
for(i=0;i<l;i++)
{
    if(s[i]!=t[i])
        sum++;
}
if((sum%2)!=0)
{
    cout<<"impossible";
    exit(0);
}

f=1;
for(i=0;i<l;i++)
{
    if(s[i]!=t[i])
        {
            if(f==1)
                printf("%c",s[i]);
            else
                printf("%c",t[i]);

           f=f*(-1);

        }

    else
        printf("%c",t[i]);

}




}