#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;


map<int,int> vis;








main()
{

long long int i,j,k,l,n,s,store,sum,h;
cin>>n;
long long int a[n];


for(i=0;i<n;i++)
{
    scanf("%I64d",&a[i]);




}

sort(a,a+n);

sum=0;
h=1;

sum=a[0];

for(i=1;i<n;i++)
{
    if(a[i]<sum)
        continue;
    else
    {
        //cout<<"poop";
        h++;
        sum=sum+a[i];
    }


}
cout<<h;
}