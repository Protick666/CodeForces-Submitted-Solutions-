#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <list>
#include <stack>
#include <utility>
#include <ctime>
#include <string>
#include <map>
#include <queue>

#define num(c) (c-'a')

using namespace std;
vector<int> bap[26];
int alp[26];

main()
{

    string p;
    long long int lent,t,i,j,k,m,h,tr;

    char a,b;
    for(i=0;i<=25;i++)
    {
        alp[i]=i;

    }

    cin>>lent>>t;
    cin>>p;
    for(m=1;m<=t;m++)
    {
        cin>>a>>b;
        for(i=0;i<=25;i++)
        {
            if(alp[i]==num(a))
                alp[i]=num(b);
            else if(alp[i]==num(b))
                alp[i]=num(a);




        }



    }

for(i=0;i<lent;i++)
    cout<<(char)(alp[num(p[i])]+'a');


}