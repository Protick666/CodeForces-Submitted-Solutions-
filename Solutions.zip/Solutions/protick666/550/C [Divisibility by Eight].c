#include<stdio.h>
#include<math.h>

char a[200];
long long int flag=0;
long long int limit;
long long int fi=-10;
long long int n;
void find(long long int j,long long um,long long int lim,long long int count);
int main()
{
long long int p,i;
n=0;
scanf("%s",a);
while(a[n]!='\0')
{
    n++;
}



    limit=i;
    find(n,0,1,1);



if(flag==1)
{
    printf("YES\n");

       printf("%I64d",fi);}
else
    printf("NO\n");

}

void find(long long int j,long long um,long long int lim,long long int count)
{   long long int locs,i;
    for(i=j-1;i>=0;i--)
    {
        locs=um+((a[i]-'0')*lim);
        if(locs%8==0)
        {
            fi=locs;
            flag=1;
            return;
        }
       else if(count<3)
                find(i,locs,lim*10,count+1);
        if(flag==1)
            return;


    }


}
