#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
using namespace std;


main()
{
   long long int i,j,n,p,store,a,b,f,sum,o,e,k,c,d,l,v;

   cin>>n;

   if(n%2==0){
     cout<<"NO";
     exit(0);
   }

    cout<<"YES\n";

    if(n==1)

    {


        cout<<"2 1\n";

        cout<<"1 2";
        exit(0);

    }

   k=n+2;
 v=2*n+4;
 l=(n-3)/2;
 e=2*((n-1)+(2*n-2+1)+(n-1)*l)+1;
 cout<<v<<" "<<e<<endl;

   for(i=2;i<=n;i++)
   { printf("1");
       printf(" %I64d\n",i);
       printf("%I64d %I64d\n",n+3,i+n+2);
   }
printf("1");
   printf(" %I64d\n",n+3);
   a=n+2;
   b=n+1;
   c=2*n+4;
   d=c-1;
   cout<<a<<" "<<b<<endl;
   cout<<c<<" "<<d<<endl;
   for(i=2;i<=n;i++)
   {
       printf("%I64d %I64d\n",i,a);
       printf("%I64d %I64d\n",i,b);
       printf("%I64d %I64d\n",i+n+2,c);
        printf("%I64d %I64d\n",i+n+2,d);

   }

   l=(n-3)/2;

   for(i=2;i<=n;i++)
   {
       for(j=1;j<=l;j++)
       {
           b=i+j;
           if(b>n)
            b=b-n+1;
            printf("%I64d %I64d\n",i,b);



       }


   }



   e=n+4;
   for(i=n+4;i<=2*n+2;i++)
   {
       for(j=1;j<=l;j++)
       {
           b=i+j;
           if(b>2*n+2)
            b=b-(2*n+2)+e-1;
            printf("%I64d %I64d\n",i,b);



       }


   }



}
