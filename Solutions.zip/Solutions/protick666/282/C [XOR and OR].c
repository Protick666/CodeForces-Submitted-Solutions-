#include<stdio.h>
 char str1[10000000],str2[10000000];

int main()
{
    long long int i,k,j;
    k=0;
    j=0;

    scanf("%s%s",str1,str2);
    if(strcmp (str1,str2)==0)
    {
        printf("YES");
        return 0;
    }
    if(strlen(str1)!=strlen(str2))
    {
        printf("NO");
        return 0;
    }
    for(i=0;str1[i];i++)
    {
      if(str1[i]=='1')
        k=1;
    if(str2[i]=='1')
        j=1;

    if(k==1 && j==1)
    break;

    }

   if(k==1 && j==1)
    printf("YES");


    else
    printf("NO");
    return 0;
}
