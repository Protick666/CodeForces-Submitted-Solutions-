#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
vector<ll> pri;
vector<ll> sec;
vector<ll> v[10000001];
vector<ll> ans;
ll counter[10000002];




int main()
{
    ll i,j,k,r,l,v1,p,v2,t,x,y,n,m,cost;
    //x pri pointer
    // y sec pointer
    pri.pb(-1);
    sec.pb(-1);

    cin>>n>>m>>t;
    j=0;
    fr(i,1,n)
    {
        in(p);
        j=max(j,p);
        pri.pb(p);
    }
    sort(all(pri));
    x=pri.size()-1;
     fr(i,1,m)
    {
        in(p);
        v[p].pb(i);
         j=max(j,p);
        sec.pb(p);
    }
    sort(all(sec));
    y=sec.size()-1;

    for(i=j;i>=0;i--)
    {
        ll temp=t;
        while(pri[x]>=i && temp>0)
        {
            x--;
            temp--;
        }

        while(sec[y]>=i && temp>0)
        {
            y--;
            temp--;
            ans.pb(sec[y+1]);
        }

    }

    if(x!=0)
    {
        cout<<"-1";
        ex;
    }

    cout<<ans.size()<<endl;

    for(i=0;i<ans.size();i++)
    {
        x=ans[i];
        printf("%I64d ",v[x][counter[x]]);
        counter[x]++;
    }




}
