#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007

ll a[1000009];
ll val[1000009];
vector<ll> v[1000009];
ll vis[1000009];
ll par[1000009];
ll f,k,z;
vector< pair<ll,ll> > vv;
pair<ll,ll> s;
void fail()
{
    cout<<"-1";
    ex;
}
ll d1(ll p)
{
    ll i,j,q;
    vis[p]=1;
    val[p]+=a[p];
    for(i=0; i<v[p].size(); i++)
    {
        q=v[p][i];
        if(vis[q]==1)
            cont;

        val[p]+=d1(q);
    }

    return val[p];
}



void d2(ll p)
{
    ll i,j,q;
    vis[p]=1;

    if(val[p]==k && vv.size()!=0)
    {
        cout<<p<<" "<<vv[0].second;
        ex;
    }

    for(i=0; i<v[p].size(); i++)
    {
        q=v[p][i];
        if(vis[q]==1)
            cont;
        if(p==f)
            z++;
        d2(q);
    }
    if(val[p]==k && p!=f)
    {
        s=mp(z,p);
        vv.pb(s);
    }

}
ll ck(ll p)
{
    if(p==f || vis[p]==1)
        return 0;

    vis[p]=1;
    if(val[p]==k+k)
        return p;
    else
        return  ck(par[p]);
}
void chk(ll p)
{
    ll  i,h;
    h=ck(par[p]);
    if(h!=0)
    {
        cout<<h<<" "<<p;
        ex;
    }
}

int main()
{


    ll n,m,x,y,sum,t,i,j;
    sum=0;
    cin>>n;
    fr(i,1,n)
    {
        in2(x,y);
        par[i]=x;
        a[i]=y;

        //in2(par[i],a[i]);
        sum+=a[i];
        if(x==0)
            {f=i;
             cont;
            }

        v[x].pb(i);
        v[i].pb(x);

    }

    k=sum/3;
    //cout<<sum<<endl;
    if((sum%3)!=0)
        fail();


//z,p
//cout<<f<<endl;
   d1(f);
   for(i=0;i<=1000001;i++)
    vis[i]=0;
   d2(f);

   //for(i=1;i<=n;i++)
    //cout<<val[i]<<" ";

   //nl;
   sort(all(vv));

    if(vv.size()>1)
    {
        if(vv[0].first!=vv[vv.size()-1].first)
        {
            cout<<vv[0].second<<" "<<vv[vv.size()-1].second;
            ex;
        }
    }

    for(i=0; i<=1000002; i++)
        vis[i]=0;

    for(i=0; i<vv.size(); i++)
    {
        s=vv[i];
        x=s.first;
        y=s.second;
        chk(y);

    }

    fail();


}
