#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

long long int x[10000];
long long int m[10000];
long long int pre[10000];

#define ma 1000000007;



main()
{

long long int  i,j,k,l,n,f1,f2,sum,f,p,q,s,a,b;
cin>>n>>a>>b>>k;
if(a>b)
{
    a=a-b;
    l=n-b;

}
else
{
    a=b-a;
    l=b-1;

}

for(i=1;i<=k;i++)
{

        if(i==1)
        {
            p=1;
            q=a+a-1;

            for(j=p;j<=q;j++)
            {
                if(j>l)
                    break;

                if(j==a)
                  continue;
                x[j]=1;
                m[j]=1;
            }

            for(j=1;j<=l;j++)
            {
                pre[j]=(pre[j-1]+x[j])%ma;


            }

        }

        else
        {

            for(j=1;j<=l;j++)
            {
                s=j/2;
                f=(pre[l]-pre[s]-m[j])%ma;
                x[j]=f;
                m[j]=f;

            }

             for(j=1;j<=l;j++)
            {
                pre[j]=(pre[j-1]+x[j]);


            }




        }











}



sum=0;
for(i=1;i<=l;i++)
    sum=(sum+x[i])%ma;

cout<<sum;







}
