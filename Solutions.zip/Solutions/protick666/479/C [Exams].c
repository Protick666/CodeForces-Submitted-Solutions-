#include<stdio.h>


main()
{
    int n,b,c,i;
    scanf("%d",&n);
    int a[n][2];
    for(i=0; i<n; i=i+1)
    {
        scanf("%d%d",&a[i][0],&a[i][1]);

    }






    while(1)
    {
        b=0;


        for(i=0; i<n-1; i=i+1)
        {

            if(a[i][0]>a[i+1][0])
            {
                c=a[i][0];
                a[i][0]=a[i+1][0];
                a[i+1][0]=c;

                c=a[i][1];
                a[i][1]=a[i+1][1];
                a[i+1][1]=c;
                b=b+1;


            }
        }
        if(b==0)
            break;


    }


    while(1)
    {
        b=0;


        for(i=0; i<n-1; i=i+1)
        {

            if((a[i][0]==a[i+1][0]) && (a[i][1]>a[i+1][1]))
            {
                c=a[i][1];
                a[i][1]=a[i+1][1];
                a[i+1][1]=c;
                b=b+1;


            }
        }
        if(b==0)
            break;


    }


    

    b=0;
    for(i=0; i<n; i=i+1)
    {
        if(i==0)
            b=a[i][1];


        else
            b=a[i][1]>=b?a[i][1]:a[i][0];
















            }


    printf("%d",b);








}
