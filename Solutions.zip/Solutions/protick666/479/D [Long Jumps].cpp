#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
vector<long long int> v;

map<long long int,long long int> w;
map<long long int,long long int> vis;


main()
{

long long int  x,y,i,j,k,l,n,f1,f2,sum,f,p,q;
cin>>n>>l>>x>>y;
sum=0;
f1=0;
f2=0;
long long int a[n];
for(i=0;i<n;i++)
    {scanf("%I64d",&f);
     a[i]=f;
     vis[f]=1;
    }

for(i=0;i<n;i++)
{
    if(a[i]==x)
    {
        f1=1;
        break;
    }
    else
    {
        p=a[i];
        q=p+x;

        if(vis[q]==1)
        {
            f1=1;
            break;
        }
        else
        {
           if(q<l && q>=0)
            w[q]=1;

        }

        q=p-x;
        if(vis[q]==1)
        {
            f1=1;
            break;
        }
        else
        {
           if(q<l && q>=0)
            w[q]=1;

        }



    }


}





for(i=0;i<n;i++)
{
    if(a[i]==y)
    {
        f2=1;
        //cout<<"match"<<endl;
        break;
    }
    else
    {
        p=a[i];
       q=p+y;
        if(vis[q]==1)
        {
            f2=1;
            //cout<<p<<" "<<q<<endl;
            break;
        }
        else
        {
            if(w[q]==1)
            {
                v.push_back(q);
                sum++;
                break;

            }

        }
        q=p-y;
         if(vis[q]==1)
        {
            f2=1;
            //cout<<p<<" "<<q<<endl;
            break;
        }
        else
        {
            if(w[q]==1)
            {
                v.push_back(q);
                sum++;
                break;

            }

        }


    }


}

if(f1==1 && f2==1)
    cout<<"0";
else if(f1==1 && f2==0)
{
    cout<<"1";
    cout<<endl;
    cout<<y;
}

else if(f1==0 && f2==1)
{
    cout<<"1";
    cout<<endl;
    cout<<x;
}


else if(f1==0 && f2==0)
{
    if(sum!=0)
    {
        cout<<"1";
      cout<<endl;
       cout<<v[0];


    }
    else if(vis[y-x]==1 || vis[y+x]==1)
        {
        cout<<"1";
      cout<<endl;
       cout<<y;


    }

      else if(vis[x-y]==1 || vis[y+x]==1)
        {
        cout<<"1";
      cout<<endl;
       cout<<x;


    }
    else
    {
        cout<<"2";
      cout<<endl;
       cout<<x<<" "<<y;

    }




}


//cout<<f1<<" "<<f2;


}
