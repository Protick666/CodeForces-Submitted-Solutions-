#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 10000000000000000;
map <ll,map<ll,ll> > r;
map<ll,ll> m;
    ll n,i,j,k,l,sum,ans,x,y,z,q,p,u,v,w,t;
void inc(ll u,ll v, ll w)
{

    if(u==v)
        return;
    y=max(u,v);
    x=min(u,v);
    j=y;

    while(1)
    {
        j=j/2;
        m[j]=p;
        if(j==x)
        {

            break;
        }
        if(j==1)
            break;

    }
    j=x;
    while(1)
    {
        if(m[j]==p)
        {
            z=j;
            break;
        }
        j=j/2;

    }

    j=y;
    while(j!=z)
    {
        r[j][j/2]+=w;
        j=j/2;
    }
    j=x;
    while(j!=z)
    {
        r[j][j/2]+=w;
        j=j/2;

    }


}


void print(ll u,ll v)
{

    if(u==v)
        return;
        ll tit;
        tit=0;
    y=max(u,v);
    x=min(u,v);
    j=y;

    while(1)
    {
        j=j/2;
        m[j]=p;
        if(j==x)
        {

            break;
        }
        if(j==1)
            break;

    }
    j=x;
    while(1)
    {
        if(m[j]==p)
        {
            z=j;
            break;
        }
        j=j/2;

    }

    j=y;
    while(j!=z)
    {
        tit+=r[j][j/2];
        j=j/2;
    }
    j=x;
    while(j!=z)
    {
        tit+=r[j][j/2];
        j=j/2;

    }


    cout<<tit<<endl;


}

main()
{
    p=0;
    cin>>q;

    for(k=1;k<=q;k++)
    {
        cin>>t;
        p++;
        if(t==1)
        {
            cin>>u>>v>>w;
            inc(u,v,w);
        }
        else
        {
            cin>>u>>v;
            print(u,v);
        }

    }





}
