#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int


ll a[1000000];
ll dp[1000000];


int main() {
ll i,j,n,m,store,sum,v,f,k,ans;
cin>>n>>k;
sum=10000000;
for(i=0;i<n;i++)
    scanf("%I64d",&a[i]);

sort(a,a+n);

for(i=0;i<n;i++)
{
    if(i==0)
        dp[i]=a[i];
    else
        dp[i]=a[i]+dp[i-1];
}

j=0;
ans=-1;

for(i=0;i<n;i++)
{
    while(1)
    {
        if(j==0)
        {
            v=(i+1)*a[i]-dp[i];
            if(v<=k)
            {
                if(i+1>ans)
                    {ans=i+1;
                     sum=a[i];

                    }


                break;

            }
            j++;

        }

         else
        {
            v=(i-j+1)*a[i]-(dp[i]-dp[j-1]);
            if(v<=k)
            {
                if(i-j+1>ans)

                  {
                        sum=a[i];

                    ans=i-j+1;

                  }
                break;

            }
            j++;

        }

    }


}

cout<<ans<<" "<<sum;



}
