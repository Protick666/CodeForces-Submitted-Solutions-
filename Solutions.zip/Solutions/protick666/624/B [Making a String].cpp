#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;
#define ll long long int
ll a[1000000];
main()
{

    ll n,i,j,k,sum,ans,p;
    cin>>n;

    for(i=0;i<n;i++)
        scanf("%I64d",&a[i]);

    sort(a,a+n);

    sum=a[n-1];
    ans=a[n-1];

    for(i=n-2;i>=0;i--)
    {
        p=a[i];
        if(p>=sum-1)
        {
            ans=ans+sum-1;
            sum--;
        }
        else
        {
            ans=ans+p;
            sum=p;
        }
        if(sum==0)
            break;
    }

    cout<<ans;
}

