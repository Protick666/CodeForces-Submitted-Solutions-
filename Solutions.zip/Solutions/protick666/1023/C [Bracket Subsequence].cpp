#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265
map<ll, stack<pair<ll,ll> > > mymap;
char ch[1000002];
 ll a[1000002];
int main()
{

    ll n,t ,j,k,flag,b, q,m,x,y,p;

    cin>>n>>k;


    scanf("%s",ch);

    string s  =  ch;

    stack<ll> st;

    for(int i=0; i<s.length(); i++)
    {
        if(s[i]=='(')
            st.push(i);
        else
        {
            x = st.top();
            st.pop();
            mymap[i-x+1].push(make_pair(x,i));
        }
    }



    ll temp = n-k;

    for(int i=temp; i>=2; i=i-2)
    {
        if(i>temp || mymap[i].size() == 0)
            cont;

        pair<ll,ll> p = mymap[i].top();
        mymap[i].pop();
        
        if(a[p.first]==0)
        {
            for(int j=p.first; j<=p.second;j++)
                a[j]  = 1;

                temp-= i;

                
        }
        i=i+2;

        
    }

    for(int i=0;i<s.length();i++)
    {
        if(a[i]==1)
            cont;
        printf("%c", s[i]);
    }


}



