#include <bits/stdc++.h>
#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#define PI 3.14159265
map<ll, stack<pair<ll,ll> > > mymap;
ll mx[1000002];

 ll a[1000003];
 ll lft[1000003];
  ll rt[1000003];
ll ans[1000003];
int main()
{
    ll n,j,i,k,p,q;
    cin>>n>>k;

    for(int i=0;i<=2*k;i++)
        lft[i] = n*2;

    ll z =0;

    set<pair<ll,ll> > myset;
    //set<pair<ll,ll> >::iterator it;

    for(i = 1; i<= n; i++)
    {
        in(p);
        if(p==0)
            {
                z = i;
                cont;
            }
        lft[p] = min(lft[p],i);
        rt[p] = max(rt[p],i);

        myset.insert(make_pair(i,p));

    }
set<pair<ll,ll> >::iterator it,pit;
    //for ( it=myset.begin(); it!=myset.end(); ++it)
          //  {
             //   pair<ll,ll> p = *it;
             //   cout<<p.first<<" "<<p.second<<endl;
          //  }

    if(rt[k] == 0)
    {

        if(z==0)
        {
            cout<<"NO";
            ex;
        }
        else
        {
            //myset.erase(make_pair(z,0));
            myset.insert(make_pair(z,k));
            lft[k]=z;  rt[k]=z;
        }
    }

   // for(int i=1;i<=k;i++)
    //{
       // cout<<i<<" "<<lft[i]<< " "<<rt[i]<<endl;
    //}



    for(int i = k; i>=1; i--)
    {
        if(lft[i] == 0)
            cont;

        it = myset.find(make_pair(lft[i],i));


        //cout<<i<<endl;
        while(true)
        {
            if(it==myset.end())
                break;

            pair<ll,ll> pp = *it;

            //cout<<i<<" "<<pp.first<<endl;

            if(pp.second < i)
            {

                cout<<"NO";
                ex;
            }

            ans[pp.first] = pp.second;
            //cout<<pp.first<<" "<<pp.second<<" yo"<<endl;

            if(pp.first == rt[i])
                break;
            pit = it;

            it++;
            myset.erase(pit);
        }
    }




    for(int i=1;i<=n;i++)
    {
        mx[i] = ans[i];
    }

    for(int i=1;i<=n;i++)
    {
        if(ans[i]!=0)
            cont;
        mx[i] = max(mx[i],mx[i-1]);
        mx[i] = max(mx[i],mx[i+1]);
    }

     for(int i=n;i>=1;i--)
    {
         if(ans[i]!=0)
            cont;
        mx[i] = max(mx[i],mx[i-1]);
        mx[i] = max(mx[i],mx[i+1]);
    }

    for(int i=1; i<=n;i++)
    {
        if(ans[i]==0)
            ans[i] = mx[i];
    }

    cout<<"YES"<<endl;

     for(int i=1; i<=n;i++)
    {
        printf("%I64d ",ans[i]);
        //cout<<ans[i]<<" ";
    }






}