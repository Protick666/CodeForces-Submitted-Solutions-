#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll dp[501][501];

ll pal[501][501];

ll term[501][501];
ll a[10000];


int main()
{
   ll n,i,j,k,l1,l2,l,sum,ans,p,f,t,h,m,x,y,z,q,r;
   cin>>n;

   for(i=1;i<=n;i++)
    scanf("%I64d",&a[i]);

   for(i=1;i<=n;i++)
      pal[i][i]=1;

   for(l=2;l<=n;l++)
   {

       for(i=1;i+l-1<=n;i++)

       {
           j=i+l-1;

           if(a[i]==a[j])
           {
               if(j==i+1)
               {
                   pal[i][j]=1;
               }
               else
               {
                   if(pal[i+1][j-1]==1)
                      pal[i][j]=1;


               }


           }
       }

   }

 for(i=1;i<=n;i++)
 {
     dp[i][i]=1;

     term[i][i]=1;

 }




  for(l=2;l<=n;l++)
   {

       for(i=1;i+l-1<=n;i++)

       {
           j=i+l-1;
           if(pal[i][j]==1)
           {
               dp[i][j]=1;
               term[i][j]=1;
           }

           else
           {
               if(a[i]==a[j])
               {
                   if(j==i+1)
                    dp[i][j]=1;
                   else
                    {x=dp[i+1][j-1];
                    y=100000000;

                     for(k=i;k<j;k++)
                     {
                         z=dp[i][k]+dp[k+1][j];
                         if(z<y)
                            y=z;

                     }
                   dp[i][j]=min(x,y);
                    }
               }

               else

               {

                   x=dp[i+1][j-1]+2;
                    y=100000000;

                     for(k=i;k<j;k++)
                     {
                         z=dp[i][k]+dp[k+1][j];
                         if(z<y)
                            y=z;

                     }

                     dp[i][j]=min(x,y);





               }

           }

       }
   }




cout<<dp[1][n];
}
