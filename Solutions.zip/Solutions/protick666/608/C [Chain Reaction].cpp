#include <iostream>
#include <cstdio>
#include <stack>
#include <vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>




using namespace std;


std::map<long long int,long long int> pos;
std::map<long long int,long long int> pola;
long long int man[1000001];
long long int a[1000001];
long long int st[1000001];
main()
{
    long long int p,n,x,i,j,pre,prepo,z,store,sum,k,pp,power;
    sum=10000000001;
    z=-1;


    cin>>n;

    for(i=0;i<n;i++)
    {
        cin>>st[i];
        cin>>pp;
        pola[st[i]]=pp;


    }

    sort(st,st+n);
    for(i=1;i<=n;i++)
    {
        store=st[i-1];
        power=pola[store];
        pos[store]=i;
        if(i==1)
        {
            if(store==0)
                z=1;
            pre=store;
            man[store]=0;
            k=n-1;

            if(k<sum)
                sum=k;

        }
        else{

            for(j=pre;j<store;j++)
                a[j]=pre;
            pre=store;
            if(store-power-1<0)
            {
                man[store]=i-1;
                k=n-1;
                if(k<sum)
                    sum=k;
            }
            else if(a[store-power-1]==0 && z==-1)
            {
                man[store]=i-1;
                k=n-1;
                if(k<sum)
                    sum=k;
            }

            else
            {
                man[store]=man[a[store-power-1]]+pos[store]-pos[a[store-power-1]]-1;
                k=man[store]+n-i;
                if(k<sum)
                    sum=k;


            }


        }

     //cout<<k<<endl;
    }

    cout<<sum;


}
