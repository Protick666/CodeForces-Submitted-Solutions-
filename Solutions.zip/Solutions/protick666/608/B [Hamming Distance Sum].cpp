#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

ll dp1[1000000];
ll dpo[1000000];


int main()
{
   ll n,i,j,k,l1,l2,l,sum,ans,p,f,t,h,m,x,y,z,q,r;
   string s1;
    string s2;
    char ch1[1000000];
    char ch2[1000000];

    scanf("%s",ch1);
    scanf("%s",ch2);

    s1=ch1;
    s2=ch2;
    l1=s1.length();
     l2=s2.length();

     if(l1>l2)
     {
         cout<<"0";
         exit(0);
     }

     for(i=1;i<=l1;i++)
     {

         if(s1[i-1]=='0')
         {
             dpo[i]=dpo[i-1]+1;
         }
         else
            dpo[i]=dpo[i-1];

     }


     for(i=1;i<=l1;i++)
     {

         if(s1[i-1]=='1')
         {
             dp1[i]=dp1[i-1]+1;
         }
         else
            dp1[i]=dp1[i-1];

     }

     //for(i=1;i<=l1;i++)
       // cout<<dp1[i]<<" ";
     //cout<<endl;
     sum=0;
     for(i=0;i<l2;i++)
     {
         x=i-0+1;
        if(x>l1)
            x=l1;
        y=l2-1-i+1;
        if(y>l1)
            y=l1;
        p=1;
        q=x;
        r=l1-y;
        p=p+r;

        //cout<<x<<" "<<y<<endl;

        if(s2[i]=='0')
        {
            z=dp1[q]-dp1[p-1];
            sum+=z;
        }
        else
        {
            z=dpo[q]-dpo[p-1];
            sum+=z;
        }







     }




cout<<sum;



}
