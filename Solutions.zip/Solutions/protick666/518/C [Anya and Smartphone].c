#include<stdio.h>
#include<stdlib.h>
main()
{long long int row,col,i,j,count,sc,sum,flag,hold,hold1,hold2,n,m,k,l1,r1,l2,r2,point,pos;
scanf("%I64d%I64d%I64d",&n,&m,&k);
sum=0;

//long long int *ord=(long long int *) malloc((sizeof(long long int))*m);
long long int  **a = (long long int **) malloc((sizeof(long long int *))*(n+1));


    for(i=0; i<n+1; i++){
    /* Allocate array, store pointer  */
    a[i] = (long long int *) malloc((sizeof(long long int))*3); }
   //what to do after??

for(i=1; i<=n; i++)
  {

      scanf("%I64d",&hold);
    a[hold][0]=i;
    if(i>1)
    {
        a[hold][1]=hold1;

        a[hold1][2]=hold;

    }



    hold1=hold;



  }



    for(i=0; i<m; i++)
    {

        scanf("%I64d",&hold);

     sc=((a[hold][0])%k==0)?((a[hold][0])/k)-1:((a[hold][0])/k);
    sum=sum+1+sc;

    if(a[hold][0]!=1)
    {   pos=a[hold][0];
        a[a[hold][1]][0]=a[a[hold][1]][0]+1;
        a[hold][0]=a[hold][0]-1;
        point=a[hold][1];
        r1=a[hold][2];
        l1=a[hold][1];
        r2=a[l1][2];
        l2=a[l1][1];


        a[hold][2]=l1;
        a[point][1]=hold;
        a[point][2]=r1;
        a[hold][1]=l2;

    if(pos<n)
    {
        a[r1][1]=point;



    }



if(pos>2)
{
    a[l2][2]=hold;




}



    }




    }






printf("%I64d",sum);










}