#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
using namespace std;

map <long long int,long long int> mama;
long long int af[1000001];
long long int bf[1000001];
long long int ar[1000001];
long long int br[1000001];

main()
{

long long int a,b,n,i,j,aa,bb,fa,fb,l,p,q,k,z,d,r,w,x,y,flag,m,sum,e;

string s;
char ch[1000003];
char c;
scanf("%s",ch);
cin>>a>>b;
s=ch;
l=s.length();
sum=0;
aa=0;
bb=0;

for(i=0;i<l;i++)
{

    c=s[i];
    d=c-'0';
    aa=((aa*10)+d)%a;
    bb=((bb*10)+d)%b;
    af[i]=aa;
    bf[i]=bb;
}

aa=0;
bb=0;
fa=1;
fb=1;
for(i=l-1;i>=0;i--)
{

    c=s[i];
    d=c-'0';
    aa=(aa+fa*d)%a;
    bb=(bb+fb*d)%b;
    ar[i]=aa;
    br[i]=bb;
    fa=(fa*10)%a;
    fb=(fb*10)%b;
}















for(i=0;i<=l-2;i++)
{
    if(af[i]==0 && br[i+1]==0 && s[i+1]!='0')
    {
        cout<<"YES"<<endl;
        cout<<s.substr(0,i+1)<<endl;
        cout<<s.substr(i+1,l-i-1);
          exit(0);
    }



}


cout<<"NO"<<endl;


}
