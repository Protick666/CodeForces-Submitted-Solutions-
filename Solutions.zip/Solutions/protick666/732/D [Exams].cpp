#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
ll a[100001];
ll vis[100001];
ll p[100001];
//ll dp[10000000];
//ll pos[10000000];
ll i,j,n,k,t,sum,y,m,x,r,l,q;

ll run(ll n)
{
    ll i,ans,x,q,y;

    if(n<1)
        return 0;
    for(i=0; i<=m; i++)
        vis[i]=0;
    //sum=0;
    sum=0;
    ans=0;
    q=m-1;
    for(i=n; i>=1; i--)
    {
        x=a[i];
        if(x==0 || vis[x]==1)
        {
            if(sum>0)
                sum--;

            continue;
        }
        else if(vis[x]==0)
        {
            y=i-1-q-sum;
            if(y<p[x])
                return 0;
            sum+=p[x];
            vis[x]=1;

            q--;
            ans++;
        }
    }
    if(ans==m)
        return 1;
    else
        return 0;

}

ll check (ll n)
{
    ll x,y,z;
    x=run(n);
    y=run(n-1);
    if(x==1 && y==0)
        return 0;
    if(x==1 && y==1)
        return -1;
    if(x==0 && y==0)
        return 1;
}

main()
{
    cin>>n>>m;
    for(i=1; i<=n; i++)
        cin>>a[i];

    for(i=1; i<=m; i++)
        cin>>p[i];

    //cout<<run(44)<<endl;
    //cout<<run(9)<<endl;



    l=1;
    r=n;

    while(1)
    {
        if(l==r)
        {
            x=check(l);
            if(x==0)
                cout<<l;
            else
                cout<<"-1";
            ex;

        }
        t=(l+r)/2;
        x=check(t);
        if(x==0)
        {
            cout<<t;
            ex;
        }
        else if(x==1)
            l=t+1;
        else
            r=t;
    }


}












