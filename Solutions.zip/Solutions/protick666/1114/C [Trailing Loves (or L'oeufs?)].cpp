#include <bits/stdc++.h>

#include <math.h>
using namespace std;
////https://github.com/andrewaeva/DGA
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;
#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
//#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 100000007
#define PI 3.14159265
ll primeSieve[1000002];
vector<ll> allPrime;
ll tst(ll n, ll b)
{

    ll t = 1;
    for(int i = 1; i <= n; i++)
        t = t * i;
    ll p = 0;
    while(true)
    {
        ll d = t % b;
        if(d != 0)
            break;
        p++;
        t = t / b;
    }

    return p;

}

void preparePrime(ll n)
{
    //cout<<n<<" prime calc"<<endl;
    for(int i = 1; i <=n; i++)
        primeSieve[i]= i;

    for(ll i = 2; i<=n; i++)
    {
        if(primeSieve[i] != i)
            continue;
        allPrime.push_back(i);
       // cout<<i<<" prime "<<endl;

        for(ll j = 1; j * i <=n; j++)
        {
            primeSieve[j*i] /= i;
        }
    }
}

ll ck(ll n, ll q)
{
    ll p = 0;
    ll t = q;
    while(true)
    {
        if(n / t == 0)
            break;
        p += n/t;
        t = t * q;
    }
    return p;
}

ll cc(ll n, ll p, ll tot)
{
    ll sum = 0;
    ll t = p;
    while(true)
    {
        if(n/t == 0)
            break;
        sum += n/t;
        n = n / t;
    }

    return sum / tot;
}
int main()
{
    //cout<<1;
    ll m,n, k, t, p, b;

    vector<pair<ll,ll> > cand;
    cin>>n>>b;
    ll sum = 0;
    preparePrime(sqrt(b));

    ll temp = b;

    for(int i = 0; i < allPrime.size(); i++)
    {
        //cout<<allPrime.size()<<endl;
        ll p = allPrime[i];

        if(temp % p != 0)
            cont;

        ll sum = 0;
        while(temp % p == 0)
        {
            sum++;
            temp =  temp / p;
        }

        cand.push_back(make_pair(p, sum));
    }

    if(temp != 1)
    {
        cand.push_back(make_pair(temp, 1));
    }

    ll ab = 0;

    for(int i = 0; i < cand.size(); i++)
    {
        if(i == 0)
            ab = cc(n, cand[i].first, cand[i].second);
        else
            ab = min(ab,  cc(n, cand[i].first, cand[i].second) );
        //cout<< cand[i].first<<" "<<cand[i].second<<endl;
    }


    cout<<ab<<endl;
    //cout<<tst(n,b)<<endl;;


}