#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007



vector<ll> v[101];

ll aa[101][101];

ll x[101];
ll y[101];
ll vis[101];



ll check(ll a,ll b)
{
    ll p,m,n,i;
    queue <ll> q;

    q.push(a);
    for(i=1;i<=100;i++)
        vis[i]=0;
    vis[a]=1;

    while(!q.empty())
    {
        n=q.front();
        q.pop();

        for(i=1;i<=100;i++)
        {
            if(aa[n][i]==1 && n!=i)
            {
                if(vis[i]==0)
                {
                    q.push(i);
                    //if(a==1)
                       // cout<<i<<endl;
                    if(i==b)
                        return 1;
                    vis[i]=1;
                }
            }
        }



    }

    return 2;
}



int main()
{
   ll n,i,j,sum,p,k,q,m,ans,l,f,r,a,b,u,v,t;
   p=1;
   cin>>n;
   for(j=1;j<=n;j++)
   {
       cin>>f>>a>>b;

       if(f==1)
       {
           x[p]=a;
           y[p]=b;
           //p++;

           for(i=1;i<p;i++)
           {
               u=x[i];
               v=y[i];
               if(u>a && u<b)
                 {aa[i][p]=1;


                 }
                if(v>a && v<b)
                 {aa[i][p]=1;


                 }
                 if(a>u && a<v)
                 aa[p][i]=1;
                  if(b>u && b<v)
                 aa[p][i]=1;

           }
           p++;

       }

       else

       {

           t=check(a,b);
           if(t==1)
             cout<<"YES"<<endl;
           else
            cout<<"NO"<<endl;



       }

   }

//cout<<aa[2][4];

}
