#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
ll a[1000001];
ll val[1000001];
vector<ll> v[1000001];
ll ans=-10000000000000000;
ll f=0;
ll vis[1000001];
ll d(ll p)
{
    ll i,j,q;
    vis[p]=1;
    val[p]+=a[p];
    for(i=0; i<v[p].size(); i++)
    {
        q=v[p][i];
        if(vis[q]==1)
            cont;
        val[p]+=d(q);
    }
    return val[p];
}
ll dfs(ll p)
{
    ll i,j,sum,k,q,t;
    sum=-10000000000000000;
    vis[p]=1;
    vector<ll> vv;
     for(i=0; i<v[p].size(); i++)
    {
        q=v[p][i];
        if(vis[q]==1)
            cont;
        t=dfs(q);
        vv.pb(t);
        //cout<<p<<" "<<t<<endl;
    }
    sort(all(vv));
    t=vv.size();
    if(t>1)
    {
                //cout<<vv[t-1]+vv[t-2]<<endl;

        ans=max(ans,vv[t-1]+vv[t-2]);
        f=1;
    }
    if(t>0)
        sum=max(sum,vv[t-1]);
    sum=max(sum,val[p]);
    //cout<<p<<" "<<sum<<endl;
    return sum;

}
int main()
{


    ll n,m,x,y,sum,t,i,j;

    cin>>n;
    loop(i,n)
      cin>>a[i+1];
    loop(i,n-1)
    {
        cin>>x>>y;
        v[x].pb(y);
        v[y].pb(x);
    }
    d(1);
    //for(i=1;i<=n;i++)
        //cout<<val[i]<<" ";
    //cout<<endl;
    loop(i,n+1)
      vis[i]=0;
    dfs(1);
    if(f==0)
        cout<<"Impossible";
    else
        cout<<ans;

}
