#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);
#define tt(x) cout<<"reached here "<<x<<endl;

#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF 1000000000000000 //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)
#define inv 10000000000
#define zz 1000000007
#include <cstddef>
ll a[5002];
ll dp[5005][5005];
//ll dp_sum[5005][5005];

int main()
{
    ll i,j,k,m,n,t,x,y;
    cin>>n;
    //cin>>n;

    fr(i,1,n)
    {
        char c;
        cin>>c;
        a[i]=(c=='f')?1:2;
    }
    dp[1][1]=1;
    dp[1][0]=1;

    for(i=2; i<=n; i++)
    {
        if(a[i-1]==1)
        {
            //sum=0;
            fr(j,2,n+1)
            {
                dp[i][j]=dp[i-1][j-1]-dp[i-1][j];
                if( dp[i][j]<0)
                    dp[i][j]+=zz;
                //sum=(sum+dp[i][j])%zz;

            }
        }
        else
        {
            fr(j,1,n+1)
            {
                dp[i][j]=dp[i-1][j];
                //sum=(sum+dp[i][j])%zz;

            }
        }

        //cout<<i<<" yes"<<endl;
       // for(j=0; j<=n+1; j++)
            //cout<<j<<" : "<<dp[i][j]<<endl;

        for(j=n+1; j>=1; j--)
        {
            dp[i][j]=(dp[i][j]+dp[i][j+1])%zz;
            if(dp[i][j]<0)
                dp[i][j]+=zz;

        }
         //for(j=0; j<=n+1; j++)
            //cout<<j<<" yo: "<<dp[i][j]<<endl;
    }

    cout<<dp[n][1]<<endl;



}
