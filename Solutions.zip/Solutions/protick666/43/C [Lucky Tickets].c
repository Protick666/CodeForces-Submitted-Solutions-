#include<stdio.h>




main()
{

long long int d0,d1,d2,n,store,flag,i;
long long int a[3];
a[0]=0;
a[1]=0;
a[2]=0;
scanf("%I64d",&n);
for(i=1;i<=n;i++)
{
scanf("%I64d",&store);

flag=store%3;
a[flag]++;


}

store=0;

if(a[2]>=a[1])
{
store=a[0]/2+a[1];


}

else

store=a[0]/2+a[2];




printf("%I64d",store);



}
