#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
#include <vector>
#include<algorithm>
#include<math.h>
#include<utility>
#include<map>
#include<set>
#include <string.h>
#include <iomanip>

using namespace std;
#define ll long long int
#define inf 10000000

#define mod 1000000007


ll a[1000000];


int main()
{
   ll n,i,j,x,y,sum,p,r,q,m,ans;
   cin>>n;

   if((n%2)==0)
   {
       cout<<"-1";
       exit(0);
   }

   for(i=1;i<=n;i++)
   {
       printf("%I64d ",i-1);
   }

   cout<<endl;

    for(i=1;i<=n;i++)
   {
       printf("%I64d ",i-1);
   }

   cout<<endl;

    for(i=1;i<=n;i++)
   {
       x=2*(i-1);
       x=x%n;
       printf("%I64d ",x);
   }







}
