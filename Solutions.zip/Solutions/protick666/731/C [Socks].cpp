#include<bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define boro 2000000011
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)

class UF
{
    ll *id, cnt, *sz;
public:
    // Create an empty union find data structure with N isolated sets.
    UF(ll N)
    {
        cnt = N;
        id = new ll[N+1];
        sz = new ll[N+1];
        for(ll i=1; i<=N; i++)
        {
            id[i] = i;
            sz[i] = 1;
        }
    }
    ~UF()
    {
        delete [] id;
        delete [] sz;
    }
    // Return the id of component corresponding to object p.
    ll find(ll p)
    {
        ll root = p;
        while (root != id[root])
            root = id[root];
        while (p != root)
        {
            ll newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
    // Replace sets containing x and y with their union.
    void merge(ll x, ll y)
    {
        ll i = find(x);
        ll j = find(y);
        if (i == j) return;

        // make smaller root point to larger one
        if   (sz[i] < sz[j])
        {
            id[i] = j;
            sz[j] += sz[i];
        }
        else
        {
            id[j] = i;
            sz[i] += sz[j];
        }
        cnt--;
    }
    // Are objects x and y in the same set?
    bool connected(ll x, ll y)
    {
        return find(x) == find(y);
    }
    // Return the number of disjoint sets.
    ll count()
    {
        return cnt;
    }
};
vector <ll> v[1000000];
ll col[1000001];
int main()
{
    ll i,j,k,n,m,x,y,ans,sum,p;
    cin>>n>>m>>k;
    UF pad(n);
    /*


    //pad=new UF(5);
    pad.merge(1,2);
    pad.merge(3,4);
    //pad.merge(3,2);
    for(i=1;i<=5;i++)
        pad.find(i);
    for(i=1;i<=5;i++)
        cout<<pad.find(i)<<endl;


    */

    for(i=1; i<=n; i++)
        cin>>col[i];

    for(i=1; i<=m; i++)
    {
        cin>>x>>y;
        pad.merge(x,y);
    }

    for(i=1; i<=n; i++)
    {
        x=pad.find(i);
        v[x].pb(i);
    }



    ans=0;

    for(i=1; i<=n; i++)
    {
        for(j=0;j<v[i].size();j++)
            v[i][j]=col[v[i][j]];
    }

    for(i=1; i<=n; i++)
    {

        sort(v[i].begin(),v[i].end());
    }


    for(i=1; i<=n; i++)
    {
        sum=-1;
        x=0;
        y=v[i].size();


        while(1)
        {
            if(x==y)
                break;
            j=x;
            while(v[i][x]==v[i][j])
            {
                j++;
                if(j==y)
                    break;
            }
            j--;
            p=j-x+1;
            sum=max(sum,p);
            x=j+1;

        }
        if(sum==-1)
            continue;
        else
            ans+=y-sum;
    }


    cout<<ans;

}










