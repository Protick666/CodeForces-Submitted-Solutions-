#include <bits/stdc++.h>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define cc(c) (c - 'a')
#define pb push_back
#define mp make_pair
#define fi first+
#define se second
#define flag(i) cout<<"case "<<i<<endl;


//#define maxx 10000000000000000
#define all(X) X.begin(), X.end()
#define loop(i,n) for ( i=0; i<ll(n); i++ )
#define fr(i,x,y) for ( i=x; i<=y; i++ )
#define fur(i,x,y) for ( i=x; i>=y; i-- )
#define out(x) printf("%I64d ",x);

#define in(x) scanf("%I64d",&x);
#define in2(x,y) scanf("%I64d%I64d",&x,&y);


#define REP1(i,a,b) for ( ll i=(a); i<=ll(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
#define ex  exit(0)
#define LSOne(S) (S & (-S))
#define INF INT_MAX //Infinity
#define cont continue
#define nl cout<<endl
#define modd 1000000007
#define jj(x,y,v) v[x].pb(y);v[y].pb(x)

ll dp[200002];
ll vis[3000002];
ll a[300001];
main()
{
    ll i,n,p,j,k,l,tot,x,y,r,b,sum,ans;
    cin>>n;
    ans=0;
    tot=0;
    r=-1;
    fr(i,1,n)
     {in(a[i]);
       r=max(r,a[i]);
       tot+=a[i];
       dp[a[i]]++;

     }

     for(i=200000;i>=1;i--)
        dp[i]+=dp[i+1];

    fr(i,1,n)
    {
        x=a[i];
        if(vis[x]==1)
            cont;
        vis[x]=1;
        if(x==1)
        {
            ans=max(ans,tot);
            cont;
        }
        j=r/x;
        p=0;
        ll val=0;
        //cout<<endl<<endl<<endl;
        for(l=j;l>=1;l--)
        {
            y=l*x;
            //cout<<dp[y]*y-p<<" "<<y<<" "<<x<<endl;
            val+=(dp[y]-p)*y;
            p=dp[y];
        }

        ans=max(ans,val);

    }



cout<<ans;

}
