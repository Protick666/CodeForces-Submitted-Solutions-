#include<bits/stdc++.h>
#include <queue>
#include <vector>
#include <climits>
using namespace std;
#define  ll  long long int
#define max3(a, b, c) max(a, b) > max(b, c) ? max(a, b) : max(b, c)
#define min3(a, b, c) min(a, b) < min(b, c) ? min(a, b) : min(b, c)
#define digit(c) (c - '0')
#define pb push_back
#define mp make_pair
#define fi first
#define cont continue

#define se second
#define maxx 10000000000000000
#define ALL(x) begin(x),end(x)
#define loop(i,n) for ( int i=0; i<int(n); i++ )
#define REP1(i,a,b) for ( int i=(a); i<=int(b); i++ )
#define FOR(it,c) for ( auto it=(c).begin(); it!=(c).end(); it++ )
#define mp make_pair
//#define maxx 1000000007
#define ex  exit(0)
#define LSOne(S) (S & (-S))
//cout << fixed << setprecision(2) << total;
#define INF INT_MAX //Infinity


double dp[200][200][200];

double pro(ll i,ll j,ll k)
{
    return i*j+j*k+k*i;
}

//x pos,y neg,temp pos a, temp neg b
int main()
{
    double n,l,a,b,c,sum;
    ll i,j,k,x,y,z;
    cin>>x>>y>>z;
    dp[x][y][z]=1;

    for(i=x; i>=0; i--)
    {
        for(j=y; j>=0; j--)
        {
            for(k=z; k>=0; k--)
            {
                //x rock,y scissors,z paper
                if(i+j+k==0)
                    cont;
                if(i+j+k==x+y+z)
                    cont;
                if(pro(i+1,j,k)!=0)
                    dp[i][j][k]+=dp[i+1][j][k]*((i+1)*k/pro(i+1,j,k));
                if(pro(i,j+1,k)!=0)
                    dp[i][j][k]+=dp[i][j+1][k]*((j+1)*i/pro(i,j+1,k));
                if(pro(i,j,k+1)!=0)
                    dp[i][j][k]+=dp[i][j][k+1]*((k+1)*j/pro(i,j,k+1));

                //cout<<i<<" "<<j<<" "<<k<<" "<<dp[i][j][k]<<endl;


            }
        }
    }
    a=0;
    for(i=1; i<=x; i++)
        a+=dp[i][0][0];
    cout << fixed << setprecision(12) << a<<" ";

    a=0;
    for(i=1; i<=y; i++)
        a+=dp[0][i][0];
    cout << fixed << setprecision(12) << a<<" ";
    a=0;
    for(i=1; i<=z; i++)
        a+=dp[0][0][i];
    cout << fixed << setprecision(12) << a;


}
