#include<stdio.h>
main()
{
long long int n,i,j,k,l,sum,sum1,low;
scanf("%I64d",&n);
long long int move[n];
long long int price[5][2];
for(i=0;i<n;i++)
{
scanf("%I64d",&move[i]);

}


for(i=0;i<5;i++)
{
scanf("%I64d",&price[i][0]);
price[i][1]=0;
}
low=price[0][0];
sum=0;
for(i=0;i<n;i++)
{
sum=sum+move[i];
for(j=4;j>=0;j--)
{   if(sum<low)
          break;
    if(sum>=price[j][0])
    {   k=sum/price[j][0];


        price[j][1]=price[j][1]+k;
        sum=sum-k*price[j][0];





    }



}

}




for(i=0;i<5;i++)
{
printf("%I64d ",price[i][1]);
printf("\n");

}
printf("%I64d",sum);






}